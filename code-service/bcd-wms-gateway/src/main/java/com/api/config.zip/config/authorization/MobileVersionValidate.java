package com.api.config.authorization;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.dataset.DataTable;
import com.server.db.DbHelpImpl;
import com.server.generate.GenerateSqlImpl;
import com.server.params.GenerateSqlTran;
import com.server.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author lw
 * @date: 2023/12/12
 * @description:
 **/
@Slf4j
@Configuration
@Service
public class MobileVersionValidate {

    @Resource
    private DbHelpImpl dbHelp;
    @Resource
    private RedisService redisService;

    private String dbName = "project";

    public static JSONObject version=null;


    public boolean redisValidate(String mobileVersion, JSONObject mobileVersionMode) {

        try {

            if (version == null) {
                setdbValidate();
            }
            if(version!=null){
                if (!version.getString("PDA_UPDATE_VERSION").equals(mobileVersion)) {
                    return dbValidate(mobileVersion, mobileVersionMode);
                }
            }
            return true;

        } catch (QueryTimeoutException e) {
            log.error("redis出现异常！异常信息:" + e);
            return dbValidate(mobileVersion, mobileVersionMode);
        }

    }

    public void setdbValidate() {

        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.set_strsql("SELECT PDA_UPDATE_NAME,PDA_UPDATE_VERSION,PDA_UPDATE_URL,PDA_UPDATE_CONTEXT,PDA_UPDATE_SIZE FROM S_PDA_UPDATE T WHERE 1=1 AND T.ACTIVE=1  ORDER BY T.CREATE_DATE DESC ");
        try {
            JSONArray data = dbHelp.queryJson(dbName, generateSqlTran);

            if (data.size() > 0) {
                version = data.getJSONObject(0);
            }

        } catch (Exception e) {
            log.error("数据处理出现异常! 异常原因:" + e);
        }

    }

    public boolean dbValidate(String mobileVersion, JSONObject mobileVersionMode) {

        try {

            GenerateSqlTran generateSqlTran = new GenerateSqlTran();
            generateSqlTran.set_strsql("SELECT PDA_UPDATE_NAME,PDA_UPDATE_VERSION,PDA_UPDATE_URL,PDA_UPDATE_CONTEXT,PDA_UPDATE_SIZE FROM S_PDA_UPDATE T WHERE 1=1 AND T.ACTIVE=1  ORDER BY T.CREATE_DATE DESC ");
            JSONArray data = dbHelp.queryJson(dbName, generateSqlTran);
            if (data.size() == 0) {
                return true;
            }
            mobileVersionMode.put("PDA_UPDATE_NAME",data.getJSONObject(0).getString("PDA_UPDATE_NAME"));
            mobileVersionMode.put("PDA_UPDATE_VERSION",data.getJSONObject(0).getString("PDA_UPDATE_VERSION"));
            mobileVersionMode.put("PDA_UPDATE_URL",data.getJSONObject(0).getString("PDA_UPDATE_URL"));
            mobileVersionMode.put("PDA_UPDATE_CONTEXT",data.getJSONObject(0).getString("PDA_UPDATE_CONTEXT"));
            mobileVersionMode.put("PDA_UPDATE_SIZE",data.getJSONObject(0).getString("PDA_UPDATE_SIZE"));
            version = data.getJSONObject(0);
            if (!data.getJSONObject(0).getString("PDA_UPDATE_VERSION").equals(mobileVersion)) {
                return false;
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
