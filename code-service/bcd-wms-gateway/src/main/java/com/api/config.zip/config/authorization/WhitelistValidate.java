package com.api.config.authorization;

import com.server.db.DbHelpImpl;
import com.server.generate.GenerateSqlImpl;
import com.server.params.GenerateSqlTran;
import com.server.redis.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Configuration
@Service
public class WhitelistValidate {
    @Resource
    private DbHelpImpl dbHelp;
    @Resource
    private RedisService redisService ;
    @Resource
    private GenerateSqlImpl generateSql;

    private String dbName="project" ;
    public static List<Map<String, Object>> listWhitelist = null;
    public boolean redisValidate(String url){

        try {

            if (listWhitelist == null) {
                listWhitelist =  redisService.getCacheObject("WHITELIST");
                if(listWhitelist==null){
                    setdbValidate();
                }
            }
            List<Map<String, Object>> Whitelist =
                    listWhitelist.stream().filter(jur -> jur.get("URL").toString().equals(url)).collect(Collectors.toList());
            if (Whitelist.size() == 0) {

                if(dbValidate(url)){
                    setdbValidate();
                    return true;
                }
                return false;
            }
            if(Whitelist.get(0).get("ACTIVE").toString().equals("0")){
                return false;
            }
            return true;

        }catch(QueryTimeoutException e){
            log.error("redis出现异常！异常信息:"+e);
            return  dbValidate(url);
        }

    }
    public void setdbValidate() {

        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.set_strsql("SELECT URL,ACTIVE FROM S_WHITELIST T WHERE 1=1 ");

        try {
            listWhitelist=   dbHelp.queryMap(dbName, generateSqlTran, "WHITELIST");
        } catch (Exception e) {
            log.error("数据处理出现异常! 异常原因:" + e);
        }

    }
    public boolean dbValidate(String url){

        try {
            GenerateSqlTran generateSqlTran=generateSql.sqlQuery(dbName,"S_WHITELIST",generateSql.add("URL",url));

            List<Map<String, Object>>Whitelist=   dbHelp.queryMap(dbName, generateSqlTran);
            if (Whitelist.size() == 0) {
                return false;
            }
            if(Whitelist.get(0).get("ACTIVE").toString().equals("0")){
                return false;
            }
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return  false;
    }


}
