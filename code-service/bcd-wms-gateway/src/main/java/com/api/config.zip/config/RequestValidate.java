package com.api.config;

import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson.JSONArray;
import com.api.model.RequestRes;
import com.server.db.DbHelpImpl;
import com.server.generate.GenerateSqlImpl;
import com.server.params.GenerateSqlTran;
import com.server.redis.RedisService;
import io.netty.util.internal.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Slf4j
@Configuration
@Service
public class RequestValidate {
    public final static String LoginToken = "login_tokens:";
    public static List<Map<String, Object>> listJurisdictions = null;
    public static List<Map<String, Object>> listPageApi = null;
    public static List<Map<String, Object>> listPage = null;
    private final String dbName = "project";
    private final String JurisdictionsSql = "SELECT JURISDICTION_KEY,ACTIVE FROM S_JURISDICTION T WHERE 1=1";
    private final String PageSql = "SELECT T.JURISDICTION_KEY,T.PAGE_KEY,S.SYSTEM_TYPE FROM S_JURISDICTION_PAGE T LEFT JOIN S_PAGE S ON T.PAGE_KEY=S.PAGE_KEY WHERE 1=1 ";
    private final String PageApiSql = "SELECT API_URL,JURISDICTION_KEY,PAGE_KEY,SYSTEM_TYPE FROM(SELECT T.JURISDICTION_KEY,T.PAGE_KEY,P.API_URL,S.SYSTEM_TYPE FROM S_JURISDICTION_PAGE_API T LEFT JOIN S_PAGE_API P ON T.PAGE_API_KEY=P.PAGE_API_KEY LEFT JOIN S_PAGE S ON T.PAGE_KEY=S.PAGE_KEY) T WHERE 1=1";
    @Resource
    private DbHelpImpl dbHelp;
    @Resource
    private RedisService redisService;
    @Resource
    private GenerateSqlImpl generateSql;
    @Resource
    private WhitelistValidate whitelistValidate;

    public boolean redisValidate(RequestRes requestRes) {
        try {

            if (listJurisdictions == null) {
                listJurisdictions = redisService.getCacheObject("JURISDICTION");
                if (listJurisdictions == null) {
                    setJurisdiction();
                }
            }
//            if (listPage == null) {
//                listPage = redisService.getCacheObject("JURISDICTION_PAGE");
//                if (listPage == null) {
//                    setPage();
//                }
//            }
            if (listPageApi == null) {
                log.info("start time:" + DateTime.now());
                listPageApi = redisService.getCacheObject("JURISDICTION_PAGE_API");
                log.info("end time:" + DateTime.now());
                if (listPageApi == null) {
                    CompletableFuture.runAsync(this::setPageApi);
                }
            }

            long jurCount =
                    listJurisdictions.stream().filter(jur -> jur.get("JURISDICTION_KEY").toString().equals(requestRes.getJurisdiction())).count();
            if (jurCount == 0) {
                if (getJurisdiction(requestRes)) {
                    setJurisdiction();

                }

            }

//            long pageCount =
//                    listPage.stream().filter(jur -> Integer.parseInt(jur.get("JURISDICTION_KEY").toString())==Integer.parseInt(jurisdiction)).filter(page -> page.get("PAGE_KEY").toString().equals(pageId)).count();
//            if (pageCount == 0) {
//                if(getPage(jurisdiction,pageId)){
//                    setPage();
//                    return true;
//                }
//                return false;
//            }
            List<Map<String, Object>> pageApiCount =
                    listPageApi.stream().filter(jur -> Integer.parseInt(jur.get("JURISDICTION_KEY").toString()) == Integer.parseInt(requestRes.getJurisdiction())).filter(page -> page.get("PAGE_KEY").toString().equals(requestRes.getPageKey())).filter(pageApi -> pageApi.get("API_URL").toString().equals(requestRes.getPageUrl())).collect(Collectors.toList());
            if (pageApiCount.size() == 0) {
                if (whitelistValidate.redisValidate(requestRes.getPageUrl())) {
                    return true;
                }
                if (getPageApi(requestRes)) {
                    CompletableFuture.runAsync(this::setPageApi);
                    return true;
                }
                return false;
            } else {
                requestRes.setSystemType(pageApiCount.get(0).get("SYSTEM_TYPE").toString());
            }
        } catch (QueryTimeoutException e) {
            log.error("redis连接出现异常！异常信息:" + e);
            //如果连接出现异常 则去数据库进行查询判断
            return dbValidate(requestRes);
        }
        return true;
    }

    //数据库校验
    public boolean dbValidate(RequestRes requestRes) {

        return getJurisdiction(requestRes) && getPage(requestRes) && getPageApi(requestRes);

    }

    //数据库查询角色标识做判断
    public boolean getJurisdiction(RequestRes requestRes) {
        JSONArray jurWhere = new JSONArray();
        this.generateSql.add(jurWhere, "JURISDICTION_KEY", requestRes.getJurisdiction());
        GenerateSqlTran sqlTran = this.generateSql.sqlQuery(dbName, "S_JURISDICTION", new StringBuilder(JurisdictionsSql), jurWhere);
        return catchException(sqlTran, null);

    }

    //数据库查询pageid做判断
    public boolean getPage(RequestRes requestRes) {
        JSONArray pageWhere = new JSONArray();
        this.generateSql.add(pageWhere, "JURISDICTION_KEY", requestRes.getJurisdiction());
        this.generateSql.add(pageWhere, "PAGE_KEY", requestRes.getPageKey());
        GenerateSqlTran sqlTran = this.generateSql.sqlQuery(dbName, "S_JURISDICTION_PAGE", new StringBuilder(PageSql), pageWhere);
        return catchException(sqlTran, null);

    }

    //数据库查询url做判断
    public boolean getPageApi(RequestRes requestRes) {
        JSONArray pageApiWhere = new JSONArray();
        this.generateSql.add(pageApiWhere, "JURISDICTION_KEY", requestRes.getJurisdiction());
        this.generateSql.add(pageApiWhere, "PAGE_KEY", requestRes.getPageKey());
        this.generateSql.add(pageApiWhere, "API_URL", requestRes.getPageUrl());
        GenerateSqlTran sqlTran = this.generateSql.sqlQuery(dbName, "S_JURISDICTION_PAGE_API", new StringBuilder(PageApiSql), pageApiWhere);
        return catchException(sqlTran, requestRes);

    }


    //统一的抓取异常处理
    private boolean catchException(GenerateSqlTran sqlTran, RequestRes requestRes) {
        try {
            JSONArray data = dbHelp.queryJson(dbName, sqlTran);
            if (data.size() > 0) {
                if (requestRes != null) {
                    requestRes.setSystemType(data.getJSONObject(0).getString("SYSTEM_TYPE"));
                }

            }
            return data.size() != 0;
        } catch (Exception e) {
            log.error("数据处理出现异常! 异常原因:" + e);
            return false;
        }
    }


    //从数据库查询设置角色缓存
    public void setJurisdiction() {

        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.set_strsql(JurisdictionsSql);

        try {
            listJurisdictions = dbHelp.queryMap(dbName, generateSqlTran, "JURISDICTION");
        } catch (Exception e) {
            log.error("数据处理出现异常! 异常原因:" + e);
        }

    }

    //从数据库查询设置page缓存
    public void setPage() {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.set_strsql(PageSql);

        try {
            listPage = dbHelp.queryMap(dbName, generateSqlTran, "JURISDICTION_PAGE");
        } catch (Exception e) {
            log.error("数据处理出现异常! 异常原因:" + e);
        }
    }

    //从数据库查询设置URL缓存
    public void setPageApi() {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.set_strsql(PageApiSql);

        try {
            listPageApi = dbHelp.queryMap(dbName, generateSqlTran, "JURISDICTION_PAGE_API");
        } catch (Exception e) {
            log.error("数据处理出现异常! 异常原因:" + e);
        }
    }

    //登录token校验
    public boolean getLoginToekn(String Btoken) {
        String token = Btoken.substring(Btoken.lastIndexOf(" ") + 1);
        String loginToken = redisService.getCacheObject(LoginToken + token);
        if (StringUtil.isNullOrEmpty(loginToken)) {
            try {
                GenerateSqlTran tokenInSqlTran = new GenerateSqlTran();
                JSONArray Where = new JSONArray();
                generateSql.add(Where, "LOGIN_TOKEN", token);
                String Sql = "SELECT LOGIN_TOKEN FROM LOGIN_TOKEN WHERE 1=1";
                tokenInSqlTran = this.generateSql.sqlQuery(dbName, "LOGIN_TOKEN", new StringBuilder(Sql), Where);
                int lt = dbHelp.queryCount(dbName, tokenInSqlTran);
                if (lt == 0) {
                    return false;
                }
            } catch (Exception e) {
                log.error("数据处理出现异常! 异常原因:" + e);
                return false;
            }
        }
        return true;
    }

    /**
     * 加载角色缓存
     */
    @PostConstruct
    public void initCache() {
        setPageApi();
    }
}
