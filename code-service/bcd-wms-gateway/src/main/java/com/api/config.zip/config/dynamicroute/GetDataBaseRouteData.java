package com.api.config.dynamicroute;

import com.alibaba.cloud.commons.lang.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.DbHelpImpl;
import com.server.generate.GenerateSqlImpl;
import com.server.params.GenerateSqlTran;
import org.springframework.cloud.gateway.filter.FilterDefinition;
import org.springframework.cloud.gateway.handler.predicate.PredicateDefinition;
import org.springframework.cloud.gateway.route.RouteDefinition;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Collections.synchronizedMap;

/**
 * @author lw
 * @date: 2024/12/16
 * @description:
 **/
@Service
public class GetDataBaseRouteData {
    @Resource
    private DbHelpImpl dbHelp;
    @Resource
    private GenerateSqlImpl generateSql;

    public List<String> getRoute(Map<String, RouteDefinition> routes) throws Exception {

        List<GenerateSqlTran> sqlTranList = new ArrayList<>();
        GenerateSqlTran mst = new GenerateSqlTran("SELECT * FROM S_GATEWAY_ROUTE T WHERE 1=1  ORDER BY T.SORT_INDEX ASC");
        mst.setTableName("S_GATEWAY_ROUTE");
        sqlTranList.add(mst);

        GenerateSqlTran predicates = new GenerateSqlTran("SELECT * FROM S_GATEWAY_PREDICATES T WHERE 1=1  ORDER BY T.SORT_INDEX ASC");
        predicates.setTableName("S_GATEWAY_PREDICATES");
        sqlTranList.add(predicates);

        JSONObject data = dbHelp.queryTranJsonObject("project", sqlTranList);


        JSONArray routeArray = data.getJSONArray("S_GATEWAY_ROUTE");
        JSONArray predicatesArray = data.getJSONArray("S_GATEWAY_PREDICATES");
        List<String> disables=new ArrayList<>();
        if (routeArray.size() > 0) {

            for (int i = 0; i < routeArray.size(); i++) {
                JSONObject row = routeArray.getJSONObject(i);
                if(row.getString("ACTIVE").equals("1")){
                    this.setRoute(routes,row, predicatesArray,disables);
                }else {

                    JSONArray disable = new JSONArray(predicatesArray.stream().filter(item -> ((JSONObject) item).getString("ROUTE_KEY").equals(row.getString("ROUTE_KEY"))).collect(Collectors.toList()));
                    for (int t = 0; t < disable.size(); i++) {
                        disables.add(disable.getJSONObject(i).getString("ROUTE_PREDICATES_ID"));
                    }
                }

            }

        }
        return  disables;

    }

    private void setRoute(Map<String, RouteDefinition> routes, JSONObject mst, JSONArray predicatesArray, List<String> disables) {
        JSONArray predicates = new JSONArray(predicatesArray.stream().filter(item -> ((JSONObject) item).getString("ROUTE_KEY").equals(mst.getString("ROUTE_KEY"))).collect(Collectors.toList()));

        for (int i = 0; i < predicates.size(); i++) {
            JSONObject row = predicates.getJSONObject(i);
            if(row.getString("ACTIVE").equals("1")){
                RouteDefinition routeDef = new RouteDefinition();
                routeDef.setId(row.getString("ROUTE_PREDICATES_ID"));
                routeDef.setUri(URI.create(mst.getString("ROUTE_URI")));
                List<PredicateDefinition> predicateDefinitions = new ArrayList<>();
                PredicateDefinition definition = new PredicateDefinition(row.getString("ROUTE_PREDICATES"));
                predicateDefinitions.add(definition);
                if(!StringUtils.isBlank(mst.getString("ORG_KEY"))){
                    PredicateDefinition org = new PredicateDefinition("Header=org, ^"+mst.getString("ORG_KEY")+"$");
                    predicateDefinitions.add(org);
                }
                routeDef.setPredicates(predicateDefinitions);
                setFilters(routeDef);
                routeDef.setOrder(mst.getInteger("ORDER_INDEX"));
                routes.put(row.getString("ROUTE_PREDICATES_ID"), routeDef);
            }else {
                disables.add(row.getString("ROUTE_PREDICATES_ID"));
            }
        }
    }

    private void setFilters(RouteDefinition routeDef) {

        List<FilterDefinition> filterDefinitions = new ArrayList<>();
        FilterDefinition definition = new FilterDefinition("StripPrefix=1");
        filterDefinitions.add(definition);
        routeDef.setFilters(filterDefinitions);
    }
}
