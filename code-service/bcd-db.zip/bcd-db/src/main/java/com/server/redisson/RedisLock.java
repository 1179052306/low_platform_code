package com.server.redisson;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RedisLock {
    String value() default "";  // 锁的名字
    long timeout() default 3000;  // 锁的超时时间，单位：毫秒
    boolean fair() default false;  // 是否使用公平锁，默认非公平锁
    long waitTime() default 10000; // 等待锁的最大时间，单位：毫秒
}
