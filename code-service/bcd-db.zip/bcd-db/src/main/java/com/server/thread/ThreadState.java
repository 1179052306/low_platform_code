package com.server.thread;

/**
 * @author lw
 * @date: 2025/3/5
 * @description:
 **/
public class ThreadState {

    ThreadStateType threadStateType=ThreadStateType.notstart;

    ThreadStateType nowState=ThreadStateType.notstart;

    public ThreadStateType getThreadStateType() {
        return threadStateType;
    }

    public void setThreadStateType(ThreadStateType threadStateType) {
        this.threadStateType = threadStateType;
    }

    public ThreadStateType getNowState() {
        return nowState;
    }

    public void setNowState(ThreadStateType nowState) {
        this.nowState = nowState;
    }
}

