package com.server.data;

public class InternalDataCollectionBase {

    public  int Count =0;
}
