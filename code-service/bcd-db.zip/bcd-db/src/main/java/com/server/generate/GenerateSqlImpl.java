package com.server.generate;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.params.GenerateSqlTran;
import com.server.params.Rps;
import com.server.params.WhereValidate;
import com.server.params.Wheres;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Description SQL生成接口
 * @Author liwei
 * @Date 2023/7/26 10:02     
 **/
@Component
@Service
public interface GenerateSqlImpl {

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName);

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, JSONArray json);

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, JSONArray json, List<Rps> rpsList);

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param strSql
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, StringBuilder strSql, JSONArray json);

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param strSql
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, StringBuilder strSql, JSONArray json, List<Rps> rpsList);

    /**
     * SQL插入
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran executeInsert(@Nullable String dbName, String tableName, JSONObject json);

    /**
     * SQL插入
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran executeInsert(@Nullable String dbName, String tableName, JSONObject json, List<Object> masterMagic);

    /**
     * SQL修改
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listwhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran executeUpdate(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listwhere);

    /**
     * SQL修改
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listwhere
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran executeUpdate(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listwhere, List<Object> masterMagic);

    /**
     * SQL删除
     *
     * @param dbName
     * @param tableName
     * @param listwhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran executeDelete(@Nullable String dbName, String tableName, List<Wheres> listwhere);

    /**
     * SQL删除
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param listwhere
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeDelete(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<Wheres> listwhere);

    /**
     * SQL集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json);

    /**
     * SQL集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json, List<Object> masterMagic);

    /**
     * SQL集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @param listwhere
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json, List<Wheres> listwhere);

    /**
     * SQL集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @param listwhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json, List<Wheres> listwhere, List<Object> masterMagic);


    /**
     * SQL集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList);

    /**
     * SQL集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Object> masterMagic);

    /**
     * SQL集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param listwhere
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Wheres> listwhere);

    /**
     * SQL集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param listwhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void executeListUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Wheres> listwhere, List<Object> masterMagic);


    /**
     * 查询条件手动添加
     *
     * @param id
     * @param value
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray add(String id, String value);



    /**
     * 查询条件手动添加
     *
     * @param jsonArray
     * @param id
     * @param value
     * @author liwei
     * @date: 2023/7/26
     **/
    void add(JSONArray jsonArray, String id, String value);

    /**
     * 查询条件手动添加
     *
     * @param id
     * @param symbol
     * @param value
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray add( String id, String symbol,String value);


    /**
     * 查询条件手动添加
     *
     * @param jsonArray
     * @param id
     * @param symbol
     * @param value
     * @author liwei
     * @date: 2023/7/26
     **/
    void add(JSONArray jsonArray,  String id, String symbol,String value);


    /**
     * 查询条件手动添加
     *
     * @param id
     * @param value
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray addContainAlias(String id, String value,String TableAlias);



    /**
     * 查询条件手动添加
     *
     * @param jsonArray
     * @param id
     * @param value
     * @author liwei
     * @date: 2023/7/26
     **/
    void addContainAlias(JSONArray jsonArray, String id, String value,String TableAlias);

    /**
     * 查询条件手动添加
     *
     * @param id
     * @param symbol
     * @param value
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray addContainAlias( String id, String symbol,String value,String TableAlias);


    /**
     * 查询条件手动添加
     *
     * @param jsonArray
     * @param id
     * @param symbol
     * @param value
     * @author liwei
     * @date: 2023/7/26
     **/
    void addContainAlias(JSONArray jsonArray,  String id, String symbol,String value,String TableAlias);

    /**
     * 查询条件后台手动验证字段是否合法
     *
     * @param json
     * @param whereValidates
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    boolean validateQuery(JSONArray json, List<WhereValidate> whereValidates);

    /**
     * 检查参数字段是否合法
     *
     * @param column
     * @param generateSqlTran
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    boolean checkParameter(String column, GenerateSqlTran generateSqlTran);
}
