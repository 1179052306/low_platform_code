package com.server.thread.hand;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.DbComposite;
import com.server.thread.ThreadBase;
import com.server.thread.ThreadStateType;
import com.server.thread.ThreadsObject;
import com.server.thread.table.ThreadTable;
import com.server.thread.table.ThreadTableBusiness;
import com.server.thread.table.ThreadTableBusinessCallback;

import java.util.Map;

/**
 * @author lw
 * @date: 2025/3/6
 * @description:
 **/
public class ThreadHandBusinessExecute {

    public   static void businessMain(String tenantId,   ThreadHandBusiness threadHandBusiness, Map<String, ThreadsObject> threadsObjectMap) throws Exception {

        String threadName=threadHandBusiness.threadName;

        String project = threadHandBusiness.project;

        DbComposite dbComposite= threadHandBusiness.dbComposite;

        ThreadHandBusinessCallback threadHandBusinessCallback = threadHandBusiness.threadHandBusinessCallback;

        if (threadsObjectMap.get(tenantId+threadName) == null) {
            ThreadsObject threadsObject = new ThreadsObject(tenantId+threadName, dbComposite, project);
            threadsObject.setSleep(60000);
            threadsObject.setTenantId(tenantId);
            if(threadHandBusiness.threadTable!=null){
                threadsObject.setThreadTable(threadHandBusiness.threadTable);
            }
            ThreadBase threadBase = threadHandBusinessCallback.externalMethod(threadsObject);
            threadsObject.setThread(threadBase);
            threadsObjectMap.put(tenantId + threadName, threadsObject);
            threadsObject.getThread().start();
        }
    }

    public   static void businessMain(ThreadHandBusiness threadHandBusiness,Integer sleep) throws Exception {
        ThreadHandBusinessCallback threadHandBusinessCallback = threadHandBusiness.threadHandBusinessCallback;
        ThreadsObject threadsObject = new ThreadsObject();
        threadsObject.setSleep(sleep);
        if(threadHandBusiness.threadTable!=null){
            threadsObject.setThreadTable(threadHandBusiness.threadTable);
        }
        ThreadBase threadBase = threadHandBusinessCallback.externalMethod(threadsObject);
        threadsObject.setThread(threadBase);
        threadsObject.getThread().start();
    }
}
