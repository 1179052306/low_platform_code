package com.server.getdata;

import com.alibaba.fastjson.JSONObject;
import com.server.db.DbConfig;
import com.server.params.DataParameter;
import com.server.params.DbCustomParameter;
import com.server.params.GenerateSqlTran;
import com.server.syntax.gridpage.DmGetTable;
import com.server.syntax.gridpage.OracleGetTable;
import com.server.syntax.gridpage.PostgresSqlGetTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Description  获取前端表格分页查询格式的数据源
 * @Author liwei
 * @Date 2023/7/26 10:10     
 **/
@Service
@Component
public class GetTableData {

    @Resource
    DbConfig dbConfig;

    @Resource
    OracleGetTable oracleGetTable;
    @Resource
    DmGetTable dmGetTable;
    @Resource
    PostgresSqlGetTable postgresSqlGetTable;

    /**
     * 获取数据
     *
     * @param dataSqlTran
     * @param dataParameter
     * @param tableAttribute
     * @return JSONObject
     * @author liwei
     * @date: 2023/7/26
     **/
    public JSONObject getData(GenerateSqlTran dataSqlTran, DataParameter dataParameter, TableAttribute tableAttribute, DbCustomParameter dbCustomParameter) throws Exception {

        JSONObject jsonObject = new JSONObject();
        String Type = dbConfig.getType(dataSqlTran.getDbName());
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            jsonObject = oracleGetTable.getData(dataSqlTran, dataParameter, tableAttribute,dbCustomParameter);

        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            jsonObject = postgresSqlGetTable.getData(dataSqlTran, dataParameter, tableAttribute,dbCustomParameter);

        }
        if (Type.equals("4")) {


            jsonObject = dmGetTable.getData(dataSqlTran, dataParameter, tableAttribute,dbCustomParameter);

        }
        return jsonObject;

    }

    public JSONObject getReportData(GenerateSqlTran dataSqlTran, String primaryColumn, DataParameter dataParameter,TableAttribute tableAttribute, DbCustomParameter dbCustomParameter) throws Exception {

        JSONObject jsonObject = new JSONObject();
        String Type = dbConfig.getType(dataSqlTran.getDbName());
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            jsonObject = oracleGetTable.getReportData(dataSqlTran,  primaryColumn, dataParameter, tableAttribute,dbCustomParameter);

        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            jsonObject = postgresSqlGetTable.getReportData(dataSqlTran,  primaryColumn, dataParameter,tableAttribute, dbCustomParameter);

        }
        if (Type.equals("4")) {

            jsonObject = dmGetTable.getReportData(dataSqlTran,  primaryColumn, dataParameter, tableAttribute,dbCustomParameter);

        }
        return jsonObject;

    }
}
