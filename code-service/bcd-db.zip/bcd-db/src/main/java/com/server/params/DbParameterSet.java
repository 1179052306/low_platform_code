package com.server.params;

import com.server.syntax.DbConvertSql;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


/**
 * @Description 字段参数化设置 ，并根据相关类型进行赋值
 * @Author liwei
 * @Date 2023/7/26 10:15
 **/
@Service
public class DbParameterSet {

    @Resource
    private DbConvertSql dbConvertSql;

    /**
     * 字段类型赋值
     *
     * @param dbName
     * @param dbParameter
     * @param Paramter
     * @param ParamterColumnTypeString
     * @param ParamterColumnSizeString
     * @param Val
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public boolean setVal(@Nullable String dbName, DbParameter dbParameter, String Paramter, String ParamterColumnTypeString,
                          String ParamterColumnSizeString, Object Val) throws Exception {
        boolean result = true;
        try {
            if (ParamterColumnSizeString.length() > 0)//判断数据大小
            {
                int Size = Integer.parseInt(ParamterColumnSizeString);//转换数据大小

                dbParameter.setParameterSize(Size);

            }
            dbParameter.setParameterVal(null);


            try {
                setDbType(dbName, dbParameter, ParamterColumnTypeString, Val);
            } catch (Exception ex) {


            }

        } catch (Exception ex) {

            result = false;

        }
        return result;
    }

    /**
     * sql 拼接
     *
     * @param dbName
     * @param Sql
     * @param ListParamter
     * @param StrSql
     * @param ParamterName
     * @param Symbol
     * @param DbType
     * @param ParamterColumnSizeString
     * @param IsLook
     * @param Value
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public boolean setStrSql(@Nullable String dbName, String Sql, List<DbParameter> ListParamter, StringBuilder StrSql, String ParamterName, String Symbol, String DbType, String ParamterColumnSizeString, Object IsLook, String Value, String TableAlias)
            throws Exception {
        boolean result = true;
        try {
            if (Sql != null) {
//                if (Symbol.contains("not") || Symbol.contains("<>")) {
//                    Sql = " NOT " + Sql;
//                }

//                if (Symbol.contains("not") || Symbol.contains("<>")) {
//                    Symbol = Symbol.replace("not", "");
//                    Symbol = Symbol.replace("<>", "=");
//                }
            }
            String KeyString = DbParmentReplace.getString(TableAlias + ParamterName);
            DbParameter dbParameter = new DbParameter();
            if (Symbol.contains("Exist")) {

                String replaceStrSql = "";

                String sqlStr = "";
                if (Symbol.contains("Not")) {
                    sqlStr = " Not ";
                }
                String prefixString = TableAlias + ParamterName;
//                String prefixString = "T." + ParamterName;
                if (StrSql.toString().contains(KeyString)) {
                    prefixString = TableAlias + ParamterName;
                }
                dbParameter.setParamenterType(ParamenterType.DOUBLE);
                if (DbType.equals("NUMBER")) {

                    //StrSql.append(sqlStr + " IN( SELECT TAB.COLUMNNAME_NUM FROM M_SEARCH_DATA TAB  WHERE 1=1 AND TAB.SEARCH_DATA_KEY=" + "?"  + "  AND  TAB.COLUMNNAME_NUM = T." + ParamterName +" AND TAB.COLUMNNAME_NUM IS NOT NULL)  ");////需要配置的字符串添加字段
//                    " + TableAlias + ParamterName + "

                    replaceStrSql = prefixString + sqlStr + " IN( SELECT TAB.COLUMNNAME_NUM FROM M_SEARCH_DATA TAB  WHERE 1=1 AND TAB.SEARCH_DATA_KEY=" + "?" + " AND TAB.COLUMNNAME_NUM IS NOT NULL)  ";
//                    StrSql.append("T." + ParamterName + sqlStr + " IN( SELECT TAB.COLUMNNAME_NUM FROM M_SEARCH_DATA TAB  WHERE 1=1 AND TAB.SEARCH_DATA_KEY=" + "?" + " AND TAB.COLUMNNAME_NUM IS NOT NULL)  ");////需要配置的字符串添加字段

                } else {

                    //StrSql.append(sqlStr + " IN( SELECT TAB.COLUMNNAME_VAR FROM M_SEARCH_DATA TAB  WHERE 1=1 AND TAB.SEARCH_DATA_KEY=" + "?"  + "  AND  TAB.COLUMNNAME_VAR = T." + ParamterName +" AND TAB.COLUMNNAME_VAR IS NOT NULL)  ");////需要配置的字符串添加字段
                    replaceStrSql = prefixString + sqlStr + " IN( SELECT TAB.COLUMNNAME_VAR FROM M_SEARCH_DATA TAB  WHERE 1=1 AND TAB.SEARCH_DATA_KEY=" + "?" + " AND TAB.COLUMNNAME_VAR IS NOT NULL)  ";
//                    StrSql.append("T." + ParamterName + sqlStr + " IN( SELECT TAB.COLUMNNAME_VAR FROM M_SEARCH_DATA TAB  WHERE 1=1 AND TAB.SEARCH_DATA_KEY=" + "?" + " AND TAB.COLUMNNAME_VAR IS NOT NULL)  ");////需要配置的字符串添加字段

                }
                if (StrSql.toString().contains(KeyString)) {
                    int indexNum = 0;

                    while ((indexNum = StrSql.toString().indexOf(KeyString, indexNum)) != -1) {
                        int index = indexNum;
                        index = index + KeyString.length();

                        StrSql.insert(index, " AND " + replaceStrSql);
                        indexNum = indexNum + KeyString.length();
                    }
                } else {
                    StrSql.append(replaceStrSql);

                }
                dbParameter.setParameterName(ParamterName);
                dbParameter.setParameterVal(Value);
                ListParamter.add(dbParameter);
                return result;
            }

            if (StrSql.toString().contains(KeyString)) {
                int indexNum = 0;

                while ((indexNum = StrSql.toString().indexOf(KeyString, indexNum)) != -1) {
                    int index = indexNum;
                    index = index + KeyString.length();

                    if (DbType.equals("DATETIME") || DbType.equals("DATE"))//判断数据类型
                    {

                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        try {
                            Date date = dateFormat.parse(Value);

                            StrSql.insert(index, " AND " + TableAlias + ParamterName + " " + Symbol + " " + " " + Value + " ");
                            StrSql.replace(indexNum,index,"");
                        } catch (Exception ex) {
                            throw new Exception(Value + "数据不合法，日期格式转换失败");
                        }

                    } else {

                        StrSql.insert(index, " AND " + TableAlias + ParamterName + " " + Symbol + " " + "?");
                        StrSql.replace(indexNum,index,"");
                        setDbType(dbName, dbParameter, DbType, Value);
                        dbParameter.setParameterName(ParamterName);
                        ListParamter.add(dbParameter);
                    }
                    indexNum = indexNum + KeyString.length();
                    break;
                }
            } else {

                if (DbType.equals("DATETIME") || DbType.equals("DATE"))//判断数据类型
                {
                    dbParameter.setParameterName(ParamterName);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    StrSql.append(ParamterName);////需要配置的字符串添加字段
                    StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                    try {
                        StrSql.append(" ? ");////需要配置的字符串添加关键词
                        setDbType(dbName, dbParameter, DbType, Value);

                        ListParamter.add(dbParameter);

                    } catch (Exception ex) {
                        throw new Exception(Value + "数据不合法，日期格式转换失败");
                    }
                } else {
                    dbParameter.setParameterName(ParamterName);
                    if (IsLook == null) {
                        if (Sql != null) {
                            if (Symbol.contains("like")) {
                                Sql = MessageFormat.format(Sql, " " + Symbol + " ", "'%'|| " + "?" + " ||'%'");////初始化

                            } else {
                                Sql = MessageFormat.format(Sql, " " + Symbol + " ", "?");////初始化
                            }
                            StrSql.append(Sql);
                        } else {
                            if (Symbol.contains("like")) {
                                if (DbType.contains("NUMBER"))//判断数据类型
                                {
                                    StrSql.append(" NVL(" + TableAlias + ParamterName + ",-1) ");////需要配置的字符串添加字段
                                    StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                    StrSql.append("?");////需要配置的字符串添加参数变量
                                }
                                if (DbType.equals("CHAR"))//判断数据类型
                                {
                                    StrSql.append("NVL(TRIM(" + TableAlias + ParamterName + "),' ')");////需要配置的字符串添加字段
                                    StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                    StrSql.append("'%'|| ");////需要配置的字符串添加关键词
                                    StrSql.append("?");////需要配置的字符串添加参数变量
                                    StrSql.append(" ||'%'");////需要配置的字符串添加关键词
                                }else{
                                    if (DbType.contains("VARCHAR"))//判断数据类型
                                    {
                                        StrSql.append("NVL(" + TableAlias + ParamterName + ",' ')");////需要配置的字符串添加字段
                                        StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                        StrSql.append("'%'|| ");////需要配置的字符串添加关键词
                                        StrSql.append("?");////需要配置的字符串添加参数变量
                                        StrSql.append(" ||'%'");////需要配置的字符串添加关键词
                                    }
                                }


                            } else if (Symbol.contains("or")) {
                                StrSql.append("'('|| ");////需要配置的字符串添加关键词
                                StrSql.append("NVL(" + TableAlias + ParamterName + ",' ')");////需要配置的字符串添加字段
                                StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                StrSql.append("?");////需要配置的字符串添加参数变量
                                StrSql.append(" ||')'");////需要配置的字符串添加关键词
                            } else if (Symbol.contains("<>")) {
                                if (DbType.equals("CHAR"))//判断数据类型
                                {
                                    StrSql.append(" NVL(TRIM(" + TableAlias + ParamterName + "),' ') ");////需要配置的字符串添加字段
                                    StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                    StrSql.append("?");////需要配置的字符串添加参数变量
                                }else{
                                    if (DbType.contains("VARCHAR"))//判断数据类型
                                    {
                                        StrSql.append(" NVL(" + TableAlias + ParamterName + ",' ') ");////需要配置的字符串添加字段
                                        StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                        StrSql.append("?");////需要配置的字符串添加参数变量
                                    }

                                    if (DbType.equals("CLOB"))//判断数据类型
                                    {
                                        StrSql.append(" NVL(TO_CHAR(" + TableAlias + ParamterName + "),' ') ");////需要配置的字符串添加字段
                                        StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                        StrSql.append("?");////需要配置的字符串添加参数变量
                                    }

                                    if (DbType.equals("NUMBER"))//判断数据类型
                                    {
                                        StrSql.append(" NVL(" + TableAlias + ParamterName + ",-1) ");////需要配置的字符串添加字段
                                        StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                        StrSql.append("?");////需要配置的字符串添加参数变量
                                    }
                                }


                            } else {
                                if (DbType.equals("CLOB"))//判断数据类型
                                {
                                    StrSql.append(" NVL(TO_CHAR(" + TableAlias + ParamterName + "),' ') ");////需要配置的字符串添加字段
                                    StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                    StrSql.append("?");////需要配置的字符串添加参数变量
                                } else {
                                    if (DbType.equals("CHAR"))//判断数据类型
                                    {
                                        StrSql.append(" NVL(TRIM(" + TableAlias + ParamterName + "),' ') ");////需要配置的字符串添加字段
                                        StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                        StrSql.append("?");////需要配置的字符串添加参数变量
                                    }else{
                                        StrSql.append(" " + TableAlias + ParamterName + " ");////需要配置的字符串添加字段
                                        StrSql.append(" " + Symbol + " ");////需要配置的字符串添加关键词
                                        StrSql.append("?");////需要配置的字符串添加参数变量
                                    }

                                }
                            }
                        }
                        setDbType(dbName, dbParameter, DbType, Value);

                        ListParamter.add(dbParameter);
                    } else {

                        dbParameter.setParamenterType(ParamenterType.VARCHAR);

                        dbConvertSql.splitStrSql(dbName, TableAlias,Symbol,  ParamterName, DbType, StrSql);
//                        if (Symbol.equals("="))
//                        {
//                            StrSql.append("  EXISTS(   SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?"  + ",','))TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段
//                        }
//                        else
//                        {
//                            StrSql.append(" NOT EXISTS(   SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?"  + ",','))TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段
//                        }
                        dbParameter.setParameterName(ParamterName);
                        dbParameter.setParameterVal(Value);
                        ListParamter.add(dbParameter);
                    }

                }

            }

        } catch (Exception ex) {
            result = false;
            throw new Exception("setStrSql 执行失败：" + ex.toString());
        }
        return result;
    }


    /**
     * 字段数据库类型读取，并根据传入值进行转换重新赋值
     *
     * @param dbName
     * @param dbParameter
     * @param ParamterColumnTypeString
     * @param Val
     * @author liwei
     * @date: 2023/7/26
     **/
    public void setDbType(@Nullable String dbName, DbParameter dbParameter, String ParamterColumnTypeString,
                          Object Val) throws Exception {

        Object ResultVal = null;
        switch (ParamterColumnTypeString) {
            case "VARCHAR":
            case "VARCHAR2":
                dbParameter.setParamenterType(ParamenterType.VARCHAR);
                if (Val != null) {
                    ResultVal = Val.toString();
                    dbParameter.setParameterVal(ResultVal);
                }
                break;
            case "CHAR":
                dbParameter.setParamenterType(ParamenterType.CHAR);
                if (Val != null) {
                    ResultVal = Val.toString().trim();
                    dbParameter.setParameterVal(ResultVal);
                }
                break;
            case "NUMBER":
                dbParameter.setParamenterType(ParamenterType.DOUBLE);
                if (Val != null) {
                    try {
                        if (StringUtils.isEmpty(Val)) {
                            ResultVal = null;
                        } else {
                            ResultVal = new BigDecimal(Val.toString());
                        }

                    } catch (Exception ex) {
                        throw new Exception(Val + "数据不合法，数字转换失败");
                    }
                    dbParameter.setParameterVal(ResultVal);
                }
                break;
            case "DOUBLE":
                dbParameter.setParamenterType(ParamenterType.DOUBLE);
                if (Val != null) {
                    try {
                        if (StringUtils.isEmpty(Val)) {
                            ResultVal = null;
                        } else {
                            ResultVal = new BigDecimal(Val.toString());
                        }

                    } catch (Exception ex) {
                        throw new Exception(Val + "数据不合法，数字转换失败");
                    }
                    dbParameter.setParameterVal(ResultVal);
                }
                break;
            case "TIMESTAMP":
            case "DATE":
                dbParameter.setParamenterType(ParamenterType.DATE);
                if (Val != null && !Val.toString().equals("")) {
                    if (Val.toString().length() <= 10) {
                        Val= Val.toString()+" 00:00:00";
                    }
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    try {
                        if(Val.toString().contains("T")){
                            SimpleDateFormat dateFormatT=null;
                            if(Val.toString().contains(".")){
                                dateFormatT=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.");
                            }else{
                                dateFormatT=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                            }
                            Date date= dateFormatT.parse(Val.toString());
                            String time = dateFormat.format(date);
                            Val = time;
                            ResultVal=Val;
                        }else {

                            if(Val.toString().length()>20){
                                SimpleDateFormat dateFormatd=null;
                                if(Val.toString().contains(".")){
                                    dateFormatd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.");
                                }else{
                                    dateFormatd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                }
                                Date date= dateFormatd.parse(Val.toString());
                                String time = dateFormat.format(date);
                                Val = time;
                                ResultVal=Val;
                            }else{
                                Date date=dateFormat.parse(Val.toString());
                                ResultVal = dateFormat.format(date);;
                            }

                        }
                    } catch (Exception ex) {
                        throw new Exception(Val + "数据不合法，日期格式转换失败");
                    }

                    dbParameter.setParameterVal(ResultVal);
                }else{
                    dbParameter.setParameterVal(null);
                }
                break;
            case "NCLOB":
            case "BLOB":
            case "CLOB":
                dbParameter.setParamenterType(ParamenterType.CLOB);
                if (Val != null) {
                    ResultVal = Val;
                    dbParameter.setParameterVal(ResultVal);
                }
                break;
            case "BOOL":
                dbParameter.setParamenterType(ParamenterType.BOOL);
                if (Val != null) {
                    ResultVal = Val;
                    dbParameter.setParameterVal(ResultVal);
                }
                break;
            case "BYTEA":
                dbParameter.setParamenterType(ParamenterType.BYTEA);
                if (Val != null) {
                    ResultVal = Val;
                    dbParameter.setParameterVal(ResultVal);
                }
                break;
        }


    }

    /**
     * 字段数据库类型读取，并根据传入值进行转换重新赋值
     *
     * @param ParamterColumnTypeString
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getDbType(String ParamterColumnTypeString
    )  {


        String type = "";
        switch (ParamterColumnTypeString.toUpperCase(Locale.ROOT)) {
            case "VARCHAR":
                type = "VARCHAR";
                break;
            case "VARCHAR2":
                type = "VARCHAR";
                break;
            case "CHAR":
                type = "VARCHAR";
                break;
            case "NUMBER":
                type = "NUMBER";
                break;
            case "DOUBLE":
                type = "NUMBER";
                break;
            case "NUMERIC":
                type = "NUMBER";
                break;
            case "TIMESTAMP":
                type = "DATE";
                break;
            case "DATE":
                type = "DATE";
                break;
            case "BLOB":
                break;
            case "CLOB":
                break;
            case "BOOL":
                break;
            case "BYTEA":
                break;
        }

        return type;

    }
}




