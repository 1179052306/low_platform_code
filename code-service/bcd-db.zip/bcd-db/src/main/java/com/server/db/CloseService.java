package com.server.db;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.params.GenerateSqlTran;
import com.server.thread.ThreadBase;
import com.server.thread.ThreadsObject;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author lw
 * @date: 2025/1/8
 * @description:
 **/

@Slf4j
public class CloseService extends ThreadBase {


    private ThreadsObject threadsObject;

    public CloseService(ThreadsObject threadsObject) {
        super(threadsObject);
        this.threadsObject = threadsObject;

    }

    @Override
    public void execute() throws Exception {
        try {
            if (MultiDataSource.oldDataSources.size() > 0) {

                for (String key : MultiDataSource.oldDataSources.keySet()) {
                    HikariDataSource oldHikari = MultiDataSource.oldDataSources.get(key);
                    try {
                        if(oldHikari.getHikariPoolMXBean()==null){
                            oldHikari.close();
                            MultiDataSource.oldDataSources.remove(key);
                            continue;
                        }
                        // 获取连接池的活跃连接数
                        int totalConnections = oldHikari.getHikariPoolMXBean().getTotalConnections();
                        int idleConnections = oldHikari.getHikariPoolMXBean().getIdleConnections();
                        int activeConnections = totalConnections - idleConnections;
                        if(activeConnections ==0){
                            oldHikari.close();
                            MultiDataSource.oldDataSources.remove(key);
                        }
                    } catch (Exception e) {

                    }
                }

            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

    }


}
