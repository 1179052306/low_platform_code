package com.server.params;

/**
 * @author lw
 * @date: 2025/5/22
 * @description:
 **/
public class SqlRestrictionsInfo {
    boolean res=true;
    String errInfo="";

    public boolean isRes() {
        return res;
    }

    public void setRes(boolean res) {
        this.res = res;
    }

    public String getErrInfo() {
        return errInfo;
    }

    public void setErrInfo(String errInfo) {
        this.errInfo = errInfo;
    }
}
