package com.server.params;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @Description SQL查询配置类
 * @Author liwei
 * @Date 2023/7/26 10:11
 **/
@Component
public class DataParameter implements Serializable {

    private boolean isOrg = false;////组织数据权限

    private boolean isAllOrg = false;////组织数据权限

    private boolean isWh = false;////仓库数据权限

    private boolean serverPage = true;////数据库分页

    private String orderByString = "";////自定义排序

    private boolean isConsignor = false;////货主数据权限

    private boolean isOrderType = false;////单据数据权限

    private boolean defaultOrderby = true;///默认排序，默认字段CREATE_DATE DESC

    private Boolean useCustomSql = true;

    private boolean isTranSport = false;////承运商数据权限

    public boolean isTranSport() {
        return isTranSport;
    }

    public void setTranSport(boolean tranSport) {
        isTranSport = tranSport;
    }

    private String customSql = null;////组织数据权限
    public boolean isWh() {
        return isWh;
    }

    public void setWh(boolean wh) {
        isWh = wh;
    }

    public boolean isOrg() {
        return isOrg;
    }

    public void setOrg(boolean org) {
        isOrg = org;
    }

    public boolean isAllOrg() {
        return isAllOrg;
    }
    public String getCustomSql() {
        return customSql;
    }

    public void setCustomSql(String customSql) {
        this.customSql = customSql;
    }
    public void setAllOrg(boolean allOrg) {
        isAllOrg = allOrg;
    }

    public boolean isServerPage() {
        return serverPage;
    }

    public void setServerPage(boolean serverPage) {
        this.serverPage = serverPage;
    }

    public boolean isConsignor() {
        return isConsignor;
    }

    public void setConsignor(boolean consignor) {
        isConsignor = consignor;
    }

    public String getOrderByString() {
        return orderByString;
    }

    public void setOrderByString(String orderByString) {
        this.defaultOrderby = false;
        this.orderByString = orderByString;
    }

    public boolean isOrderType() {
        return isOrderType;
    }

    public void setOrderType(boolean orderType) {
        isOrderType = orderType;
    }

    public boolean isDefaultOrderby() {
        return defaultOrderby;
    }

    public void setDefaultOrderby(boolean defaultOrderby) {
        this.defaultOrderby = defaultOrderby;
    }

    /**
     * 是否启用自定义条件追加的sql语句
     */
    public Boolean isUseCustomSql() {
        return useCustomSql;
    }

    public void setUserCustomSql(Boolean userCustomSql) {
        this.useCustomSql = userCustomSql;
    }


}
