package com.server.params;

/**
 * @author lw
 * @date: 2025/2/21
 * @description:
 **/
public class JdbcSqlModel {

    public JdbcSqlModel(String alias, String sql) {
        this.alias = alias;
        this.sql = sql;
    }

    String alias;
    String sql;


    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }
}
