package com.server.thread;

import java.util.HashMap;
import java.util.Map;

/**
 * @author lw
 * @date: 2025/3/5
 * @description:
 **/
public class ThreadsManage {

    Map<String, ThreadsObject> threadsObjectMap=new HashMap<>();

}
