package com.server.params;

import org.dom4j.Document;

/**
 * @Author
 * @Date 2022/11/17 10:54
 */
public class DocumentXml{

    public Document getDoc() {
        return doc;
    }

    public void setDoc(Document doc) {
        this.doc = doc;
    }

    private Document doc;
}
