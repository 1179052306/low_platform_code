package com.server.generate;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.params.*;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

@Component
@Service
public interface CommonImpl {

    /**
     * 插入生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran insert(@Nullable String dbName, String tableName, JSONObject json);

    /**
     * 插入生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran insert(@Nullable String dbName, String tableName, JSONObject json, List<Object> masterMagic);

    /**
     * 插入生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param documentXml
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran insert(@Nullable String dbName, String tableName, JSONObject json, DocumentXml documentXml, List<Object> masterMagic);

    /**
     * 修改生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listWhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran update(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listWhere);

    /**
     * 修改生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listWhere
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran update(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listWhere, List<Object> masterMagic);

    /**
     * 修改生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param documentXml
     * @param listWhere
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran update(@Nullable String dbName, String tableName, JSONObject json, DocumentXml documentXml, List<Wheres> listWhere, List<Object> masterMagic);

    /**
     * 删除生成
     *
     * @param dbName
     * @param tableName
     * @param documentXml
     * @param listWhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran delete(@Nullable String dbName, String tableName, DocumentXml documentXml, List<Wheres> listWhere);

    /**
     * 删除生成
     *
     * @param dbName
     * @param tableName
     * @param listWhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran delete(@Nullable String dbName, String tableName, List<Wheres> listWhere);

    /**
     * 集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, List<Object> masterMagic);

    /**
     * 集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param docparament
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, DocumentXml docparament, List<Object> masterMagic);


    /**
     * 集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param listWhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, List<Wheres> listWhere, List<Object> masterMagic);

    /**
     * 集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param documentXml
     * @param listWhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, DocumentXml documentXml, List<Wheres> listWhere, List<Object> masterMagic);
    /**
     * 集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Object> masterMagic);

    /**
     * 集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param docparament
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, DocumentXml docparament, List<Object> masterMagic);


    /**
     * 集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param listWhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Wheres> listWhere, List<Object> masterMagic);

    /**
     * 集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param documentXml
     * @param listWhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, DocumentXml documentXml, List<Wheres> listWhere, List<Object> masterMagic);

    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName);

    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName, JSONArray json);

    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName, JSONArray json, List<Rps> rpsList);

    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @param strSql
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName, StringBuilder strSql, JSONArray json, List<Rps> rpsList);

     boolean checkParameter(String column, GenerateSqlTran generateSqlTran) ;
}
