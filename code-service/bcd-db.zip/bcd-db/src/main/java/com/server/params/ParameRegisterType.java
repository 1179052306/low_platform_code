package com.server.params;

/**
 * @Description 加密类型
 * @Author liwei
 * @Date 2023/7/26 10:23
 **/
public enum ParameRegisterType {
    in(1),
    out(0),
    in_and_out(2);
    private int registerType;


    ParameRegisterType(int registerType){

        this.registerType=registerType;
    }

    public int getRegisterType() {
        return registerType;
    }

    public void setRegisterType(int registerType) {
        this.registerType = registerType;
    }
}
