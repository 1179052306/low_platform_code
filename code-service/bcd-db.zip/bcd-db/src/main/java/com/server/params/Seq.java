package com.server.params;

import java.util.List;

/**
 * @author lw
 * @date: 2023/12/26
 * @description:
 **/
public class Seq {
    public Seq(String table, Integer num){
        this.table=table;
        this.num=num;
    }
    Integer num;

    String table;

    List<Long> seqList;

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public List<Long> getSeqList() {
        return seqList;
    }

    public void setSeqList(List<Long> seqList) {
        this.seqList = seqList;
    }
}
