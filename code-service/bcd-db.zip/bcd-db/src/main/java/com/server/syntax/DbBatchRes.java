package com.server.syntax;

import com.server.db.DbConfig;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Description 数据库执行处理结果，由于不同数据库在批量处理是返回的数据代码不一样，这里要根据不同数据库重新解析
 * @Author liwei
 * @Date 2023/7/26 10:49
 **/
@Service
public class DbBatchRes {
    @Resource
    DbConfig dbConfig;

    /**
     * 数据库执行处理结果
     *
     * @param dbName
     * @param num
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    public int batchRes(@Nullable String dbName, int[] num) {

        int res = 0;
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            for (int j = 0; j < num.length; j++) {
                if (num[j] == -2||num[j]==1) {
                    res += 1;
                } else {
                    res = 0;

                    break;
                }
            }

        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            for (int j = 0; j < num.length; j++) {
                if (num[j] == 1) {
                    res += 1;
                } else {
                    res = 0;

                    break;
                }
            }
        }
        if (Type.equals("4")) {

            for (int j = 0; j < num.length; j++) {
                if (num[j] == -2||num[j]==1) {
                    res += 1;
                } else {
                    res = 0;

                    break;
                }
            }

        }
        return res;

    }
}
