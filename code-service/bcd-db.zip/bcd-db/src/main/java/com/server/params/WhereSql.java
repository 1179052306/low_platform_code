package com.server.params;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * @Description 添加Wheren可执行格式
 * @Author liwei
 * @Date 2023/7/26 10:34
 **/
public class WhereSql {

    public void add(JSONArray jsonArray, String Id, String Value,String TableAlias) {
        add(jsonArray, "=", Id, Value,TableAlias);
    }

    public void add(JSONArray jsonArray, String Symbol1Str, String Id, String Value,String TableAlias) {
        if (jsonArray == null) {
            jsonArray = new JSONArray();
        }
        JSONObject Symbol1 = new JSONObject();
        Symbol1.put("Symbol", "and");
        jsonArray.add(Symbol1);
        JSONObject Val = new JSONObject();
        Val.put("Id", Id);
        Val.put("Symbol", Symbol1Str);
        Val.put("Val", Value);
        Val.put("TableAlias", TableAlias);
        jsonArray.add(Val);
    }

    public boolean validate(JSONArray jsonArray, List<WhereValidate> whereValidates) {

        boolean res = true;
        if (jsonArray == null) {

            errWhereValidate(whereValidates);
            return  false;
        }
        if (jsonArray.size()==0) {

            errWhereValidate(whereValidates);
            return  false;
        }
        for (int j = 0; j < whereValidates.size(); j++) {
            String column = whereValidates.get(j).getColumnName();
            if (!whereValidates.get(j).isNull()) {
                if (jsonArray.size() > 0) {
                    String Val = "";
                    for (int i = 0; i < jsonArray.size(); i++) {
                        if (i % 2 > 0) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            if (column.equals(jsonObject.get("Id").toString())) {
                                Val = jsonObject.get("Val").toString();

                            }

                        }
                    }
                    if (StringUtils.isEmpty(Val)) {
                        whereValidates.get(j).setRes(false);
                        whereValidates.get(j).setMsg("字段" + column + "不能为空！");
                        res = false;
                    }

                } else {
                    whereValidates.get(j).setRes(false);
                    whereValidates.get(j).setMsg("字段" + column + "不能为空！");
                    res = false;
                }
            }
        }
        return res;

    }
    public void errWhereValidate( List<WhereValidate> whereValidates) {

        for (int j = 0; j < whereValidates.size(); j++) {
            String column = whereValidates.get(j).getColumnName();
            if (!whereValidates.get(j).isNull()) {
                whereValidates.get(j).setRes(false);
                whereValidates.get(j).setMsg("字段" + column + "不能为空！");
            }
        }

    }
}
