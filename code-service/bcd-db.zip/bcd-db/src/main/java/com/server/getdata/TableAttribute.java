package com.server.getdata;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Component;

/**
 * @Description 表格属性相关值
 * @Author liwei
 * @Date 2023/7/26 10:16
 **/
@Component
public class TableAttribute {
    int skip = 0;///默认设置为第一页
    int take = 15;///默认设置为一页15行
    int begin=0;
    int end=0;
    JSONObject sort=null;
    JSONArray totalSummary=null;
    int jurisdiction_key=-1;
    int org_key=-1;
    long user_key=-1;
    boolean isLoadingAll=false;

    public boolean getIsLoadingAll() {
        return isLoadingAll;
    }

    public void setIsLoadingAll(boolean isLoadingAll) {
        this.isLoadingAll = isLoadingAll;
    }

    public int getBegin() {
        return begin;
    }

    public void setBegin(int begin) {
        this.begin = begin;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }


    public int getSkip() {
        return skip;
    }

    public void setSkip(int skip) {
        this.skip = skip;
    }

    public int getTake() {
        return take;
    }

    public void setTake(int take) {
        this.take = take;
    }

    public JSONObject getSort() {
        return sort;
    }

    public void setSort(JSONObject sort) {
        this.sort = sort;
    }

    public JSONArray getTotalSummary() {
        return totalSummary;
    }

    public void setTotalSummary(JSONArray totalSummary) {
        this.totalSummary = totalSummary;
    }

    public int getJurisdiction_key() {
        return jurisdiction_key;
    }

    public void setJurisdiction_key(int jurisdiction_key) {
        this.jurisdiction_key = jurisdiction_key;
    }

    public int getOrg_key() {
        return org_key;
    }

    public void setOrg_key(int org_key) {
        this.org_key = org_key;
    }

    public long getUser_key() {
        return user_key;
    }

    public void setUser_key(long user_key) {
        this.user_key = user_key;
    }
}
