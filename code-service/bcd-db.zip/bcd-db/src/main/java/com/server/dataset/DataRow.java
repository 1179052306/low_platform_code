package com.server.dataset;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @Author
 * @Date 2022/11/14 13:13
 */
public class DataRow {

    public DataRow(DataTable table, DataColumnCollection columns) {

        this.table = table;
        this.columns = columns;
    }

    public DataTable getTable() {
        return table;
    }

    public void setTable(DataTable table) {
        this.table = table;
    }


    public Map<String, Object> getRowMap() {
        return rowMap;
    }

    public void setRowMap(Map<String, Object> rowMap) {
        this.rowMap = rowMap;
    }


    public DataColumnCollection getColumns() {
        return columns;
    }

    public void setColumns(DataColumnCollection columns) {
        this.columns = columns;
    }

    private DataTable table;

    private Map<String, Object> rowMap = new LinkedHashMap<String, Object>();

    private DataColumnCollection columns;

    public void setVal(DataColumn column, Object value) {
        if (column != null) {
            String columnName = column.getColumnName();

            rowMap.put(columnName, value);
        }
    }

    public Map<String, Object> GetRowMap() {

        return rowMap;

    }

    public void setVal(String column, Object val) {

        this.setVal(columns.getColumn(column), val);
    }

    public void setVal(int index, Object val) {

        this.setVal(columns.getColumn(index), val);
    }

    public Object getVal(String column) {

        if (this.rowMap.get(column) == null) {

            return  "";
        }
        return this.rowMap.get(column);
    }

    public Object getVal(int index) {
        String column = this.columns.getColumn(index).getColumnName();
        return this.rowMap.get(column);
    }
}
