package com.server.db;

import com.zaxxer.hikari.HikariDataSource;
import io.seata.rm.datasource.DataSourceProxy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class MultiDataSource extends AbstractRoutingDataSource {
    public static Map<String, HikariDataSource> oldDataSources =new ConcurrentHashMap<>();

    @Autowired
    private DBProperties dbProperties;

    @Override
    protected Object determineCurrentLookupKey() {

        return MultiDataSourceHolder.getDatasource();

    }
    
    public void resetTargetDataSource(HashMap<Object, Object> targetDataSources) {
        try {
            if(targetDataSources.size()==0){
                return;
            }
            for (Map.Entry<Object, DataSource> entry : this.getResolvedDataSources().entrySet()) {
                HikariDataSource hikariDataSource=(HikariDataSource) entry.getValue();
                oldDataSources.put(UUID.randomUUID().toString(),hikariDataSource);
            }
            YamlPropertiesFactoryBean factoryBean = new YamlPropertiesFactoryBean();
            String path = "application.yml";
            factoryBean.setResources(new ClassPathResource(path));
            Properties properties = factoryBean.getObject();
            boolean seata_enabled = true;
            if (properties.get("seata.enabled") == null) {
                seata_enabled = false;
            } else {
                seata_enabled = Boolean.parseBoolean(properties.get("seata.enabled").toString());
            }
            if (seata_enabled) {
                for (Object key : targetDataSources.keySet()) {
                    this.setDefaultTargetDataSource(new DataSourceProxy((HikariDataSource )targetDataSources.get(key)));
                }
            } else {
                for (Object key : targetDataSources.keySet()) {
                    this.setDefaultTargetDataSource(targetDataSources.get(key));
                }
            }
            this.setTargetDataSources(targetDataSources);
            this.afterPropertiesSet();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
