package com.server.generate;

import com.server.params.Rpt;
import com.server.params.RptCompute;
import com.server.params.Rtt;
import com.server.params.Wheres;
import com.server.syntax.val.DbValue;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class CommonHelp {

    @Resource
    private DbValue dbValue;

    /**
     * 插入是进行动态替换
     *
     * @param dbName
     * @param Magic
     * @param MasterKeyOfMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    public void insertMagic(String dbName, List<Rpt>Magic, List<Object>MasterKeyOfMagic)throws  Exception{

        if(MasterKeyOfMagic!=null && MasterKeyOfMagic.size()>0){
            for (int i = 0; i < MasterKeyOfMagic.size(); i++) {

                Object node=MasterKeyOfMagic.get(i);
                if(node.getClass().getName().equals("com.server.params.Rpt")){

                    Magic.add((Rpt)node);

                }
                if(node.getClass().getName().equals("com.server.params.Rtt")){

                    Rtt rtt= (Rtt)node;
                    rtt.setParamentVal(dbValue.getSysDate(dbName));
                    Rpt rpt=new Rpt(rtt.getParamentName(),rtt.getParamentVal());
                    Magic.add(rpt);

                }
            }
//            if(Magic.size()!=MasterKeyOfMagic.size()){
//
//                throw new Exception("MasterKeyOfMagic 参数中存在不合法的Object类型，合法（Rpt，Rtt）");
//            }
        }

    }


    public void insertCompute(String dbName, List<RptCompute>Magic, List<Object>MasterKeyOfMagic)throws  Exception{

        if(MasterKeyOfMagic!=null && MasterKeyOfMagic.size()>0){
            for (int i = 0; i < MasterKeyOfMagic.size(); i++) {

                Object node=MasterKeyOfMagic.get(i);
                if(node.getClass().getName().equals("com.server.params.RptCompute")){

                    Magic.add((RptCompute)node);

                }

            }
//            if(Magic.size()!=MasterKeyOfMagic.size()){
//
//                throw new Exception("MasterKeyOfMagic 参数中存在不合法的Object类型，合法（Rpt，Rtt）");
//            }
        }

    }
    /**
     * 插入是进行动态替换
     *
     * @param MasterKeyOfMagic
     * @param Column
     * @param StrAfterSql
     * @return Boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public Boolean magicSssignment(List<Rpt> MasterKeyOfMagic, String Column, StringBuilder StrAfterSql)
    {
        Boolean result=false;
        try
        {
            ///循环特殊值
            for (int i = 0; i < MasterKeyOfMagic.size() ; i++)
            {
                Rpt funParament=MasterKeyOfMagic.get(i);
                if (Column.equals(funParament.getParamentName()))///特殊值比对
                {
                    StrAfterSql.append(funParament.getParamentVal());///需要配置的字符串添加相对应值
                    result = true;///设置返回结果
                    removeRpt(MasterKeyOfMagic, i);////移除二维数组下当前值
                    break;///跳出
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return  result;
    }
    /**
     * 插入是进行动态替换
     *
     * @param MasterKeyOfMagic
     * @param Column
     * @param
     * @return Boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public RptCompute computesSssignment(List<RptCompute> MasterKeyOfMagic, String Column)
    {
        RptCompute rptCompute=null;
        try
        {
            ///循环特殊值
            for (int i = 0; i < MasterKeyOfMagic.size() ; i++)
            {
                RptCompute funParament=MasterKeyOfMagic.get(i);
                if (Column.equals(funParament.getParamentName()))///特殊值比对
                {
                    rptCompute=new RptCompute(funParament.getParamentName(),funParament.getSymbol());
//                    removeRpt(MasterKeyOfMagic, i);////移除二维数组下当前值
                    break;///跳出
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return  rptCompute;
    }
    /**
     * 删除RPT
     *
     * @param MasterKeyOfMagic
     * @param index
     * @author liwei
     * @date: 2023/7/26
     **/
    public void removeRpt(List<Rpt>MasterKeyOfMagic, int index)
    {
        try
        {

            MasterKeyOfMagic.remove(index);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    /**
     * 删除Where
     *
     * @param Where
     * @param index
     * @author liwei
     * @date: 2023/7/26
     **/
    public void removeWhere(List<Wheres>Where, int index)
    {
        try
        {

            Where.remove(index);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

}
