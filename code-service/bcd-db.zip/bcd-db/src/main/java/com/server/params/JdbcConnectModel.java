package com.server.params;

/**
 * @author lw
 * @date: 2025/2/21
 * @description:
 **/
public class JdbcConnectModel {

    public JdbcConnectModel(String jdbc_url, String user, String pwd) {
        this.jdbc_url = jdbc_url;
        this.user = user;
        this.pwd = pwd;
    }

    String jdbc_url;
    String user;
    String pwd;

    public String getJdbc_url() {
        return jdbc_url;
    }

    public void setJdbc_url(String jdbc_url) {
        this.jdbc_url = jdbc_url;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}
