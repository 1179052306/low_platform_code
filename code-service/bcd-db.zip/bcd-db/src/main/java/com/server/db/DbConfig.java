package com.server.db;

import com.zaxxer.hikari.HikariDataSource;
import io.seata.rm.datasource.DataSourceProxy;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.Connection;


/**
 * @Description 数据库配置读取
 * @Author liwei
 * @Date 2023/7/26 9:50
 **/
@Service
public class DbConfig {

    @Resource
    public MultiDataSource dataSource;
//    @Resource
//    public DbHelp dbHelp;

    @Resource
    Tenant tenant;

    @Resource
    InterceptTenant interceptTenant;

    /**
     * 获取数据库类型
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getType(@Nullable String dbName) {
        String dbType = null;
        try {

            if (dataSource == null) {
                return null;
            }
            String driverClassName = "";

            try {

                driverClassName = getConnType(dbName);

            } catch (Exception e) {
                e.printStackTrace();
            } finally {

            }

            if (driverClassName.toLowerCase().contains("mysql")) {
                dbType = "0";
            }
            if (driverClassName.toLowerCase().contains("oracle")) {
                dbType = "1";
            }
            if (driverClassName.toLowerCase().contains("sqlserver")) {
                dbType = "2";
            }
            if (driverClassName.toLowerCase().contains("postgresql")) {
                dbType = "3";
            }
            if (driverClassName.toLowerCase().contains("dm")) {
                dbType = "4";
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return dbType;
    }

    /**
     * 获取数据库名称
     *
     * @param dbName
     * @return String
     **/
    public String getUserName(@Nullable String dbName) {
        String userName = null;
        try {

            if (dataSource == null) {
                return null;
            }

            try {

                userName = getUserNameVal(dbName);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {

            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return userName;
    }

    public String getConnType(@Nullable String dbName) throws Exception {

        HikariDataSource hikariDataSource = this.getHikariDataSource(dbName);
        return hikariDataSource.getDriverClassName();

    }

    public String getUserNameVal(@Nullable String dbName) throws Exception {

        HikariDataSource hikariDataSource = this.getHikariDataSource(dbName);
        return hikariDataSource.getUsername();

    }

    public HikariDataSource getHikariDataSource(@Nullable String dbName) throws Exception {

        HikariDataSource hikariDataSource = null;

        if (dbName != null) {
            if (tenant.getSingle()) {
                if (dataSource.getResolvedDataSources().get(dbName).getClass().getName().contains("HikariDataSource")) {
                    hikariDataSource = (HikariDataSource) dataSource.getResolvedDataSources().get(dbName);
                } else {
                    DataSourceProxy dataSourceProxy = (DataSourceProxy) dataSource.getResolvedDataSources().get(dbName);
                    hikariDataSource = (HikariDataSource) dataSourceProxy.getTargetDataSource();
                }
            } else {
                String tenantId = interceptTenant.getTenantHeader();
                if (dataSource.getResolvedDataSources().get(dbName + "-" + tenantId).getClass().getName().contains("HikariDataSource")) {
                    hikariDataSource = (HikariDataSource) dataSource.getResolvedDataSources().get(dbName + "-" + tenantId);
                } else {
                    DataSourceProxy dataSourceProxy = (DataSourceProxy) dataSource.getResolvedDataSources().get(dbName + "-" + tenantId);
                    hikariDataSource = (HikariDataSource) dataSourceProxy.getTargetDataSource();
                }
            }
        } else {
            if (dataSource.getResolvedDefaultDataSource().getClass().getName().contains("HikariDataSource")) {
                hikariDataSource = (HikariDataSource) dataSource.getResolvedDefaultDataSource();
            } else {
                DataSourceProxy dataSourceProxy = (DataSourceProxy) dataSource.getResolvedDefaultDataSource();
                hikariDataSource = (HikariDataSource) dataSourceProxy.getTargetDataSource();
            }
        }

        return hikariDataSource;
    }

    public boolean checkTenant() {

        boolean res = true;
        if (!tenant.getSingle()) {
            String tenantId = interceptTenant.getTenantHeader();
            if(dataSource.getResolvedDataSources().get("project" + "-" + tenantId)==null){
                res=false;
            }
        }

        return res;
    }

}
