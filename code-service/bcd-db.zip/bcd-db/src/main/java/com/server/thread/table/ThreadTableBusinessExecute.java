package com.server.thread.table;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.DbComposite;
import com.server.thread.ThreadBase;
import com.server.thread.ThreadStateType;
import com.server.thread.ThreadsObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author lw
 * @date: 2025/3/6
 * @description:
 **/
public class ThreadTableBusinessExecute {

    public   static void businessMain(String tenantId, ThreadTableBusiness threadTableBusiness, Map<String, ThreadsObject> threadsObjectMap) throws Exception {
        for (Map.Entry<String, ThreadsObject> entry : threadsObjectMap.entrySet()) {
            ThreadsObject value = entry.getValue();
            value.setDestroy(true);
        }


        String project = threadTableBusiness.project;

        ThreadTable threadTable= threadTableBusiness.threadTable;;

        DbComposite dbComposite= threadTableBusiness.dbComposite;

        ThreadTableBusinessCallback threadTableBusinessCallback = threadTableBusiness.threadTableBusinessCallback;

        JSONArray orderThread = dbComposite.dbHelp.queryJson(project, dbComposite.generateSql.sqlQuery(project, threadTable.tableName, dbComposite.generateSql.add("ACTIVE", "1")));
        if (orderThread.size() > 0) {
            for (int i = 0; i < orderThread.size(); i++) {
                JSONObject row = orderThread.getJSONObject(i);
                if (threadsObjectMap.get(tenantId+row.getString(threadTable.tablePkColumn)) == null) {

                    ThreadTable threadTableItem=new ThreadTable();
                    threadTableItem.setTableName(threadTable.tableName);
                    threadTableItem.setTablePkColumn(threadTable.tablePkColumn);
                    threadTableItem.setTablePkVal(row.getString(threadTable.tablePkColumn));
                    threadTableItem.setTableStateColumn(threadTable.tableStateColumn);
                    threadTableItem.setTableDataColumn(threadTable.tableDataColumn);
                    ThreadsObject threadsObject=new ThreadsObject(tenantId+threadTable.tablePkColumn,dbComposite,project);
                    threadsObject.setThreadTable(threadTableItem);
                    threadsObject.setSleep(row.getInteger(threadTable.tableSeelpColumn));
                    threadsObject.setTenantId(tenantId);
                    ThreadBase threadBase= threadTableBusinessCallback.externalMethod(threadsObject, row);
                    threadsObject.setThread(threadBase);
                    threadsObject.setDestroy(false);
                    threadsObjectMap.put(tenantId+row.getString(threadTable.tablePkColumn),threadsObject);
                }else{
                    ThreadsObject threadsObject=  threadsObjectMap.get(tenantId+row.getString(threadTable.tablePkColumn));
                    if(row.getInteger(threadTable.tableStateColumn)==-1){
                        threadsObject.getThreadState().setThreadStateType(ThreadStateType.notstart);
                    }
                    if(row.getInteger(threadTable.tableStateColumn)==0){
                        threadsObject.getThreadState().setThreadStateType(ThreadStateType.stop);
                    }
                    threadsObject.setSleep(row.getInteger(threadTable.tableSeelpColumn));
                    threadsObject.setDestroy(false);
                }
            }
        }
        List<String>removeList = new ArrayList<String>();
        for (Map.Entry<String, ThreadsObject> entry : threadsObjectMap.entrySet()) {
            ThreadsObject value = entry.getValue();
            if(value.isDestroy()){
                value.getThreadState().setThreadStateType(ThreadStateType.stop);
                removeList.add(entry.getKey());
                continue;
            }
            if(value.getThreadState().getNowState()== ThreadStateType.stop){
                removeList.add(entry.getKey());
                continue;
            }
            if(value.getThreadState().getNowState()== ThreadStateType.notstart){
                value.getThread().start();
            }
        }
        for (String entry : removeList) {
            threadsObjectMap.remove(entry);
        }
    }
}
