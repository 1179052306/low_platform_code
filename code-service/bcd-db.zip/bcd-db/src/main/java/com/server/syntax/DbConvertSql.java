package com.server.syntax;

import com.server.db.DbConfig;
import com.server.params.ReplaceSql;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @Description 数据库语法替换，由于不同数据库在语法上有些不同，需要对其进行简单处理
 * @Author liwei
 * @Date 2023/7/26 10:51
 **/
@Slf4j
@Service
public class DbConvertSql {

    @Resource
    DbConfig dbConfig;

    public String convertStrSql(@Nullable String dbName, String Sql) {
        List<ReplaceSql>list=  IndexOfSting( Sql);
        String SqlStr = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SqlStr = Sql.toUpperCase(Locale.ROOT);

            if(list.size()>0){
                StringBuilder stringBuilder=new StringBuilder(SqlStr);
                for (int i = 0; i < list.size(); i++) {

                    stringBuilder.replace(list.get(i).getStart(),list.get(i).getEnd(),list.get(i).getValue());
                }
                SqlStr = stringBuilder.toString();

            }

            SqlStr = SqlStr.replace("NULLIF(", "NVL(");
            if (SqlStr.contains("DELETE")) {
//                if (SqlStr.contains("FROM")) {
//                    SqlStr = SqlStr.replace("FROM", " ");
//                }
            }


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SqlStr = Sql.toLowerCase(Locale.ROOT);
//            SqlStr=SqlStr.replace("nvl(","nullif(");

            if(list.size()>0){
                StringBuilder stringBuilder=new StringBuilder(SqlStr);
                for (int i = 0; i < list.size(); i++) {

                    stringBuilder.replace(list.get(i).getStart(),list.get(i).getEnd(),list.get(i).getValue());
                }
                SqlStr = stringBuilder.toString();

            }

            if (SqlStr.contains("delete")) {

                if (!SqlStr.contains("from")) {

                    SqlStr = SqlStr.replace("delete", "delete from ");
                } else {

                    int fromNum = SqlStr.split("from").length - 1;
                    int deleteNum = SqlStr.split("delete").length - 1;
                    int selectNum = SqlStr.split("select").length - 1;

                    if (fromNum - selectNum - deleteNum < 0) {
                        boolean isAddFrom = true;
                        String[] deleteSplit = SqlStr.split("delete");
                        if (deleteSplit.length > 1) {
                            if (deleteSplit[0].split("select").length > 1) {
                                isAddFrom = false;
                            }
                        }
                        if (isAddFrom) {
                            SqlStr = SqlStr.replace("delete", "delete from ");
                        }

                    }

                }
            }



        }

        if (Type.equals("4")) {

            SqlStr = Sql.toUpperCase(Locale.ROOT);

            if(list.size()>0){
                StringBuilder stringBuilder=new StringBuilder(SqlStr);
                for (int i = 0; i < list.size(); i++) {

                    stringBuilder.replace(list.get(i).getStart(),list.get(i).getEnd(),list.get(i).getValue());
                }
                SqlStr = stringBuilder.toString();

            }

            SqlStr = SqlStr.replace("NULLIF(", "NVL(");
            if (SqlStr.contains("DELETE")) {
//                if (SqlStr.contains("FROM")) {
//                    SqlStr = SqlStr.replace("FROM", " ");
//                }
            }


        }
        log.info("执行SQL:" + SqlStr);
        return SqlStr;

    }

    public void splitStrSql(@Nullable String dbName,String TableAlias, String Symbol, String ParamterName, String DbType, StringBuilder Sql) {

        String SqlStr = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {
            /*if (Symbol.equals("=")) {
                Sql.append("  EXISTS(   SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",','))TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段
            } else {
                Sql.append(" NOT EXISTS(   SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",','))TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段
            }*/
            //用IN 非EXISTS
            if (Symbol.equals("=")) {
                Sql.append(" "+TableAlias + ParamterName + " IN( SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",',')) TAB) ");////需要配置的字符串添加字段
            } else {
                Sql.append(" "+TableAlias + ParamterName + " NOT IN( SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",',')) TAB ) ");////需要配置的字符串添加字段
            }

        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {
            /*if (Symbol.equals("=")) {
                if ("NUMBER".contains(DbType)) {
                    Sql.append("  EXISTS( SELECT TAB.STRVALUE FROM (SELECT to_number(unnest(string_to_array(" + "?" + ",',')),'9999999999999999') as STRVALUE)TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段

                } else {
                    Sql.append("  EXISTS( SELECT TAB.STRVALUE FROM (SELECT unnest(string_to_array(" + "?" + ",',')) as STRVALUE)TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段

                }
            } else {
                if ("NUMBER".contains(DbType)) {
                    Sql.append(" NOT EXISTS(   SELECT TAB.STRVALUE FROM (SELECT to_number(unnest(string_to_array(" + "?" + ",',')),'9999999999999999') as STRVALUE)TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段
                } else {
                    Sql.append(" NOT EXISTS(   SELECT TAB.STRVALUE FROM (SELECT unnest(string_to_array(" + "?" + ",',')) as STRVALUE)TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段

                }
            }*/
            //查询改为IN 非 EXISTS
            if (Symbol.equals("=")) {
                if ("NUMBER".contains(DbType)) {
                    Sql.append(" "+TableAlias + ParamterName + " IN( SELECT to_number(unnest(string_to_array(" + "?" + ",',')),'9999999999999999') as strValue) ");////需要配置的字符串添加字段

                } else {
                    Sql.append(" "+TableAlias  + ParamterName + " IN( SELECT unnest(string_to_array(" + "?" + ",',')) as strValue)");////需要配置的字符串添加字段

                }
            } else {
                if ("NUMBER".contains(DbType)) {
                    Sql.append(" "+TableAlias  + ParamterName + " NOT IN( SELECT to_number(unnest(string_to_array(" + "?" + ",',')),'9999999999999999') as strValue) ");////需要配置的字符串添加字段
                } else {
                    Sql.append(" "+TableAlias  + ParamterName + " NOT IN( SELECT unnest(string_to_array(" + "?" + ",',')) as strValue)");////需要配置的字符串添加字段

                }
            }
        }
        if (Type.equals("4")) {
            /*if (Symbol.equals("=")) {
                Sql.append("  EXISTS(   SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",','))TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段
            } else {
                Sql.append(" NOT EXISTS(   SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",','))TAB WHERE 1=1 AND  TAB.STRVALUE = T." + ParamterName + " ) ");////需要配置的字符串添加字段
            }*/
            //用IN 非EXISTS
            if (Symbol.equals("=")) {
                Sql.append(" "+TableAlias + ParamterName + " IN( SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",',')) TAB) ");////需要配置的字符串添加字段
            } else {
                Sql.append(" "+TableAlias + ParamterName + " NOT IN( SELECT TAB.STRVALUE FROM TABLE(str_splits(" + "?" + ",',')) TAB ) ");////需要配置的字符串添加字段
            }

        }

    }

    public void deleteStrSql(@Nullable String dbName, StringBuilder Sql) {

        String SqlStr = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            Sql.append(" FROM ");
        }

        if (Type.equals("4")) {


        }
    }

    public List<ReplaceSql> IndexOfSting(String Sql) {
        List<ReplaceSql>list=new ArrayList<>();
        try {
            String ch = "'";
            int index = Sql.indexOf(ch);
            if (index == -1) {
                return list;
            }

            int num=1;

            int start = index;
            int end = 0;
            while (index != -1) {
                num++;
                index = Sql.indexOf(ch, index + 1);
                if(index==-1){
                    break;
                }
                end =index;

                if(num%2==0){
                    if(start+1==end){
                        continue;
                    }
                    ReplaceSql replaceSql=new ReplaceSql();
                    replaceSql.setValue(Sql.substring(start+1,end));
                    replaceSql.setStart(start+1);
                    replaceSql.setEnd(end);
                    list.add(replaceSql);
                }

                start=index;
            }
        }catch (Exception ex){
            log.error(Sql+"IndexOfSting:" + ex);
        }

        return list;
    }

}
