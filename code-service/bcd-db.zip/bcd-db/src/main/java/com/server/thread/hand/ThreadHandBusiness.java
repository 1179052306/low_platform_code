package com.server.thread.hand;

import com.server.DbComposite;
import com.server.thread.table.ThreadTable;
import com.server.thread.table.ThreadTableBusinessCallback;

/**
 * @author lw
 * @date: 2025/3/6
 * @description:
 **/

public class ThreadHandBusiness {

    public ThreadHandBusiness() {

    }
    public ThreadHandBusiness(String threadName,String project, DbComposite dbComposite,ThreadHandBusinessCallback threadHandBusinessCallback) {
        this.threadName = threadName;
        this.project = project;
        this.dbComposite = dbComposite;
        this.threadHandBusinessCallback = threadHandBusinessCallback;

    }
    public ThreadHandBusiness(String threadName,String project, DbComposite dbComposite, String pkVal,ThreadHandBusinessCallback threadHandBusinessCallback) {
        this.threadName = threadName;
        this.project = project;
        this.dbComposite = dbComposite;
        this.threadHandBusinessCallback = threadHandBusinessCallback;
        threadTable=new ThreadTable();
        threadTable.setTableName("S_THREAD_MANAGE");
        threadTable.setTablePkColumn("THREAD_MANAGE_KEY");
        threadTable.setTableStateColumn("THREAD_STATE");
        threadTable.setTableSeelpColumn("THREAD_SLEEP");
        threadTable.setTableDataColumn("MANAGE_THREAD_TIME");
        threadTable.setTablePkVal(pkVal);
    }

    String project = "project";

    String threadName = "";
    ThreadTable threadTable=null;
    DbComposite dbComposite;

    ThreadHandBusinessCallback threadHandBusinessCallback;

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public DbComposite getDbComposite() {
        return dbComposite;
    }

    public void setDbComposite(DbComposite dbComposite) {
        this.dbComposite = dbComposite;
    }

    public ThreadHandBusinessCallback getThreadHandBusinessCallback() {
        return threadHandBusinessCallback;
    }

    public void setThreadHandBusinessCallback(ThreadHandBusinessCallback threadHandBusinessCallback) {
        this.threadHandBusinessCallback = threadHandBusinessCallback;
    }

    public String getThreadName() {
        return threadName;
    }

    public void setThreadName(String threadName) {
        this.threadName = threadName;
    }
}
