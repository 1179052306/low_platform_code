package com.server.params;

import java.io.Serializable;

/**
 * @Description 加密字段
 * @Author liwei
 * @Date 2023/7/26 10:24
 **/
public class GenerateEncry implements Serializable {

    public GenerateEncry(String columnName, EncryType encryType){
        this.columnName=columnName;
        this.encryType=encryType;
    }

    private  EncryType encryType;/////加密类型

    private  String columnName="";/////加密字段

    private  int columnIndex=-1;

    public String getColumnName() {  return columnName; }

    public EncryType getEncryType() {
        return encryType;
    }

    public int getColumnIndex() {
        return columnIndex;
    }

    public void setEncryType(EncryType encryType) {
        this.encryType = encryType;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public void setColumnIndex(int columnIndex) {
        this.columnIndex = columnIndex;
    }


}
