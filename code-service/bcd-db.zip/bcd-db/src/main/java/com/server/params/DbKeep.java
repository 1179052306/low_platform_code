package com.server.params;

import java.util.ArrayList;
import java.util.List;

/**
 * @author lw
 * @date: 2023/12/6
 * @description:
 **/
public class DbKeep {

    List<GenerateSqlTran> sqlTranList=new ArrayList<>();

    Boolean isExecute=false;

    KeepSqlTranType keepSqlTranType=KeepSqlTranType.execute;

    Boolean res=false;

    Object resData=new Object();

    public Object getResData() {
        return resData;
    }

    public void setResData(Object resData) {
        this.resData = resData;
    }
    public Boolean getRes() {
        return res;
    }

    public void setRes(Boolean res) {
        this.res = res;
    }



    public List<GenerateSqlTran> getSqlTranList() {
        return sqlTranList;
    }

    public void setSqlTranList(List<GenerateSqlTran> sqlTranList) {
        this.sqlTranList = sqlTranList;
    }

    public Boolean getExecute() {
        return isExecute;
    }

    public void setExecute(Boolean execute) {
        isExecute = execute;
    }


    public KeepSqlTranType getKeepSqlTranType() {
        return keepSqlTranType;
    }

    public void setKeepSqlTranType(KeepSqlTranType keepSqlTranType) {
        this.keepSqlTranType = keepSqlTranType;
    }


}
