package com.server.dataset;

import java.util.ArrayList;

/**
 * @Author
 * @Date 2022/11/14 13:20
 */
public class DataRowCollection {

    public  DataRowCollection(DataColumnCollection columns, DataTable table){

        this.columns=columns;

        this.table=table;
    }

    public ArrayList getRows() {
        return list;
    }

    public void setRows(ArrayList list) {
        this.list = list;
    }

    private ArrayList<DataRow>  list=new ArrayList();

    private DataColumnCollection columns=null;

    public DataTable getTable() {
        return table;
    }

    public void setTable(DataTable table) {
        this.table = table;
    }

    public void addRow(DataRow datarow){



        list.add(datarow);

    }
    private DataTable table;

    public DataRow newRow(){

        DataRow datarow=new DataRow(this.table,this.columns);

        list.add(datarow);
        return datarow;

    }

    public DataRow getRow(int index){

        return list.get(index);
    }
    public void remove(DataRow DataRow){

        for (int i = 0; i <list.size() ; i++) {

            if(list.get(i).equals(DataRow)){

                list.remove(i);
                break;
            }
        }
    }

    public void removeAt(int index){

        list.remove(index);
    }

    public void clear(){

        list.clear();

    }

    public int size(){

       return list.size();

    }

}
