package com.server.params;

import java.util.ArrayList;
import java.util.List;

/**
 * @author lw
 * @date: 2025/7/1
 * @description:
 **/
public class ProceduresParameter {
    public ProceduresParameter(String dbName, String procedures) {
        this.dbName = dbName;
        this.procedures = procedures;
    }

    public ProceduresParameter(String dbName, String procedures, List<DbParameter> listParameter) {
        this.dbName = dbName;
        this.procedures = procedures;
        this.listParameter = listParameter;
    }

    private String dbName; /////数据库名

    private String procedures; /////数据库名

    private List<DbParameter> listParameter = new ArrayList<>();/////特殊处理属性集合

    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public String getProcedures() {
        return procedures;
    }

    public void setProcedures(String procedures) {
        this.procedures = procedures;
    }

    public List<DbParameter> getListParameter() {
        return listParameter;
    }

    public void setListParameter(List<DbParameter> listParameter) {
        this.listParameter = listParameter;
    }

    public DbParameter getDbParameter(int index) {
        return listParameter.get(index);
    }

    public DbParameter getDbParameter(String parameterName) {

        int index = -1;
        for (int i = 0; i < listParameter.size(); i++) {
            if (listParameter.get(i).getParameterName().equals(parameterName)) {
                index = i;
                break;
            }
        }
        if(index>0){
            return this.getDbParameter(index);
        }else {
            return null;
        }


    }
}
