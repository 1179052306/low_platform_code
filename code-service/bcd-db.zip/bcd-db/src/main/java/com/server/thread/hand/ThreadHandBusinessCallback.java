package com.server.thread.hand;

import com.alibaba.fastjson.JSONObject;
import com.server.thread.ThreadBase;
import com.server.thread.ThreadsObject;

/**
 * @author lw
 * @date: 2025/3/6
 * @description:
 **/
public interface ThreadHandBusinessCallback {

    ThreadBase externalMethod(ThreadsObject threadsObject);
}
