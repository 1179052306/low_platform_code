package com.server.thread;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.MultiDataSourceHolder;
import com.server.db.Tenant;
import com.server.special_handle.SpecialHandleInterface;
import com.server.tenant.TenantData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author lw
 * @date: 2025/2/26
 * @description:
 **/

@Service
@Slf4j
public class ThreadlHandle {

    @Autowired
    TenantData tenantData;

    public   void execute(Tenant tenant, ThreadHandleInterface task) throws Exception {
        if(tenant.getSingle()) {
            task.execute("");
        }else {
           JSONArray data= tenantData.getTenant();
            for (int i = 0; i < data.size(); i++) {
                try {
                    JSONObject item=data.getJSONObject(i);
                    MultiDataSourceHolder.setDatasource(item.getString("TENANT_ID"));
                    task.execute(item.getString("TENANT_ID"));
                    MultiDataSourceHolder.clearDataSource();
                }catch (Exception ex){
                    log.error("ThreadlHandle:"+ex.toString());
                }

            }


        }
    }


}
