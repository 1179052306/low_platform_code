package com.server.syntax.val;

import com.server.params.DateIntervalType;
import com.server.params.GenerateSqlTran;
import com.server.params.Seq;
import org.springframework.lang.Nullable;

/**
 * @Description SqlServe数据库值获取
 * @Author liwei
 * @Date 2023/7/26 10:37
 **/
public class SqlServeVal implements DbValueServer {


    @Override
    public String getSeq(String table) {
        return null;
    }

    @Override
    public String getSeqVal(String dbName, String table) throws Exception {
        return null;
    }

    @Override
    public void getListSeqVal(@Nullable String dbName, Seq seq) throws Exception {

    }

    @Override
    public String getSysDateVal(String dbName) throws Exception {
        return null;
    }

    @Override
    public String getSysDateVal(String dbName, String format) throws Exception {
        return null;
    }

    @Override
    public String getSysDateIntervalDay(String val) {
        return null;
    }

    @Override
    public String getSysDataStr(String dbName, String format) throws Exception {
        return null;
    }

    @Override
    public String getToDateColumSql(String dbName, String time, String format) throws Exception {
        return null;
    }

    @Override
    public String getDateSql(String dbName, String time, String format) throws Exception {
        return null;
    }

    @Override
    public String getDateColumSql(String dbName, String column, String format) throws Exception {
        return null;
    }

    @Override
    public String getCeil(String val) {
        return null;
    }

    @Override
    public String getFloor(String val) {
        return null;
    }

    @Override
    public String getMod(String except, String dividdeBy) {
        return " "+except+"%"+dividdeBy+" ";
    }

    @Override
    public String connect_symbol() {
        return "+";
    }

    @Override
    public String getSysDate() {
        return null;
    }

    @Override
    public GenerateSqlTran getSysDateGenerateSql() {
        return null;
    }

    @Override
    public String getSysDate(String format) {
        return null;
    }

    @Override
    public String getDateInterval(int value, DateIntervalType dateType) {
        return null;
    }

    @Override
    public String getDateSubduction(String startDateFiled, String endDateFiled) {
        return null;
    }

    @Override
    public String getTrunc(String startDateFiled, String symbol, String endDateFiled) {
        return "";
    }

    @Override
    public String convertVarchar(String context) {
        return null;
    }

    @Override
    public String convertVarchar(String context, String format) {
        return null;
    }

    @Override
    public String getTrim(String context) {
        return null;
    }

    @Override
    public String getRowNum(int row) {
        return null;
    }

    @Override
    public String getRowVal() {
        return null;
    }

    public String getTableDescription() {

        return "SELECT * FROM (SELECT A.NAME AS TABLE_NAME, B.NAME AS COLUMN_NAME, T.NAME AS COLUMN_TYPE, C.VALUE AS COLUMN_CAPTION, B.IS_NULLABLE " +
                "FROM SYS.TABLES A INNER JOIN SYS.COLUMNS B ON B.OBJECT_ID = A.OBJECT_ID LEFT JOIN SYS.EXTENDED_PROPERTIES C ON C.MAJOR_ID = " +
                "B.OBJECT_ID AND C.MINOR_ID = B.COLUMN_ID LEFT JOIN SYS.TYPES T ON  T.USER_TYPE_ID = B.USER_TYPE_ID) T WHERE 1 = 1 ";

    }

    @Override
    public String createTable(String table, String copyTable) throws Exception {
        return "SELECT * INTO " + table + " FROM " + copyTable + " WHERE 1=0";
    }


}
