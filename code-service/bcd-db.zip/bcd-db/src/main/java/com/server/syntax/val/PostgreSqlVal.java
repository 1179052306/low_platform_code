package com.server.syntax.val;

import com.server.dataset.DataTable;
import com.server.db.DbHelpImpl;
import com.server.params.DateIntervalType;
import com.server.params.GenerateSqlTran;
import com.server.params.Seq;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description Postgre数据库值获取
 * @Author liwei
 * @Date 2023/7/26 10:35
 **/
@Service
public class PostgreSqlVal implements DbValueServer {

    @Autowired
    private DbHelpImpl dbHelp;

    /**
     * 获取自增列数据库SQL文本
     *
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSeq(String table) {
        return "nextval('" + table + "_SEQ')";
    }

    /**
     * 获取自增列数据值
     *
     * @param dbName
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSeqVal(@Nullable String dbName, String table) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT nextval('" + table + "_SEQ')");
        return dbHelp.query(dbName, stringBuilder.toString()).getRows().getRow(0).getVal(0).toString();
    }

    @Override
    public void getListSeqVal(@Nullable String dbName, Seq seq) throws Exception {
        List<Long>value=new ArrayList<>();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < seq.getNum(); i++) {
            stringBuilder.append("SELECT nextval('" +  seq.getTable()  + "_SEQ')");
            if(i<seq.getNum()-1){
                stringBuilder.append(" UNION ");
            }

        }
        DataTable dataTable= dbHelp.query(dbName, stringBuilder.toString());

        for (int i = 0; i < dataTable.size(); i++) {
            value.add(Long.parseLong(dataTable.getRows(i).getVal(0).toString()));
        }
        seq.setSeqList(value);
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDateVal(@Nullable String dbName) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select  to_timestamp(to_char(current_timestamp,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss')");
        return dbHelp.query(dbName, stringBuilder.toString()).getRows().getRow(0).getVal(0).toString();
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDateVal(@Nullable String dbName, String format) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT to_char(current_timestamp,'" + format + "')");
        return dbHelp.query(dbName, stringBuilder.toString()).getRows().getRow(0).getVal(0).toString();
    }

    @Override
    public String getSysDateIntervalDay( String val)  {
        return " EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - "+val+")) / 86400 ";
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDataStr(@Nullable String dbName, String format) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" to_timestamp(to_char(current_timestamp,'" + format + "'),'" + format + "')::timestamp");
        return stringBuilder.toString();
    }

    @Override
    public String getToDateColumSql(String dbName, String time, String format) throws Exception {
        if(StringUtils.isBlank(time)){
            return "null";
        }
        String sql="to_timestamp("+time+",'"+format+"')::timestamp";
        return sql;
    }

    @Override
    public String getDateSql(String dbName, String time, String format) throws Exception {
        if(StringUtils.isBlank(time)){
            return "null";
        }
        String sql="to_timestamp('"+time+"','"+format+"')::timestamp";
        return sql;
    }

    @Override
    public String getDateColumSql(String dbName, String column, String format) throws Exception {
        String sql="to_timestamp(to_char("+column+",'"+format+"'),'"+format+"')::timestamp";
        return sql;
    }

    @Override
    public String getCeil( String val)  {
        return " CEIL("+val+") ";
    }

    @Override
    public String getFloor( String val)  {
        return " FLOOR("+val+") ";
    }

    @Override
    public String getMod(String except, String dividdeBy) {
        return " "+except+"%"+dividdeBy+" ";
    }

    @Override
    public String connect_symbol() {
        return "||";
    }

    /**
     * 获取数据库时间SQL文本
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDate() {
        return "to_timestamp(to_char(current_timestamp,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss')";
    }

    
    @Override
    public GenerateSqlTran getSysDateGenerateSql() {
        GenerateSqlTran generateSqlTran=new GenerateSqlTran();
        generateSqlTran.set_strsql("select  to_timestamp(to_char(current_timestamp,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss') AS NEW_DATE ");
        generateSqlTran.setTableName("NEW_DATE");
        return generateSqlTran;
    }

    /**
     * 获取数据库时间SQL文本
     *
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDate(String format) {
        return " to_timestamp(to_char(current_timestamp,'" + format + "'),'" + format + "')";
    }

    @Override
    public String getDateInterval(int value, DateIntervalType dateType) {
        return " INTERVAL '"+value+" "+dateType.getIntervalType()+"'";
    }

//    @Override
//    public String getColumnDateInterval(String cloumn,DateIntervalType dateType) {
//        return " "+cloumn+"+INTERVAL '"+value+" "+dateType.getIntervalType()+"'";
//    }

    @Override
    public String getDateSubduction(String startDateFiled, String endDateFiled) {
        return " FLOOR( EXTRACT(EPOCH FROM ("+startDateFiled+" - "+endDateFiled+")) / 86400) ";
    }

    @Override
    public String getTrunc(String startDateFiled, String symbol, String endDateFiled) {
        return "";
    }

    @Override
    public String convertVarchar( String context) {
        return " NVL(CAST("+context+" AS text) ,'')";
    }

    @Override
    public String convertVarchar(String context, String format) {
        return " TO_CHAR(" + context + ",'"+format+"')";
    }

    @Override
    public String getTrim(String context) {
        return " TRIM("+context+")";
    }
    
    @Override
    public String getRowNum(int row) {
        return " LIMIT "+row+"";
    }

    @Override
    public String getRowVal() {
        return " row_number()over() ";
    }

    /**
     * 获取数据库字段详情
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getTableDescription() {
        return "select * from (select c.relname as table_name, cast(obj_description(relfilenode, 'pg_class') as varchar) as table_caption, a.attname as column_name, " +
                "t.typname as column_type, b.description as column_caption, a.attnotnull as is_nullable from pg_class c, pg_attribute a left outer " +
                "join pg_description b on a.attrelid=b.objoid and a.attnum = b.objsubid,pg_type t where 1=1 and a.attnum > 0 and a.attrelid = c.oid " +
                "and a.atttypid = t.oid order by a.attnum) T where 1=1 ";
    }

    @Override
    public String createTable(String table, String copyTable) throws Exception {
        return "CREATE TABLE " + table + " (LIKE " + copyTable + " INCLUDING ALL)";
}

}
