package com.server;

import com.server.db.DbHelpImpl;
import com.server.db.MultiDataSourceHolder;
import com.server.db.Tenant;
import com.server.generate.GenerateSqlImpl;
import com.server.special_handle.SpecialHandle;
import com.server.syntax.val.DbValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author lw
 * @date: 2025/3/5
 * @description:
 **/
@Service
public class DbComposite {

    @Autowired
    public MultiDataSourceHolder multiDataSourceHolder;

    @Autowired
    public DbHelpImpl dbHelp;
    @Autowired
    public GenerateSqlImpl generateSql;

    @Autowired
    public DbValue dbValue;
    @Autowired
    public Tenant tenant;

    @Autowired
    public SpecialHandle specialHandle;
}
