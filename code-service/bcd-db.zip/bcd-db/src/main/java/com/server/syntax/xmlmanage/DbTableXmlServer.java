package com.server.syntax.xmlmanage;

import com.server.params.GenerateSqlTran;
import org.springframework.lang.Nullable;


/**
 * @Description xml获取接口
 * @Author liwei
 * @Date 2023/7/26 10:40
 **/
public interface DbTableXmlServer {

    /**
     * 保存xml
     *
     * @param path
     * @param table
     * @param dbName
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public boolean saveXml(String path, String table, @Nullable String dbName);

    /**
     * 检查字段xml
     *
     * @param table
     * @param columnName
     * @param dbName
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public boolean checkColumnXml(String table, String columnName, @Nullable String dbName);

    /**
     * 获取全部表数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    public StringBuilder getDataSql(@Nullable String dbName);

    /**
     * @Description: 获取数据库所有表名称
     * @param dbName 数据库标识
     * @param symbol 条件标识符
     * @param filter 条件
     * @Return {@link GenerateSqlTran}
     * @Author: 陈永书
     * @Date: 2024/2/3 14:16
     */
    public GenerateSqlTran getDataSql(@Nullable String dbName, String symbol, String filter);


    /**
     * 获取全部表字段数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    public StringBuilder getTableColumnSql(@Nullable String dbName);

    public GenerateSqlTran getTableColumnSql(@Nullable String dbName, String table);
}
