package com.server.params;


/**
 * @Description Where条件参数
 * @Author liwei
 * @Date 2023/7/26 10:34
 **/
public  class Wheres{

    public Wheres(String paramentName, String paramentVal){

        this.paramentName=paramentName;
        this.paramentVal=paramentVal;
    }
    public Wheres(String paramentName){

        this.paramentName=paramentName;

    }
    public Wheres(String paramentName, String Symbol, String paramentVal){

        this.paramentName=paramentName;
        this.paramentVal=paramentVal;
        this.symbol=Symbol;
    }

    public Wheres(String paramentName,  String paramentVal, boolean isRemove){

        this.paramentName=paramentName;
        this.paramentVal=paramentVal;
        this.isRemove=isRemove;
    }

    private  String symbol="=";
    private  Boolean isRemove=true;
    private  String paramentVal="";
    private  String paramentName="";


    public String getSymbol() {
        return symbol;
    }

    public Boolean getIsRemove() {
        return isRemove;
    }

    public String getParamentName() {
        return paramentName;
    }

    public String getParamentVal() {
        return paramentVal;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void setIsRemove(Boolean isRemove) {
        this.isRemove = isRemove;
    }

    public void setParamentName(String paramentName) {
        this.paramentName = paramentName;
    }

    public void setParamentVal(String paramentVal) {
        this.paramentVal = paramentVal;
    }

}
