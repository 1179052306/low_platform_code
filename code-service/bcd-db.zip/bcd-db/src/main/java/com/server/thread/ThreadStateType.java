package com.server.thread;

/**
 * @author lw
 * @date: 2025/3/5
 * @description:
 **/
public enum ThreadStateType {
    notstart(-1, "未启动"),
    stop(0, "停止"),
    run(1, "运行中"),
    hibernate(2, "休眠"),
    ;

    private int stateType;
    private String stateDesc;

    ThreadStateType(int stateType, String stateDesc) {
        this.stateType = stateType;
        this.stateDesc = stateDesc;
    }

    public int getStateType() {
        return stateType;
    }

    public void setStateType(int stateType) {
        this.stateType = stateType;
    }

    public String getStateDesc() {
        return stateDesc;
    }

    public void setStateDesc(String stateDesc) {
        this.stateDesc = stateDesc;
    }
}
