package com.server.dataset;

import java.util.ArrayList;

/**
 * @Author
 * @Date 2022/11/14 11:28
 */
public class DataSet {
    public DataSet(){

    }
    public ArrayList<DataTable> getTables() {
        return tables;
    }

    public DataTable getTables(int index) {
        return tables.get(index);
    }

    public void setTables(ArrayList<DataTable> tables) {
        this.tables = tables;
    }

    private ArrayList<DataTable> tables=new ArrayList<>();

    public DataTable[] Table;


    public void add(DataTable dataTable){

        tables.add(dataTable);

    }

    public void removeAt(int index){

        tables.remove(index);
    }

    public void clear(){

        tables.clear();

    }

    public int size(){

        return tables.size();

    }
}
