package com.server.params;

/**
 * @Description 加密类型
 * @Author liwei
 * @Date 2023/7/26 10:23
 **/
public enum KeepSqlTranType {

    execute(1),

    query(0);

    private int keepSqlTranType=1;

    KeepSqlTranType(int keepType){

        this.keepSqlTranType=keepType;
    }
    public int getKeepSqlTranType() {
        return keepSqlTranType;
    }

    public void setKeepSqlTranType(int keepSqlTranType) {
        this.keepSqlTranType = keepSqlTranType;
    }


}
