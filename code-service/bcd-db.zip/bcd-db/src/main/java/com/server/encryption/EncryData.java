package com.server.encryption;

import com.alibaba.fastjson.JSONArray;
import com.server.dataset.DataColumn;
import com.server.dataset.DataTable;
import com.server.params.EncryType;
import com.server.params.GenerateEncry;
import com.server.params.GenerateSqlTran;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
/**
 * @Description 字段加密
 * @Author liwei
 * @Date 2023/7/26 9:51
 **/
public class EncryData {

    /**
     * DataTable 字段加密
     *
     * @param data
     * @param generateSqlTran
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    public static DataTable encryDataTable(DataTable data, GenerateSqlTran generateSqlTran){

        for (int i = 0; i < data.size(); i++) {

            for (int j = 0; j < generateSqlTran.getEncryList().size(); j++) {
                GenerateEncry generateEncry= generateSqlTran.getEncryList().get(j);
                DataColumn column= data.getColumns().getColumn(generateEncry.getColumnName());

                if(column!=null){

                    String Val=data.getRows(i).getVal(column.getColumnName()).toString();
                    if(StringUtils.isEmpty(Val)){
                        continue;
                    }
                    if(generateEncry.getEncryType()== EncryType.email){
                        Val= Encryption.settingemail(Val);
                    }
                    if(generateEncry.getEncryType()== EncryType.ipone){
                        Val= Encryption.settingphone(Val);
                    }
                    data.getRows(i).setVal(column,Val);
                }
            }
        }



        return  data;
    }
    /**
     * JSONArray 字段加密
     *
     * @param data
     * @param generateSqlTran
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    public static JSONArray encryJson(JSONArray data, GenerateSqlTran generateSqlTran){

        for (int i = 0; i < data.size(); i++) {

            for (int j = 0; j < generateSqlTran.getEncryList().size(); j++) {
                GenerateEncry generateEncry= generateSqlTran.getEncryList().get(j);

                if(data.getJSONObject(i).get(generateEncry.getColumnName())!=null){

                    String Val=data.getJSONObject(i).get(generateEncry.getColumnName()).toString();

                    if(StringUtils.isEmpty(Val)){
                        continue;
                    }
                    if(generateEncry.getEncryType()== EncryType.email){
                        Val= Encryption.settingemail(Val);
                    }
                    if(generateEncry.getEncryType()== EncryType.ipone){
                        Val= Encryption.settingphone(Val);
                    }
                    data.getJSONObject(i).put(generateEncry.getColumnName(),Val);
                }
            }
        }



        return  data;
    }

    /**
     * List<Map<String, Object>> 字段加密
     *
     * @param data
     * @param generateSqlTran
     * @return List<Map<String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    public static List<Map<String, Object>> encryMap(List<Map<String, Object>> data, GenerateSqlTran generateSqlTran){

        for (int i = 0; i < data.size(); i++) {

            for (int j = 0; j < generateSqlTran.getEncryList().size(); j++) {
                GenerateEncry generateEncry= generateSqlTran.getEncryList().get(j);

                if(data.get(i).get(generateEncry.getColumnName())!=null){

                    String Val=data.get(i).get(generateEncry.getColumnName()).toString();
                    if(StringUtils.isEmpty(Val)){
                        continue;
                    }
                    if(generateEncry.getEncryType()== EncryType.email){
                        Val= Encryption.settingemail(Val);
                    }
                    if(generateEncry.getEncryType()== EncryType.ipone){
                        Val= Encryption.settingphone(Val);
                    }
                    data.get(i).put(generateEncry.getColumnName(),Val);
                }
            }
        }
        return  data;
    }



}
