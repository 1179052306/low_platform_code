package com.server.syntax.gridpage;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.DbHelpImpl;
import com.server.generate.GenerateSqlImpl;
import com.server.generate.SQLSanitizer;
import com.server.getdata.TableAttribute;
import com.server.params.DataParameter;
import com.server.params.DbCustomParameter;
import com.server.params.GenerateSqlTran;
import com.server.syntax.val.DbValue;
import com.server.syntax.xmlmanage.DbTableXml;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description Oracle数据库获取分页查询相关
 * @Author liwei
 * @Date 2023/7/26 10:24
 **/
@Slf4j
@Service
@Component
public class DmGetTable {

    @Autowired
    private DbHelpImpl dbHelp;
    @Autowired
    private GenerateSqlImpl generateSql;
    @Autowired
    DbTableXml dbSaveTableXml;
    @Autowired
    private GetPermissionsSql getPermissionsSql;

    @Autowired
    private DbValue dbValue;

    /**
     * 数据库分页查询
     *
     * @param dataSqlTran
     * @param dataParameter
     * @param tableAttribute
     * @return JSONObject
     * @author liwei
     * @date: 2023/7/26
     **/
    public JSONObject getData(GenerateSqlTran dataSqlTran, DataParameter dataParameter, TableAttribute tableAttribute, @Nullable DbCustomParameter dbCustomParameter) throws Exception {
        JSONObject resData = new JSONObject();

        try {


            List<GenerateSqlTran> ListSqlTran = new ArrayList<>();//定义参数SQL容器
//            int[] Page = GetPage();
            String tableSql = dataSqlTran.get_strsql();
            tableSql = getPermissionsSql.getPermissionsSql(tableSql, dataParameter, dbCustomParameter, tableAttribute);

            if (tableAttribute.getSort() != null) {

                JSONObject sort = tableAttribute.getSort();
                String tableName = dataSqlTran.getTableName();
                String column = sort.get("selector").toString();
                if (!generateSql.checkParameter(column, dataSqlTran)) {

                    throw new Exception("列名" + column + " 排序字段不合法");
                }

                String desc = "";
                try {
                    if (Boolean.parseBoolean(sort.get("desc").toString())) {
                        desc = "DESC";
                    } else {
                        desc = "ASC";
                    }
                } catch (Exception ex) {
                    throw new Exception("列名" + column + " 排序格式不合法");
                }

                tableSql += " ORDER BY ";

                if (!org.apache.commons.lang.StringUtils.isBlank(sort.get("TableAlias").toString())) {
                    tableSql += SQLSanitizer.sanitize(sort.get("TableAlias").toString()) + ".";
                }
                tableSql += sort.get("selector") + " " + desc;

            } else {
                if (dataParameter.isDefaultOrderby()) {

                    if (StringUtils.isEmpty(dataParameter.getOrderByString())) {
                        tableSql += " ORDER BY T.CREATE_DATE DESC";

                    } else {
                        tableSql += dataParameter.getOrderByString();

                    }
                } else {
                    tableSql += dataParameter.getOrderByString();
                }

            }
            if (!tableAttribute.getIsLoadingAll()) {
                dataSqlTran.set_strsql(" SELECT * FROM(SELECT * FROM   (SELECT A.*, ROWNUM RN FROM(" + tableSql + ") A) " +
                        "WHERE RN <= " + tableAttribute.getEnd() + ")WHERE RN > " + tableAttribute.getBegin() + " ORDER BY RN ASC ");

            } else {
                dataSqlTran.set_strsql(tableSql);
            }
            ListSqlTran.add(dataSqlTran);
            GenerateSqlTran countSqlTran = new GenerateSqlTran();
            countSqlTran.set_strsql("SELECT COUNT(1) COUNT FROM (" + tableSql + ") A");
            countSqlTran.setListParameter(dataSqlTran.getListParameter());
            ListSqlTran.add(countSqlTran);
            if (tableAttribute.getTotalSummary() != null) {

                JSONArray summary = tableAttribute.getTotalSummary();
                if (summary.size() > 0) {
                    String sumCloumn = "";
                    for (int i = 0; i < summary.size(); i++) {

                        if (!generateSql.checkParameter(summary.getJSONObject(i).get("selector").toString(), dataSqlTran)) {

                            log.error("列名" + summary.getJSONObject(i).get("selector").toString() + " 汇总字段第一次不不合法");
                            dataSqlTran.get_XmlDocumentName().setDoc(dbSaveTableXml.saveTableXml(dbSaveTableXml.getTableXmlPath(dataSqlTran.getTableName(), dataSqlTran.getDbName()), dataSqlTran.getTableName(), dataSqlTran.getDbName()));
                            if (!generateSql.checkParameter(summary.getJSONObject(i).get("selector").toString(), dataSqlTran)) {
                                log.error("列名" + summary.getJSONObject(i).get("selector").toString() + " 汇总字段第二次不不合法");
                                throw new Exception("列名" + summary.getJSONObject(i).get("selector").toString() + " 汇总字段第二次不不合法");
                            }
                        }
                        sumCloumn += "SUM(" + summary.getJSONObject(i).get("selector").toString() + ")" + summary.getJSONObject(i).get("selector").toString() + ",";


                    }
                    sumCloumn = sumCloumn.substring(0, sumCloumn.length() - 1);
                    if (dataParameter.isServerPage()) {
                        GenerateSqlTran Str = new GenerateSqlTran();
                        Str.set_strsql("SELECT " + sumCloumn + " FROM (" + tableSql + ") A ");
                        Str.setListParameter(dataSqlTran.getListParameter());
                        ListSqlTran.add(Str);

                    } else {
                        GenerateSqlTran Str = new GenerateSqlTran();
                        Str.set_strsql("SELECT " + sumCloumn + " FROM(SELECT* FROM   (SELECT A.*, ROWNUM RN FROM(" + tableSql + ") A) WHERE RN <= " + tableAttribute.getEnd() + ")WHERE RN > " + tableAttribute.getBegin() + " ORDER BY RN ASC  ");
                        Str.setListParameter(dataSqlTran.getListParameter());
                        ListSqlTran.add(Str);

                    }
                }
            }

            JSONArray data = dbHelp.queryTranJson(dataSqlTran.getDbName(), ListSqlTran);///参数查询
            resData.put("data", data.get(0));
            resData.put("totalCount", ((JSONObject) ((JSONArray) data.get(1)).get(0)).get("COUNT"));
            if (tableAttribute.getTotalSummary() != null) {
                JSONArray summary = tableAttribute.getTotalSummary();
                if (summary.size() > 0) {
                    resData.put("summary", data.get(2));

                }
            }
            resData.put("res", true);
        } catch (Exception ex) {
            resData.put("err", "查询失败" + ex.toString());
            resData.put("res", false);
        }
        return resData;


    }

    /**
     * 数据库分页查询
     *
     * @param dataSqlTran
     * @param dataParameter
     * @param tableAttribute
     * @return JSONObject
     * @author liwei
     * @date: 2023/7/26
     **/
    public JSONObject getReportData(GenerateSqlTran dataSqlTran, String primaryColumn, DataParameter dataParameter, TableAttribute tableAttribute, @Nullable DbCustomParameter dbCustomParameter) throws Exception {
        JSONObject resData = new JSONObject();

        try {


            List<GenerateSqlTran> ListSqlTran = new ArrayList<>();//定义参数SQL容器
            String tableSql = dataSqlTran.get_strsql();
            tableSql = getPermissionsSql.getPermissionsSql(tableSql, dataParameter, dbCustomParameter, tableAttribute);

            if (tableAttribute.getSort() != null) {

                JSONObject sort = tableAttribute.getSort();
                String tableName = dataSqlTran.getTableName();
                String column = sort.get("selector").toString();
                if (!generateSql.checkParameter(column, dataSqlTran)) {

                    throw new Exception("列名" + column + " 排序字段不合法");
                }

                String desc = "";
                try {
                    if (Boolean.parseBoolean(sort.get("desc").toString())) {
                        desc = "DESC";
                    } else {
                        desc = "ASC";
                    }
                } catch (Exception ex) {
                    throw new Exception("列名" + column + " 排序格式不合法");
                }

                tableSql += " ORDER BY " + sort.get("selector") + " " + desc;

            } else {
                if (dataParameter.isDefaultOrderby()) {

                    if (StringUtils.isEmpty(dataParameter.getOrderByString())) {
                        tableSql += " ORDER BY CREATE_DATE DESC";

                    } else {
                        tableSql += dataParameter.getOrderByString();

                    }
                } else {
                    tableSql += dataParameter.getOrderByString();
                }

            }
            String mstvalue = dbValue.getSeqValue(dataSqlTran.getDbName(), "M_PRIMARY_STORAGE");

            dataSqlTran.set_strsql("INSERT INTO M_PRIMARY_STORAGE(MST_KEY,VALUE)SELECT " + mstvalue + "," + primaryColumn + " FROM (" + tableSql + ") T ");
            dbHelp.executeSql(dataSqlTran.getDbName(), dataSqlTran);
            resData.put("data", mstvalue);
            resData.put("res", true);
        } catch (Exception ex) {
            resData.put("err", "查询失败" + ex.toString());
            resData.put("res", false);
        }
        return resData;


    }
}
