package com.server.dataset;

import java.util.ArrayList;

/**
 * @Author
 * @Date 2022/11/14 13:20
 */
public class DataColumnCollection {

    public  DataColumnCollection(DataTable table){

        this.table=table;
    }

    public ArrayList getList() {
        return list;
    }

    public void setList(ArrayList list) {
        this.list = list;
    }

    private ArrayList<DataColumn>  list=new ArrayList();

    public DataTable getTable() {
        return table;
    }

    public void setTable(DataTable ztable) {
        this.table = table;
    }

    private DataTable table;

    public DataColumn add(){

        DataColumn dataColumn=new DataColumn(this.table);

        list.add(dataColumn);
        return dataColumn;

    }
    public DataColumn add(String columnName, int ColumnType, String ColumnTypeName){

        DataColumn dataColumn=new DataColumn(columnName,ColumnType,ColumnTypeName,this.table);

        list.add(dataColumn);
        return dataColumn;

    }

    public void remove(String columnName){

        for (int i = 0; i <list.size() ; i++) {

            if(list.get(i).getColumnName().equals(columnName)){

                list.remove(i);
                break;
            }
        }
    }

    public void removeAt(int index){

        list.remove(index);
    }
    public void clear(){

        list.clear();

    }

    public int size(){

       return list.size();

    }

    public DataColumn getColumn(String columnName){
        DataColumn column=null;
        for (int i = 0; i <list.size() ; i++) {

            if(list.get(i).getColumnName().equals(columnName)){

                column= list.get(i);
                break;
            }
        }
        return column;
    }

    public DataColumn getColumn(int index){
        DataColumn column=null;
        column= list.get(index);
        return column;
    }
}
