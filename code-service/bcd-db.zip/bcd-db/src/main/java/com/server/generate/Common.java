package com.server.generate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.params.*;
import com.server.syntax.DbConvertSql;

import com.server.syntax.xmlmanage.DbTableXml;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

@Slf4j
@Component
@Service
public class Common implements CommonImpl {

    @Autowired
    DbTableXml dbSaveTableXml;
    @Autowired
    CommonHelp CommonHelp;
    @Autowired
    DbConvertSql dbConvertSql;
    @Autowired
    ExistSearch ExistSearch;
    @Autowired
    DbParameterSet DbParameterSet;

    /**
     * insert 插入生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     */
    public GenerateSqlTran insert(@Nullable String dbName, String tableName, JSONObject json) {
        return insert(dbName, tableName, json, null, null);
    }

    /**
     * insert 插入生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     */
    public GenerateSqlTran insert(@Nullable String dbName, String tableName, JSONObject json, List<Object> masterMagic) {
        return insert(dbName, tableName, json, null, masterMagic);
    }

    /**
     * insert 插入生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param documentXml
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     */
    public GenerateSqlTran insert(@Nullable String dbName, String tableName, JSONObject json, DocumentXml documentXml, List<Object> masterMagic) {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.setDbName(dbName);
        try {
            if (json == null) {
                log.error("表" + tableName + "插入主参数：null(json不能为空)");
                generateSqlTran.getErrList().add(new GenerateErr("主参数", "json不能为空"));
                return generateSqlTran;
            }


            List<Rpt> Magic = new ArrayList<Rpt>();
            try {
                CommonHelp.insertMagic(dbName, Magic, masterMagic);
            } catch (Exception ex) {
                log.error("表" + tableName + "插入取值处理：masterMagic失败(" + ex.toString() + ")");
                generateSqlTran.getErrList().add(new GenerateErr("取值处理", "表" + tableName + "插入取值处理：masterMagic失败" + ex.toString()));

                return generateSqlTran;
            }
            if (documentXml == null) {
                try {

                    documentXml = new DocumentXml();

                    documentXml.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));

                } catch (Exception ex) {

                    log.error(tableName + ".xml初始化失败" + "(初始化DocumentXml失败失败" + ex.toString());
                    generateSqlTran.getErrList().add(new GenerateErr("初始化处理", "初始化DocumentXml失败失败" + ex.toString()));

                }
            }
            generateSqlTran.set_XmlDocumentName(documentXml);
            ///初始化对象StringBuilder（此处为INSERT 前半部分（字段））
            StringBuilder StrBeforeSql = new StringBuilder();
            //初始化对象StringBuilder（此处为INSERT 后半部分（值））
            StringBuilder StrAfterSql = new StringBuilder();
            InsertBefore(dbName, tableName, documentXml, generateSqlTran, StrBeforeSql, StrAfterSql);
            List<DbParameter> ListParameter = new ArrayList<DbParameter>();

            Iterator<String> sIterator = json.keySet().iterator();
            //循环并得到key列表
            while (sIterator.hasNext()) {
                // 获得key
                String key = sIterator.next();
                boolean result = false;
                StrBeforeSql.append(key + ",");
                if (Magic != null && Magic.size() > 0)////判断是特殊值是否为空
                {
                    DocumentNodeXml node = new DocumentNodeXml();
                    try {
                        ParamenterCheck.getParameter(key, documentXml, node);
                        if (node.getNode() != null) {
                            result = CommonHelp.magicSssignment(Magic, key, StrAfterSql);///特殊值处理
                        }
                    } catch (Exception ex) {
                        log.error("表" + tableName + "插入处理：Xml节点取值处理异常(" + ex.toString() + "");
                        generateSqlTran.getErrList().add(new GenerateErr("Xml节点取值处理", ex.toString()));


                    }
                }
                if (result) {

                    StrAfterSql.append(",");///初始化对象StringBuilder（此处为INSERT 前半部分（字段）） 添加逗号
                    continue;////跳出当前循环
                } else {

                    //获得key值对应的value
                    Object value = json.get(key);

                    StrAfterSql.append("?,");
                    try {

                        Parameter(dbName, key, value, StrAfterSql, documentXml, ListParameter, tableName);
                    } catch (Exception e) {
                        log.error("表" + tableName + "插入处理：参数处理异常(" + e.toString() + "");
                        generateSqlTran.getErrList().add(new GenerateErr("参数处理", e.toString()));
                    }
                }


            }

            InsertAfter(dbName, tableName, documentXml, generateSqlTran, StrBeforeSql, StrAfterSql);

            generateSqlTran.setListParameter(ListParameter); ////对象拼接并赋值给生成类
        } catch (Exception ex) {
            log.error("表" + tableName + "插入处理：方法处理异常(" + ex.toString() + "");
            generateSqlTran.getErrList().add(new GenerateErr("方法处理", ex.toString()));

        }
        return generateSqlTran;
    }


    /**
     * Update更新生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listWhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     */
    public GenerateSqlTran update(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listWhere) {
        return update(dbName, tableName, json, null, listWhere, null);
    }

    /**
     * Update更新生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listWhere
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     */
    public GenerateSqlTran update(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listWhere, List<Object> masterMagic) {
        return update(dbName, tableName, json, null, listWhere, masterMagic);
    }

    /**
     * Update更新生成
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param documentXml
     * @param EditWhere
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran update(@Nullable String dbName, String tableName, JSONObject json, DocumentXml documentXml, List<Wheres> EditWhere, List<Object> masterMagic) {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.setDbName(dbName);
        if (json == null) {
            log.error("表" + tableName + "更新主参数：null(json不能为空)");
            generateSqlTran.getErrList().add(new GenerateErr("主参数", "表" + tableName + "插入主参数：null(json不能为空)"));
            return generateSqlTran;
        }

        List<Rpt> Magic = new ArrayList<Rpt>();
        List<RptCompute> Computes = new ArrayList<RptCompute>();

        try {
            CommonHelp.insertMagic(dbName, Magic, masterMagic);

            CommonHelp.insertCompute(dbName, Computes, masterMagic);

        } catch (Exception ex) {
            log.error("表" + tableName + "更新取值处理：masterMagic失败(" + ex.toString() + ")");
            generateSqlTran.getErrList().add(new GenerateErr("取值处理", "表" + tableName + "插入取值处理：masterMagic失败(" + ex.toString() + ""));
            return generateSqlTran;
        }
        if (documentXml == null) {
            try {

                documentXml = new DocumentXml();

                documentXml.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));

            } catch (Exception ex) {

                log.error(tableName + ".xml初始化失败" + "(初始化DocumentXml失败失败" + ex.toString());
                generateSqlTran.getErrList().add(new GenerateErr("初始化处理", "初始化DocumentXml失败失败" + ex.toString()));

            }
        }
        generateSqlTran.set_XmlDocumentName(documentXml);
        List<Wheres> listWhere = new ArrayList<Wheres>();

        for (int i = 0; i < EditWhere.size(); i++) {
            Wheres node = EditWhere.get(i);
            listWhere.add(node);
        }


        ///初始化对象StringBuilder（此处为INSERT 前半部分（字段））
        StringBuilder StrBeforeSql = new StringBuilder();
        //初始化对象StringBuilder（此处为INSERT 后半部分（值））
        StringBuilder StrAfterSql = new StringBuilder();
        UpdateBefore(dbName, tableName, documentXml, generateSqlTran, StrBeforeSql, StrAfterSql);
        List<DbParameter> ListParameter = new ArrayList<DbParameter>();
        List<DbParameter> listWhereParameter = new ArrayList<DbParameter>();

        if (listWhere != null && listWhere.size() > 0)////判断是特殊值是否为空
        {
            for (int i = 0; i < listWhere.size(); i++) {
                Wheres where = listWhere.get(i);
                String key = where.getParamentName();
                String value = "";
                if (json.get(key) == null) {
                    log.error("表" + tableName + "更新处理：Json中参数处理(" + key + "值为空");
                    generateSqlTran.getErrList().add(new GenerateErr("Json中参数处理", key + "值为空"));
                    break;
                }

                value = json.get(key).toString();
                if (value.isEmpty()) {
                    if (where.getParamentVal().isEmpty()) {
                        log.error("表" + tableName + "更新处理：Json中参数处理(" + key + "值为空");
                        log.error("表" + tableName + "更新处理：Where参数处理(" + key + "值为空");
                        generateSqlTran.getErrList().add(new GenerateErr("Json中参数处理", key + "值为空"));
                        generateSqlTran.getErrList().add(new GenerateErr("Where参数处理", key + "值为空"));
                        break;
                    } else {
                        value = where.getParamentVal();
                    }

                }

                if(where.getIsRemove()){
                    json.remove(key);
                }
                StrAfterSql.append(" AND ");
                StrAfterSql.append(" " + key + " ");
                if (where.getSymbol() == "") if (!ParamenterCheck.symbolCheck(where.getSymbol())) {
                    log.error("符号参数：" + where.getSymbol() + "不合法");
                    generateSqlTran.getErrList().add(new GenerateErr("listWhere符号参数处理", where.getSymbol() + "不合法"));
                    break;
                }
                StrAfterSql.append(where.getSymbol());
                StrAfterSql.append("?");
                try {
                    Parameter(dbName, key, value, StrAfterSql, documentXml, listWhereParameter, tableName);
                } catch (Exception e) {

                    log.error("表" + tableName + "更新处理：Where参数处理发生异常(" + e.toString() + "");
                    generateSqlTran.getErrList().add(new GenerateErr("Where参数处理", e.toString()));
                }
            }

        }

        Iterator<String> sIterator = json.keySet().iterator();
        //循环并得到key列表
        while (sIterator.hasNext()) {
            // 获得key
            String key = sIterator.next();

            boolean result = false;

            StrBeforeSql.append(key + "=");
            if (Magic != null && Magic.size() > 0)////判断是特殊值是否为空
            {

                DocumentNodeXml node = new DocumentNodeXml();
                try {
                    ParamenterCheck.getParameter(key, documentXml, node);
                    if (node.getNode() != null) {
                        result = CommonHelp.magicSssignment(Magic, key, StrBeforeSql);///特殊值处理
                    }
                } catch (Exception ex) {
                    log.error("表" + tableName + "更新处理：Xml节点取值处理异常(" + ex.toString() + "");
                    generateSqlTran.getErrList().add(new GenerateErr("Xml节点取值处理", ex.toString()));

                }
            }
            if (Computes != null && Computes.size() > 0)////判断是特殊值是否为空
            {
                try {
                    RptCompute rptCompute=  CommonHelp.computesSssignment(Computes, key);///特殊值处理
                    if(rptCompute!=null){
                        StrBeforeSql.append(key+rptCompute.getSymbol());
                        StrBeforeSql.append("?");
                        Object value = json.get(key);
                        Parameter(dbName, key, value, StrBeforeSql, documentXml, ListParameter, tableName);
                        result=true;
                    }
//
                } catch (Exception e) {
                    log.error("表" + tableName + "更新处理：参数处理发生异常(" + e.toString() + "");
                    generateSqlTran.getErrList().add(new GenerateErr("参数处理", e.toString()));
                }
            }
            if (result) {
                StrBeforeSql.append(",");///初始化对象StringBuilder（此处为UPDATE 前半部分（字段）） 添加逗号
                continue;////跳出当前循环
            } else {

                StrBeforeSql.append("?,");
                Object value = json.get(key);
                try {
                    Parameter(dbName, key, value, StrBeforeSql, documentXml, ListParameter, tableName);
                } catch (Exception e) {
                    log.error("表" + tableName + "更新处理：参数处理发生异常(" + e.toString() + "");
                    generateSqlTran.getErrList().add(new GenerateErr("参数处理", e.toString()));
                }

            }
        }

        for (int i = 0; i < listWhereParameter.size(); i++) {

            ListParameter.add(listWhereParameter.get(i));
        }


        UpdateAfter(dbName, tableName, documentXml, generateSqlTran, StrBeforeSql, StrAfterSql);

        generateSqlTran.setListParameter(ListParameter); ////对象拼接并赋值给生成类

        return generateSqlTran;
    }

    /**
     * Update批量更新生成
     *
     * @param dbName
     * @param tableName
     * @param documentXml
     * @param listWhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     */

    public GenerateSqlTran delete(@Nullable String dbName, String tableName, DocumentXml documentXml, List<Wheres> listWhere) {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.setDbName(dbName);

        if (listWhere == null) {
            log.error("表" + tableName + "删除处理：listWhere参数不能为null");
            generateSqlTran.getErrList().add(new GenerateErr("参数处理", "listWhere参数不能为null"));
            return generateSqlTran;
        }
        if (listWhere.size() == 0) {

            log.error("表" + tableName + "删除处理：listWhere参数集合必须大于0");
            generateSqlTran.getErrList().add(new GenerateErr("参数处理", "listWhere参数集合必须大于0"));
            return generateSqlTran;
        }

        if (documentXml == null) {
            try {

                documentXml = new DocumentXml();

                documentXml.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));

            } catch (Exception ex) {

                log.error(tableName + ".xml初始化失败" + "(初始化DocumentXml失败失败" + ex.toString());
                generateSqlTran.getErrList().add(new GenerateErr("初始化处理", "初始化DocumentXml失败失败" + ex.toString()));

            }
        }
        generateSqlTran.set_XmlDocumentName(documentXml);
        ///初始化对象StringBuilder（此处为INSERT 前半部分（字段））
        StringBuilder StrBeforeSql = new StringBuilder();
        //初始化对象StringBuilder（此处为INSERT 后半部分（值））
        StringBuilder StrAfterSql = new StringBuilder();
        DeleteBefore(dbName, tableName, documentXml, generateSqlTran, StrBeforeSql, StrAfterSql);
        List<DbParameter> listWhereParameter = new ArrayList<DbParameter>();

        for (int i = 0; i < listWhere.size(); i++) {

            Wheres where = listWhere.get(i);
            StrAfterSql.append("  AND ");///添加数据库 关系词 AND
            StrAfterSql.append(where.getParamentName());//添加字段
            if (where.getSymbol() == "") if (!ParamenterCheck.symbolCheck(where.getSymbol())) {
                log.error("符号参数：" + where.getSymbol() + "不合法");
                generateSqlTran.getErrList().add(new GenerateErr("listWhere符号参数处理", where.getSymbol() + "不合法"));
                break;
            }
            StrAfterSql.append(where.getSymbol());
            StrAfterSql.append("? ");
            try {


                Parameter(dbName, where.getParamentName(), where.getParamentVal(), StrAfterSql, documentXml, listWhereParameter, tableName);
            } catch (Exception e) {
                log.error("表" + tableName + "删除处理：Where参数处理异常(" + e.toString() + ")");
                generateSqlTran.getErrList().add(new GenerateErr("Where参数处理", e.toString()));
            }
        }

        DeleteAfter(dbName, tableName, documentXml, generateSqlTran, StrBeforeSql, StrAfterSql);

        generateSqlTran.setListParameter(listWhereParameter); ////对象拼接并赋值给生成类

        return generateSqlTran;
    }
    /**
     * delete 删除数据
     *
     * @param dbName
     * @param tableName
     * @param listWhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran delete(@Nullable String dbName, String tableName, List<Wheres> listWhere) {
        DocumentXml doc = new DocumentXml();
        doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));
        return delete(dbName, tableName, doc, listWhere);
    }
    /**
     * 集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    public void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, List<Object> masterMagic) {
        try {
            if (jsonArray == null) {
                return;
            }
            if (jsonArray.size() == 0) {
                return;
            }
            DocumentXml doc = new DocumentXml();
            doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));
            listInsert(dbName, tableName, listExecuteSqlTran, jsonArray, doc, masterMagic);

        } catch (Exception ex) {
            throw ex;
        }
    }

    /**
     * 集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    public void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Object> masterMagic) {
        try {
            if (jsonObjectList == null) {
                return;
            }
            if (jsonObjectList.size() == 0) {
                return;
            }
            DocumentXml doc = new DocumentXml();
            doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));
            listInsert(dbName, tableName, listExecuteSqlTran, jsonObjectList, doc, masterMagic);

        } catch (Exception ex) {
            throw ex;
        }
    }
    /**
     * listInsert 批量插入生成
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonObjectList
     * @param docparament
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     */
    public void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, DocumentXml docparament, List<Object> masterMagic) {
        try {

            GenerateSqlTran generateSqlTran = new GenerateSqlTran();

            for (int i = 0; i < jsonObjectList.size(); i++) {
                if (i == 0) {
                    generateSqlTran = insert(dbName, tableName, jsonObjectList.get(i), docparament, masterMagic);

                } else {
                    GenerateSqlTran batch = CopySetGenerate(dbName, generateSqlTran, jsonObjectList.get(i));

                    generateSqlTran.getListBatch().add(batch);
                }
            }
            listExecuteSqlTran.add(generateSqlTran);

        } catch (Exception ex) {
            throw ex;
        }
    }
    /**
     * listInsert 批量插入生成
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param docparament
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     */
    public void listInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, DocumentXml docparament, List<Object> masterMagic) {
        try {

            GenerateSqlTran generateSqlTran = new GenerateSqlTran();

            for (int i = 0; i < jsonArray.size(); i++) {
                if (i == 0) {
                    generateSqlTran = insert(dbName, tableName, jsonArray.getJSONObject(i), docparament, masterMagic);

                } else {
                    GenerateSqlTran batch = CopySetGenerate(dbName, generateSqlTran, jsonArray.getJSONObject(i));

                    generateSqlTran.getListBatch().add(batch);
                }
            }
            listExecuteSqlTran.add(generateSqlTran);

        } catch (Exception ex) {
            throw ex;
        }
    }
    /**
     * 集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param listWhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    public void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Wheres> listWhere, List<Object> masterMagic) {
        try {
            if (jsonObjectList == null) {
                return;
            }
            if (jsonObjectList.size() == 0) {
                return;
            }
            DocumentXml doc = new DocumentXml();

            doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));

            listUpdate(dbName, tableName, listExecuteSqlTran, jsonObjectList, doc, listWhere, masterMagic);
        } catch (Exception ex) {
            throw ex;
        }
    }


    public void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, DocumentXml documentXml, List<Wheres> listWhere, List<Object> masterMagic) {
        try {

            GenerateSqlTran generateSqlTran = new GenerateSqlTran();

            for (int i = 0; i < jsonObjectList.size(); i++) {
                if (i == 0) {
                    generateSqlTran = update(dbName, tableName, jsonObjectList.get(i), documentXml, listWhere, masterMagic);

                } else {
//                    generateSqlTran.getListBatch().add(update(dbName, tableName, jsonArray.getJSONObject(i),
//                    documentXml, listWhere,
//                            masterMagic));

                    GenerateSqlTran batch = new GenerateSqlTran();
                    if (listWhere != null && listWhere.size() > 0)////判断是特殊值是否为空
                    {
                        for (int j = 0; j < listWhere.size(); j++) {
                            Wheres where = listWhere.get(j);
                            String key = where.getParamentName();

                            if (jsonObjectList.get(i).get(key) == null) {
                                if (where.getParamentVal() == "") {
                                    log.error("表" + tableName + "更新处理：Json中参数处理(" + key + "值为空");

                                    batch.getErrList().add(new GenerateErr("Json中参数处理", key + "值为空"));
                                    break;
                                }
                            }
                            if (jsonObjectList.get(i).get(key).toString().isEmpty()) {

                                if (where.getParamentVal().isEmpty()) {
                                    log.error("表" + tableName + "更新处理：Json中参数处理(" + key + "值为空");
                                    log.error("表" + tableName + "更新处理：Where参数处理(" + key + "值为空");

                                    batch.getErrList().add(new GenerateErr("Json中参数处理", key + "值为空"));
                                    batch.getErrList().add(new GenerateErr("Where参数处理", key + "值为空"));
                                    break;
                                } else {
                                    jsonObjectList.get(i).put(key, where.getParamentVal());
                                }
                            }
                        }
                    }
                    if (batch.getErrList().size() > 0) {
                        continue;
                    }
                    batch = CopySetGenerate(dbName, generateSqlTran, jsonObjectList.get(i));

                    generateSqlTran.getListBatch().add(batch);

                }
            }
            listExecuteSqlTran.add(generateSqlTran);
        } catch (Exception ex) {
            throw ex;
        }
    }
    /**
     * 集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param listWhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    public void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, List<Wheres> listWhere, List<Object> masterMagic) {
        try {
            if (jsonArray == null) {
                return;
            }
            if (jsonArray.size() == 0) {
                return;
            }
            DocumentXml doc = new DocumentXml();

            doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));

            listUpdate(dbName, tableName, listExecuteSqlTran, jsonArray, doc, listWhere, masterMagic);
        } catch (Exception ex) {
            throw ex;
        }
    }

    /**
     * Update批量更新生成
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param jsonArray
     * @param documentXml
     * @param listWhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     */
    @Override
    public void listUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray jsonArray, DocumentXml documentXml, List<Wheres> listWhere, List<Object> masterMagic) {
        try {

            GenerateSqlTran generateSqlTran = new GenerateSqlTran();

            for (int i = 0; i < jsonArray.size(); i++) {
                if (i == 0) {
                    generateSqlTran = update(dbName, tableName, jsonArray.getJSONObject(i), documentXml, listWhere, masterMagic);

                } else {
//                    generateSqlTran.getListBatch().add(update(dbName, tableName, jsonArray.getJSONObject(i),
//                    documentXml, listWhere,
//                            masterMagic));

                    GenerateSqlTran batch = new GenerateSqlTran();
                    if (listWhere != null && listWhere.size() > 0)////判断是特殊值是否为空
                    {
                        for (int j = 0; j < listWhere.size(); j++) {
                            Wheres where = listWhere.get(j);
                            String key = where.getParamentName();

                            if (jsonArray.getJSONObject(i).get(key) == null) {
                                if (where.getParamentVal() == "") {
                                    log.error("表" + tableName + "更新处理：Json中参数处理(" + key + "值为空");

                                    batch.getErrList().add(new GenerateErr("Json中参数处理", key + "值为空"));
                                    break;
                                }
                            }
                            if (jsonArray.getJSONObject(i).get(key).toString().isEmpty()) {

                                if (where.getParamentVal().isEmpty()) {
                                    log.error("表" + tableName + "更新处理：Json中参数处理(" + key + "值为空");
                                    log.error("表" + tableName + "更新处理：Where参数处理(" + key + "值为空");

                                    batch.getErrList().add(new GenerateErr("Json中参数处理", key + "值为空"));
                                    batch.getErrList().add(new GenerateErr("Where参数处理", key + "值为空"));
                                    break;
                                } else {
                                    jsonArray.getJSONObject(i).put(key, where.getParamentVal());
                                }
                            }
                        }
                    }
                    if (batch.getErrList().size() > 0) {
                        continue;
                    }
                    batch = CopySetGenerate(dbName, generateSqlTran, jsonArray.getJSONObject(i));

                    generateSqlTran.getListBatch().add(batch);

                }
            }
            listExecuteSqlTran.add(generateSqlTran);
        } catch (Exception ex) {
            throw ex;
        }
    }

    public GenerateSqlTran CopySetGenerate(@Nullable String dbName, GenerateSqlTran generateSqlTran, JSONObject jsonObject) {
        GenerateSqlTran batch = new GenerateSqlTran();
        generateSqlTran.setDbName(generateSqlTran.getDbName());
        batch.set_strsql(generateSqlTran.get_strsql());
        for (int j = 0; j < generateSqlTran.getListParameter().size(); j++) {
            DbParameter node = generateSqlTran.getListParameter().get(j);
            DbParameter dataParameter = new DbParameter();
            dataParameter.setParameterName(node.getParameterName());
            dataParameter.setParameterSize(node.getParameterSize());
            dataParameter.setParamenterType(node.getParamenterType());
            try {
                String Val = "";
                if (jsonObject.get(node.getSourceParameterName()) != null) {
                    Val = jsonObject.get(node.getSourceParameterName()).toString();
                }
//                dataParameter.setParameterVal(jsonObject.get(node.getSourceParameterName()));
                DbParameterSet.setDbType(dbName, dataParameter, dataParameter.getParamenterType().toString(), Val);

            } catch (Exception ex) {
                log.error("复制处理对象：异常(" + ex.toString() + ")");
                batch.getErrList().add(new GenerateErr("复制数据", ex.toString()));

            }
            batch.getListParameter().add(dataParameter);
        }
        return batch;

    }
    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName) {
        return sqlQueryParameter(dbName, tableName, null);
    }
    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName, JSONArray json) {
        StringBuilder StrSql = new StringBuilder();
        StrSql.append("SELECT * FROM " + tableName + " T WHERE 1=1 ");
        return sqlQueryParameter(dbName, tableName, StrSql, json, null);
    }
    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName, JSONArray json, List<Rps> rpsList) {
        StringBuilder StrSql = new StringBuilder();
        StrSql.append("SELECT * FROM " + tableName + " T WHERE 1=1 ");
        return sqlQueryParameter(dbName, tableName, StrSql, json, rpsList);
    }
    /**
     * 参数化查询
     *
     * @param dbName
     * @param tableName
     * @param strSql
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran sqlQueryParameter(@Nullable String dbName, String tableName, StringBuilder strSql, JSONArray json, List<Rps> rpsList) {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.setDbName(dbName);
        try {


            DocumentXml doc = new DocumentXml();

            try {

                doc = new DocumentXml();

                doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));

            } catch (Exception ex) {

                log.error(tableName + ".xml初始化失败" + "(初始化DocumentXml失败失败" + ex.toString());
                generateSqlTran.getErrList().add(new GenerateErr("初始化处理", "初始化DocumentXml失败失败" + ex.toString()));

            }

            generateSqlTran.set_XmlDocumentName(doc);
            ///初始化对象SQL生成类
            List<DbParameter> ListParamter = new ArrayList<DbParameter>();
            List<Rpc> rpcList = null;
            try {
                rpcList = DbParmentReplace.getParamenters(strSql);
            } catch (Exception ex) {
                log.error("Rpc取值时发生异常" + "(" + ex.toString() + ")");
                generateSqlTran.getErrList().add(new GenerateErr("取值处理", "Rpc失败" + ex.toString()));
                return generateSqlTran;
            }

            if (json != null) {
                if (rpcList.size() > 0) {

                    for (int i = 0; i < rpcList.size(); i++) {
                        Rpc rpc = rpcList.get(i);

                        for (int t = 1; t < json.size(); t += 2) {
                            JSONObject jsObject = json.getJSONObject(t);

                            if (rpc.getParamentName().toUpperCase(Locale.ROOT).equals(jsObject.getString("Id").toUpperCase(Locale.ROOT))) {

                                JSONObject valObject = JSONObject.parseObject(jsObject.toString());
                                if(!rpc.getTableAlias().isEmpty()){
                                    valObject.put("TableAlias",rpc.getTableAlias());
                                }else{
                                    if(valObject.get("TableAlias")!=null){
                                        valObject.remove("TableAlias");
                                    }
                                }
                                try {
                                    QueryParameter(dbName, valObject, null, strSql, doc, ListParamter, tableName);
                                    ////调用值参数化方法对象;
                                } catch (Exception ex) {
                                    log.error("Query参数处理发生异常" + "(" + ex.toString() + ")");
                                    generateSqlTran.getErrList().add(new GenerateErr("Query参数处理", ex.toString()));
                                }
//
//                                json.remove(t);
//                                json.remove(t - 1);
//                                break;
                            }


                        }
                    }
                    for (int i = 0; i < rpcList.size(); i++) {
                        Rpc rpc = rpcList.get(i);
                        for (int t = 1; t < json.size(); t += 2) {
                            JSONObject jsObject = json.getJSONObject(t);
                            if (rpc.getParamentName().toUpperCase(Locale.ROOT).equals(jsObject.getString("Id").toUpperCase(Locale.ROOT))) {
                                json.remove(t);
                                json.remove(t - 1);
                                break;
                            }
                        }
                    }
                }
            }
            if (json != null) {
                if (rpsList != null) {

                    for (int i = 0; i < rpsList.size(); i++) {
                        Rps rps = rpsList.get(i);

                        for (int t = 1; t < json.size(); t += 2) {
                            JSONObject jsObject = json.getJSONObject(t);

                            if (rps.getParamentName().equals(jsObject.getString("Id"))) {

                                JSONObject valObject = JSONObject.parseObject(jsObject.toString());
                                try {

                                    if(valObject.get("TableAlias")==null){
                                        valObject.put("TableAlias","T");
                                    }
                                    QueryParameter(dbName, valObject, rps.getSql(), strSql, doc, ListParamter, tableName);////调用值参数化方法对象;
                                } catch (Exception ex) {
                                    log.error("Query参数Rps处理发生异常" + "(" + ex.toString() + ")");
                                    generateSqlTran.getErrList().add(new GenerateErr("Query参数Rps处理", ex.toString()));
                                }

                                json.remove(t);
                                json.remove(t - 1);
                                break;
                            }


                        }
                    }
                }
            }
            if (json != null) {
                for (int i = 0; i < json.size(); i++) {
                    JSONObject jsObject = json.getJSONObject(i);
                    if (jsObject.get("Symbol") != null) {
                        try {
                            if (!ParamenterCheck.symbolCheck(jsObject.get("Symbol").toString())) {
                                log.error("符号参数：" + jsObject.get("Symbol").toString() + "不合法");
                                generateSqlTran.getErrList().add(new GenerateErr("参数处理", jsObject.get("Symbol") + "不合法"));
                            }
                        } catch (Exception ex) {
                            log.error("符号参数：" + jsObject.get("Symbol").toString() + "出现异常" + ex.toString());
                            generateSqlTran.getErrList().add(new GenerateErr("参数处理", jsObject.get("Symbol") + "不合法" + ex.toString()));
                        }

                    }
                    if (i % 2 == 0) {
                        try {
                            if (!ParamenterCheck.symbolCheck(jsObject.get("Symbol").toString())) {
                                log.error("符号参数：" + jsObject.get("Symbol").toString() + "不合法");
                                generateSqlTran.getErrList().add(new GenerateErr("参数处理", jsObject.get("Symbol") + "不合法"));
                            }
                        } catch (Exception ex) {
                            log.error("符号参数：" + jsObject.get("Symbol").toString() + "出现异常" + ex.toString());
                            generateSqlTran.getErrList().add(new GenerateErr("参数处理", jsObject.get("Symbol") + "不合法" + ex.toString() + ""));
                        }
                        strSql.append(" " + jsObject.get("Symbol").toString() + " ");
                    } else {
                        JSONObject valObject = JSONObject.parseObject(jsObject.toString());
                        try {
                            if(valObject.get("TableAlias")==null){
                                valObject.put("TableAlias","T");
                            }
                            QueryParameter(dbName, valObject, null, strSql, doc, ListParamter, tableName);
                            ////调用值参数化方法对象;

                        } catch (Exception ex) {
                            log.error("Query参数处理发生异常" + "(" + ex.toString() + ")");
                            generateSqlTran.getErrList().add(new GenerateErr("Query参数处理", ex.toString()));
                        }

                    }

                }
            }
            if (rpcList != null) {
                if (rpcList.size() > 0) {


                    for (int i = 0; i < rpcList.size(); i++) {
                        Rpc rpc = rpcList.get(i);

                        String paramentName="";
                        if(!rpc.getTableAlias().isEmpty()){
                            paramentName+=rpc.getTableAlias()+".";
                        }
                        paramentName+=rpc.getParamentName();
                        String Str = strSql.toString().replace(DbParmentReplace.getString(paramentName), " ");
                        strSql = new StringBuilder(Str);

                    }
                }
            }
            generateSqlTran.setListParameter(ListParamter);
            generateSqlTran.setTableName(tableName);
            generateSqlTran.set_strsql(dbConvertSql.convertStrSql(dbName, strSql.toString()));
        } catch (Exception ex) {
            log.error("表" + tableName + "查询处理：方法处理异常(" + ex.toString() + "");
            generateSqlTran.getErrList().add(new GenerateErr("方法处理", ex.toString()));

        }
        return generateSqlTran;
    }

    /**
     * 参数化字段读取
     *
     * @param dbName
     * @param jo
     * @param Sql
     * @param StrSql
     * @param TableColumnAttribute
     * @param ListParamter
     * @param tableName
     * @author liwei
     * @date: 2023/7/26
     **/
    public void QueryParameter(@Nullable String dbName, JSONObject jo, String Sql, StringBuilder StrSql, DocumentXml TableColumnAttribute, List<DbParameter> ListParamter, String tableName) throws Exception {
        String Key = jo.get("Id").toString();
        String Value = jo.get("Val").toString().trim();
        String Symbol = jo.get("Symbol").toString() == null ? "=" : jo.get("Symbol").toString();
        Object IsLook = jo.get("IsLook");
        String TableAlias = jo.get("TableAlias") == null ? "" : jo.get("TableAlias").toString()+".";
        Key = ParamenterCheck.noHTML(Key).toString();
        Value = ParamenterCheck.noHTML(Value).toString();
        if (!ParamenterCheck.symbolCheck(Symbol)) {
//            throw new Exception("参数不符合");
            log.error("查询参数名：" + Key + "-比较符号：" + Symbol + "-值：" + Value + "(比较符号不合法！)");

            throw new Exception("查询参数名：" + Key + "-比较符号：" + Symbol + "-值：" + Value + "(比较符号不合法！)");
        }
        try {
            DbParameter dbParameter = new DbParameter();
            dbParameter.setSourceParameterName(Key);
            Key = Key.toUpperCase();

            DocumentNodeXml documentNodeXml = new DocumentNodeXml();
            ParamenterCheck.getParameter(Key, TableColumnAttribute, documentNodeXml);
            if (documentNodeXml.getNode() == null) {
                if (!dbSaveTableXml.checkColumnXml(tableName, Key, dbName)) {
                    log.error("第一次验证：查询参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
                    throw new Exception("第一次验证：查询参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
                } else {
                    TableColumnAttribute.setDoc(dbSaveTableXml.saveTableXml(dbSaveTableXml.getTableXmlPath(tableName, dbName), tableName, dbName));
                    ParamenterCheck.getParameter(Key, TableColumnAttribute, documentNodeXml);
                    if (documentNodeXml.getNode() == null) {
                        log.error("第二次验证：查询参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
                        throw new Exception("第二次验证：查询参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
                    }
                }
            }
            String ParamterColumnTypeString = documentNodeXml.getNode().selectSingleNode("OracleType").getText();
            //获取XML节点值数据类型
            String ParamterColumnSizeString = documentNodeXml.getNode().selectSingleNode("OracleSize").getText();
            //获取XML节点值数据大小
            dbParameter.setParameterName(Key);
            if (Symbol.equals("Exist") || Symbol.equals("Not Exist")) {
                String Val = ExistSearch.excuteSearch(dbName, Key, ParamterColumnTypeString, Value);
                if (Val == null) {

                    Symbol = "=";
                } else {
                    Value = Val;
                }
            }
            try {
                DbParameterSet.setStrSql(dbName, Sql, ListParamter, StrSql, Key, Symbol, ParamterColumnTypeString, ParamterColumnSizeString, IsLook, Value,TableAlias);
            } catch (Exception ex) {
                log.error("查询参数名：" + Key + "-比较符号：" + Symbol + "-值：" + Value + "(在DbParameterSet.setStrSql 时发生异常" + ex.toString() + "！)");

                throw new Exception("查询参数名：" + Key + "-比较符号：" + Symbol + "-值：" + Value + "(在DbParameterSet.setStrSql 时发生异常" + ex.toString() + "！)");
            }

        } catch (Exception ex) {

            log.error("查询参数名：" + Key + "-比较符号：" + Symbol + "-值：" + Value + "(发生异常" + ex.toString() + "！)");

            throw new Exception("查询参数名：" + Key + "-比较符号：" + Symbol + "-值：" + Value + "(发生异常" + ex.toString() + "！)");

        }
    }
    /**
     * 字段读取参数化
     *
     * @param dbName
     * @param Key
     * @param Value
     * @param StrAfterSql
     * @param TableColumnAttribute
     * @param ListParameter
     * @param tableName
     * @author liwei
     * @date: 2023/7/26
     **/
    public void Parameter(@Nullable String dbName, String Key, Object Value, StringBuilder StrAfterSql, DocumentXml TableColumnAttribute, List<DbParameter> ListParameter, String tableName) throws Exception {
        DbParameter dbParameter = new DbParameter();
        dbParameter.setSourceParameterName(Key);
        Key = Key.toUpperCase();

        DocumentNodeXml documentNodeXml = new DocumentNodeXml();
        ParamenterCheck.getParameter(Key, TableColumnAttribute, documentNodeXml);
        if (documentNodeXml.getNode() == null) {

            if (!dbSaveTableXml.checkColumnXml(tableName, Key, dbName)) {
                log.error("第一次验证：数据处理参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
                throw new Exception("第一次验证：参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
            } else {
                TableColumnAttribute.setDoc(dbSaveTableXml.saveTableXml(dbSaveTableXml.getTableXmlPath(tableName, dbName), tableName, dbName));
                ParamenterCheck.getParameter(Key, TableColumnAttribute, documentNodeXml);
                if (documentNodeXml.getNode() == null) {
                    log.error("第二次验证：数据处理参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
                    throw new Exception("第二次验证：参数名：" + Key + "-在" + tableName + ".Xml中不存在此字段,如特殊字段，请在系统中XML管理中手动添加;输入的值为：" + Value + "");
                }
            }

        }
        String ParamterColumnTypeString = documentNodeXml.getNode().selectSingleNode("OracleType").getText();//获取XML
        // 节点值数据类型
        String ParamterColumnSizeString = documentNodeXml.getNode().selectSingleNode("OracleSize").getText();//获取XML
        // 节点值数据大小
        Value = ParamenterCheck.noHTML(Value);


        StringBuilder stringBuilderErr = new StringBuilder();
        dbParameter.setParameterName(Key);
        try {
            DbParameterSet.setVal(dbName, dbParameter, Key, ParamterColumnTypeString, ParamterColumnSizeString, Value);
        } catch (Exception ex) {
            log.error("数据处理参数名：" + Key + "对应值：" + Value + "在setVal 时发生异常：" + ex.toString());
            throw new Exception("参数名：" + Key + "对应值：" + Value + "在setVal 时发生异常：" + ex.toString());
        }
        ListParameter.add(dbParameter);
    }
    /**
     * 插入之前字符串拼接
     *
     * @param dbName
     * @param tableName
     * @param doc
     * @param ex
     * @param StrBeforeSql
     * @param StrAfterSql
     * @author liwei
     * @date: 2023/7/26
     **/
    public void InsertBefore(@Nullable String dbName, String tableName, DocumentXml doc, GenerateSqlTran ex, StringBuilder StrBeforeSql, StringBuilder StrAfterSql) {
        StrBeforeSql.append("INSERT INTO "); ///添加数据库insert 关系词
        StrBeforeSql.append(tableName); ///添加表名
        StrBeforeSql.append("("); ///添加括号
        //初始化对象StringBuilder（此处为INSERT 后半部分（值））

        StrAfterSql.append("VALUES(");    //添加数据库values 关键词
    }
    /**
     * 插入之后字符串拼接
     *
     * @param dbName
     * @param tableName
     * @param doc
     * @param ex
     * @param StrBeforeSql
     * @param StrAfterSql
     * @author liwei
     * @date: 2023/7/26
     **/
    public void InsertAfter(@Nullable String dbName, String tableName, DocumentXml doc, GenerateSqlTran ex, StringBuilder StrBeforeSql, StringBuilder StrAfterSql) {
        StrBeforeSql.delete(StrBeforeSql.length() - 1, StrBeforeSql.length());////初始化对象StringBuilder（此处为INSERT
        // 前半部分（字段））截取最后逗号
        StrBeforeSql.append(")");////初始化对象StringBuilder（此处为INSERT 前半部分（字段））添加结束符括号

        StrAfterSql.delete(StrAfterSql.length() - 1, StrAfterSql.length());//初始化对象StringBuilder（此处为INSERT
        // 后半部分（值）））截取最后逗号

        StrAfterSql.append(")");//初始化对象StringBuilder（此处为INSERT 后半部分（值）））添加结束符括号
        ex.setTableName(tableName);
        ex.set_strsql(dbConvertSql.convertStrSql(dbName, StrBeforeSql.toString() + StrAfterSql.toString())); ////对象拼接并赋

    }
    /**
     * 修改之前字符串拼接
     *
     * @param dbName
     * @param tableName
     * @param doc
     * @param ex
     * @param StrBeforeSql
     * @param StrAfterSql
     * @author liwei
     * @date: 2023/7/26
     **/
    public void UpdateBefore(@Nullable String dbName, String tableName, DocumentXml doc, GenerateSqlTran ex, StringBuilder StrBeforeSql, StringBuilder StrAfterSql) {
        if (doc.getDoc() == null) {


            doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));
        }
        if (doc.getDoc() == null) {

            return;
        }
        ///初始化对象StringBuilder（此处为INSERT 前半部分（字段））

        StrBeforeSql.append("UPDATE ");///添加数据库UPDATE 关系词
        StrBeforeSql.append(tableName);//添加表名
        StrBeforeSql.append(" SET ");//添加关键词SET

        StrAfterSql.append("  WHERE 1=1 ");    //添加数据库values 关键词
    }
    /**
     * 修改之后字符串拼接
     *
     * @param dbName
     * @param tableName
     * @param doc
     * @param ex
     * @param StrBeforeSql
     * @param StrAfterSql
     * @author liwei
     * @date: 2023/7/26
     **/
    public void UpdateAfter(@Nullable String dbName, String tableName, DocumentXml doc, GenerateSqlTran ex, StringBuilder StrBeforeSql, StringBuilder StrAfterSql) {
        StrBeforeSql.delete(StrBeforeSql.length() - 1, StrBeforeSql.length());////初始化对象StringBuilder（此处为INSERT
        // 前半部分（字段））截取最后逗号

//        StrAfterSql.delete(StrAfterSql.length() - 1, StrAfterSql.length());//初始化对象StringBuilder（此处为INSERT
//        后半部分（值）））截取最后逗号

        ex.setTableName(tableName);
        ex.set_strsql(dbConvertSql.convertStrSql(dbName, StrBeforeSql.toString() + StrAfterSql.toString())); ////对象拼接并赋值给生成类

    }
    /**
     * 删除之前字符串拼接
     *
     * @param dbName
     * @param tableName
     * @param doc
     * @param ex
     * @param StrBeforeSql
     * @param StrAfterSql
     * @author liwei
     * @date: 2023/7/26
     **/
    public void DeleteBefore(@Nullable String dbName, String tableName, DocumentXml doc, GenerateSqlTran ex, StringBuilder StrBeforeSql, StringBuilder StrAfterSql) {
        if (doc.getDoc() == null) {
            doc.setDoc(dbSaveTableXml.getTableXml(tableName, dbName));
        }
        if (doc.getDoc() == null) {

            return;
        }
        ///初始化对象StringBuilder（此处为INSERT 前半部分（字段））

        StrBeforeSql.append("DELETE  ");///添加数据库UPDATE 关系词

        dbConvertSql.deleteStrSql(dbName, StrBeforeSql);

        StrBeforeSql.append(tableName);//添加表名


        StrAfterSql.append("  WHERE 1=1 ");    //添加数据库values 关键词
    }
    /**
     * 删除之后字符串拼接
     *
     * @param dbName
     * @param tableName
     * @param doc
     * @param ex
     * @param StrBeforeSql
     * @param StrAfterSql
     * @author liwei
     * @date: 2023/7/26
     **/
    public void DeleteAfter(@Nullable String dbName, String tableName, DocumentXml doc, GenerateSqlTran ex, StringBuilder StrBeforeSql, StringBuilder StrAfterSql) {
        ex.setTableName(tableName);
        ex.set_strsql(StrBeforeSql.toString() + StrAfterSql.toString()); ////对象拼接并赋值给生成类
    }

    public boolean checkParameter(String column, GenerateSqlTran generateSqlTran) {
        column = column.toUpperCase();
        DocumentNodeXml documentNodeXml = new DocumentNodeXml();
        try {
            ParamenterCheck.getParameter(column, generateSqlTran.get_XmlDocumentName(), documentNodeXml);
            if (documentNodeXml.getNode() == null) {
                return false;
            }
        } catch (Exception ex) {
            return false;
        }
        return true;
    }
}
