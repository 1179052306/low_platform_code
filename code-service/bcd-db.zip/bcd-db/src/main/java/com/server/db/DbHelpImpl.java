package com.server.db;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.dataset.DataSet;
import com.server.dataset.DataTable;
import com.server.params.DbKeepTran;
import com.server.params.GenerateSqlTran;
import com.server.params.ProceduresParameter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @Description 数据库执行接口
 * @Author liwei
 * @Date 2023/7/24 17:07
 **/
@Component
@Service
public interface DbHelpImpl {

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    DataTable query(@Nullable String dbName, String sql) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param listSql
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    DataSet query(@Nullable String dbName, List<String> listSql) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param generateSqlTran
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    DataTable query(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sqlTranList
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    DataSet queryTran(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryJson(@Nullable String dbName, String sql) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param listSql
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryJson(@Nullable String dbName, List<String> listSql) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param generateSqlTran
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryJson(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sqlTranList
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryTranJson(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sqlTranList
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONObject queryTranJsonObject(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception;
    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @param cacheKey
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    DataTable query(@Nullable String dbName, String sql, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param listSql
     * @param cacheKey
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    DataSet query(@Nullable String dbName, List<String> listSql, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param generateSqlTran
     * @param cacheKey
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    DataTable query(@Nullable String dbName, GenerateSqlTran generateSqlTran, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sqlTranList
     * @param cacheKey
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    DataSet queryTran(@Nullable String dbName, List<GenerateSqlTran> sqlTranList, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryJson(@Nullable String dbName, String sql, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param listSql
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryJson(@Nullable String dbName, List<String> listSql, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param generateSqlTran
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryJson(@Nullable String dbName, GenerateSqlTran generateSqlTran, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sqlTranList
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    JSONArray queryTranJson(@Nullable String dbName, List<GenerateSqlTran> sqlTranList, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    List<Map<String, Object>> queryMap(@Nullable String dbName, String sql) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @param cacheKey
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    List<Map<String, Object>> queryMap(@Nullable String dbName, String sql, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param generateSqlTran
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    List<Map<String, Object>> queryMap(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param generateSqlTran
     * @param cacheKey
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    List<Map<String, Object>> queryMap(@Nullable String dbName, GenerateSqlTran generateSqlTran, String cacheKey) throws Exception;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int queryCount(@Nullable String dbName, String sql) throws Exception;

    /**
     * 查询SQL数据的count
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int queryCount(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception;

    /**
     * 查询SQL数据的count
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int queryJsonCount(@Nullable String dbName, String sql) throws Exception;

    /**
     * 查询SQL数据的count
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int queryJsonCount(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception;

    /**
     * 查询SQL数据的count
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int queryMapCount(@Nullable String dbName, String sql) throws Exception;

    /**
     * 查询SQL数据的count
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int queryMapCount(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception;

    /**
     * sql执行操作，增删改
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int executeSql(@Nullable String dbName, String sql) throws Exception;

    /**
     * sql执行操作，增删改
     *
     * @param dbName
     * @param listSql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int executeSql(@Nullable String dbName, List<String> listSql) throws Exception;

    List<String> executeSqlRes(@Nullable String dbName, List<String> listSql) throws Exception ;
    /**
     * sql执行操作，增删改
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int executeSql(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception;

    /**
     * sql集合执行操作，增删改
     *
     * @param dbName
     * @param sqlTranList
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    int executeSqlTran(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception;

    void callProcedures(@Nullable String dbName, ProceduresParameter proceduresParameter)throws Exception;
    /**
     * 长事务处理
     *
     * @param
     * @param
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    Boolean keepSqlTran(DbKeepTran dbKeepTran) throws Exception;

    Boolean keepExecute(DbKeepTran dbKeepTran,Boolean  execute) throws Exception;

}
