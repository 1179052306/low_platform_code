package com.server.params;

/**
 * @Description 加密类型
 * @Author liwei
 * @Date 2023/7/26 10:23
 **/
public enum DateIntervalType {
    year("YEAR"),
    month("MONTH"),
    week("WEEK"),
    day("DAY"),
    hour("HOUR"),
    minute("MINUTE"),
    second("SECOND");
    DateIntervalType(String intervalType){

        this.intervalType=intervalType;
    }
    public String getIntervalType() {
        return intervalType;
    }

    public void setIntervalType(String intervalType) {
        this.intervalType = intervalType;
    }

    private String intervalType;




}
