//package com.server;
//
//import com.server.db.MultiDataSourceHolder;
//import lombok.extern.slf4j.Slf4j;
//import org.aspectj.lang.annotation.After;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StringUtils;
//
//@Slf4j
//@Aspect
//@Component
//public class DataSourceAspect {
//
//    @Pointcut(value = "@within(com.server.DefaultDataSource) || @annotation(com.server.DefaultDataSource)")
//    public void dataSourcePointCut(){}
//
//
//    @Before("dataSourcePointCut() && @annotation(multiDataSource)")
//    public void before(DefaultDataSource multiDataSource){
//
//        String dbName = multiDataSource.dbName();
//
//        if (StringUtils.hasLength(dbName)){
//
//            MultiDataSourceHolder.setDatasource(multiDataSource.dbName());
//            log.info("current dataSourceName ====== "+dbName);
//
//        }else {
//
//            log.info("switch datasource fail, use default, or please configure the data source for the annotations,");
//
//        }
//    }
//
//
//    @After("dataSourcePointCut()")
//    public void after(){
//        MultiDataSourceHolder.clearDataSource();
//    }
//}
