package com.server.thread;

import com.server.DbComposite;
import com.server.thread.table.ThreadTable;

/**
 * @author lw
 * @date: 2025/3/5
 * @description:
 **/
public class ThreadsObject {

    public ThreadsObject() {

    }
    public ThreadsObject(String threadName, DbComposite dbComposite, String project) {
        this.threadName = threadName;
        this.dbComposite = dbComposite;
        this.project = project;
    }
    ThreadTable threadTable;
    String threadName;
    ThreadState threadState=new ThreadState();
    DbComposite dbComposite;
    ThreadBase threadBase;
    String project = "project";
    String tenantId;
    boolean destroy = true;
    int sleep=600000;


    public boolean isDestroy() {
        return destroy;
    }

    public void setDestroy(boolean destroy) {
        this.destroy = destroy;
    }
    public String getThreadName() {
        return threadName;
    }

    public void setThreadName(String threadName) {
        this.threadName = threadName;
    }

    public ThreadState getThreadState() {
        return threadState;
    }

    public void setThreadState(ThreadState threadState) {
        this.threadState = threadState;
    }

    public DbComposite getDbComposite() {
        return dbComposite;
    }

    public void setDbComposite(DbComposite dbComposite) {
        this.dbComposite = dbComposite;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public int getSleep() {
        return sleep;
    }

    public void setSleep(int sleep) {
        this.sleep = sleep;
    }

    public ThreadBase getThread() {
        return threadBase;
    }

    public void setThread(ThreadBase threadBase) {
        this.threadBase = threadBase;
    }

    public ThreadTable getThreadTable() {
        return threadTable;
    }

    public void setThreadTable(ThreadTable threadTable) {
        this.threadTable = threadTable;
    }

}
