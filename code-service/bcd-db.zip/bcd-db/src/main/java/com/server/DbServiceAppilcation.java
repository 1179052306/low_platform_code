package com.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

//@SpringBootApplication
//
//public class DbServiceAppilcation {
//    public static  void  main(String[]args){
//
//        SpringApplication.run(DbServiceAppilcation.class,args);
//
//    }
//
//}
