package com.server.params;


import lombok.extern.slf4j.Slf4j;


/**
 * @Description 参数检查
 * @Author liwei
 * @Date 2023/7/26 10:21
 **/
@Slf4j
public class ParamenterCheck{

    /**
     * 检查符号是否合法
     *
     * @param Symbol
     * @return Boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public static Boolean symbolCheck(String Symbol)
    {
        try
        {
            Boolean result = true;

            Symbol = noHTML(Symbol).toString();

            if (!Symbol.equals("=") && !Symbol.equals("<>") &&!Symbol.equals("and") && !Symbol.equals("or") && !Symbol.equals("like") && !Symbol.equals("not like") && !Symbol.equals("<") && !Symbol.equals(">") && !Symbol.equals("<=") && !Symbol.equals(">=")&&!Symbol.equals("Exist")&&!Symbol.equals("Not Exist"))
            {
                result = false;
            }
            return result;
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    /**
     * 检查内容是否包含特殊字符
     *
     * @param Htmlstring
     * @return Object
     * @author liwei
     * @date: 2023/7/26
     **/
    public static Object noHTML(Object Htmlstring)
    {
        if (Htmlstring == null)
        {
            return "";
        }
        else
        {
            if(Htmlstring.getClass().getName().contains("String")){
                return Htmlstring.toString();
            }
            //删除脚本
            //Htmlstring = Regex.Replace(Htmlstring, @"<script[^>]*?>.*?</script>", "", RegexOptions.IgnoreCase);
            ////删除HTML
            //Htmlstring = Regex.Replace(Htmlstring, @"<(.[^>]*)>", "", RegexOptions.IgnoreCase);
            ////Htmlstring = Regex.Replace(Htmlstring, @"([/r/n])[/s]+", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"-->", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"<!--.*", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"""", "", RegexOptions.IgnoreCase);
            //if (!Htmlstring.Contains("to_date"))
            //{
            //    Htmlstring = Regex.Replace(Htmlstring, @"'", "", RegexOptions.IgnoreCase);
            //}
            //Htmlstring = Regex.Replace(Htmlstring, @"&(quot|#34);", "\"", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(amp|#38);", "&", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(lt|#60);", "<", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(gt|#62);", ">", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(nbsp|#160);", " ", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(iexcl|#161);", "/xa1", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(cent|#162);", "/xa2", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(pound|#163);", "/xa3", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&(copy|#169);", "/xa9", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, @"&#(/d+);", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "xp_cmdshell", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "javascript", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "alert", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "iframe ", "", RegexOptions.IgnoreCase);
            ////删除与数据库相关的词
            //Htmlstring = Regex.Replace(Htmlstring, "select", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "insert", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "delete from", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "count''", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "drop table", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "truncate", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "asc", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "mid", "", RegexOptions.IgnoreCase);
            //// Htmlstring = Regex.Replace(Htmlstring, "char", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "xp_cmdshell", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "exec master", "", RegexOptions.IgnoreCase);
            //Htmlstring = Regex.Replace(Htmlstring, "net localgroup administrators", "", RegexOptions.IgnoreCase);
            ////Htmlstring = Regex.Replace(Htmlstring, "and", "", RegexOptions.IgnoreCase);
            //Htmlstring = ReplaceVal(Htmlstring);
            return Htmlstring;

        }

    }

    public static void getParameter(String Key, DocumentXml TableColumnAttribute, DocumentNodeXml node)throws Exception
    {
        try {
            Key = Key.toUpperCase();

            node.setNode( TableColumnAttribute.getDoc().selectSingleNode("//ColumnAttribute[@ID='"+Key+"']"));
        }catch (Exception ex){
            log.error("参数"+Key+"：在查询节点时发生异常("+ex.toString() + "");
            throw new Exception("参数"+Key+"在查询节点时发生异常"+ex.toString());
        }

    }
}
