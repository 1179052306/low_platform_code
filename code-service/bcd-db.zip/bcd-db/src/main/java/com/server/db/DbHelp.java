package com.server.db;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.dataset.*;
import com.server.encryption.EncryData;
import com.server.generate.SQLSanitizer;
import com.server.params.*;
import com.server.redis.RedisService;
import com.server.syntax.DbBatchRes;
import com.server.syntax.DbConvertSql;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;

@Configuration
@Component
@Repository
@Service
@Slf4j


/**
 * @Description 数据库操作类
 * @Author liwei
 * @Date 2023/7/26 9:43     
 **/
public class DbHelp implements DbHelpImpl {


    @Resource
    public MultiDataSource dataSource;

    @Resource
    private RedisService redisService;

    @Resource
    private DbConvertSql dbConvertSql;

    @Resource
    private DbBatchRes dbBatchRes;

    @Resource
    InterceptTenant interceptTenant;
    @Resource
    Tenant tenant;

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param sql
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataTable query(@Nullable String dbName, String sql) throws Exception {
        DataTable data = null;
        ResultSet rs = null;
        Connection conn = conn(dbName);

        PreparedStatement preparedStatement = null;
        try {

            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, sql));
            rs = preparedStatement.executeQuery();
            log.info("SQL执行成功！");
            data = resultToDataTable(rs);

            if (data.size() > 1000) {
                log.error(sql + "数据返回超过1000条数据");
            }
            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);

            conn.rollback();
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }


        return data;
    }

    /**
     * 查询SQL操作,将数据写入缓存
     *
     * @param dbName
     * @param sql
     * @param cacheKey
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataTable query(@Nullable String dbName, String sql, String cacheKey) throws Exception {
        DataTable data = query(dbName, sql);
        setCacheObject(cacheKey, data);

        return data;
    }

    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param listSql
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataSet query(@Nullable String dbName, List<String> listSql) throws Exception {
        DataSet data = new DataSet();
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {
            for (int i = 0; i < listSql.size(); i++) {
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, listSql.get(i)));
                rs = preparedStatement.executeQuery();
                log.info("SQL执行成功！");

                DataTable dt = resultToDataTable(rs);
                if (dt.size() > 1000) {
                    log.error(listSql.get(i) + "数据返回超过1000条数据");
                }
                data.add(dt);
                preparedStatement.close();
            }
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }
        listSql.clear();
        return data;
    }


    /**
     * 查询SQL操作, 将数据写入缓存
     *
     * @param dbName
     * @param listSql
     * @param cacheKey
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataSet query(@Nullable String dbName, List<String> listSql, String cacheKey) throws Exception {
        DataSet data = query(dbName, listSql);
        setCacheObject(cacheKey, data);
        return data;
    }


    /**
     * 查询SQL操作
     *
     * @param dbName
     * @param generateSqlTran
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataTable query(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception {
        if (!checkGenerate(dbName, generateSqlTran)) {
            throw new Exception("处理对象中存在异常对象");
        }
        DataTable data = null;
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {
            if (preparedStatement != null) {
                preparedStatement.clearParameters();
                preparedStatement.close();
            }

            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));

            if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {

                setVal(conn, generateSqlTran, preparedStatement);
            }

            rs = preparedStatement.executeQuery();
            log.info("SQL执行成功！");

            data = resultToDataTable(rs);
            if (data.size() > 1000) {
                log.error(generateSqlTran.get_strsql() + "数据返回超过1000条数据");
            }
            if (generateSqlTran.getEncryList().size() > 0) {

                data = EncryData.encryDataTable(data, generateSqlTran);
            }
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }
        return data;
    }

    /**
     * 查询SQL操作, 将数据写入缓存
     *
     * @param dbName
     * @param generateSqlTran
     * @param cacheKey
     * @return DataTable
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataTable query(@Nullable String dbName, GenerateSqlTran generateSqlTran, String cacheKey) throws Exception {
        DataTable data = query(dbName, generateSqlTran);
        setCacheObject(cacheKey, data);

        return data;
    }


    /**
     * 查询SQL数据的count
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int queryCount(@Nullable String dbName, String sql) throws Exception {
        return query(dbName, sql).size();
    }


    /**
     * 查询SQL数据的count
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int queryCount(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception {
        return query(dbName, generateSqlTran).size();
    }

    /**
     * 查询SQL集合数据
     *
     * @param dbName
     * @param sqlTranList
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataSet queryTran(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception {
        if (!checkListGenerate(dbName, sqlTranList)) {
            throw new Exception("处理对象中存在异常对象");
        }
        DataSet data = new DataSet();
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {

            for (int i = 0; i < sqlTranList.size(); i++) {
                GenerateSqlTran generateSqlTran = sqlTranList.get(i);
                if (preparedStatement != null) {
                    preparedStatement.clearParameters();
                    preparedStatement.close();
                }
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));

                if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {

                    setVal(conn, generateSqlTran, preparedStatement);
                }

                rs = preparedStatement.executeQuery();
                log.info("SQL执行成功！");
                DataTable dt = resultToDataTable(rs);
                if (dt.size() > 1000) {
                    log.error(generateSqlTran.get_strsql() + "数据返回超过1000条数据");
                }
                if (!StringUtils.isBlank(generateSqlTran.getTableName())) {
                    dt.setTableName(generateSqlTran.getTableName() + generateSqlTran.getAliasName());
                }
                if (generateSqlTran.getEncryList().size() > 0) {
                    data.add(EncryData.encryDataTable(dt, generateSqlTran));

                } else {
                    data.add(dt);
                }
            }

            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }
        return data;
    }

    /**
     * 查询SQL集合数据，并写入缓存
     *
     * @param dbName
     * @param sqlTranList
     * @param cacheKey
     * @return DataSet
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public DataSet queryTran(@Nullable String dbName, List<GenerateSqlTran> sqlTranList, String cacheKey) throws Exception {
        DataSet data = queryTran(dbName, sqlTranList);
        setCacheObject(cacheKey, data);
        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sql
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryJson(@Nullable String dbName, String sql) throws Exception {
        JSONArray data = null;
        ResultSet rs = null;
        Connection conn = conn(dbName);

        PreparedStatement preparedStatement = null;
        try {

            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, sql));
            rs = preparedStatement.executeQuery();
            log.info("SQL执行成功！");
            data = resultToJSONArray(rs);
            if (data.size() > 1000) {
                log.error(sql + "数据返回超过1000条数据");
            }
            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }

        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sql
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryJson(@Nullable String dbName, String sql, String cacheKey) throws Exception {
        JSONArray data = queryJson(dbName, sql);
        setCacheObject(cacheKey, data);
        return data;
    }


    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param listSql
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryJson(@Nullable String dbName, List<String> listSql) throws Exception {
        JSONArray data = new JSONArray();
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {


            for (int i = 0; i < listSql.size(); i++) {


                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, listSql.get(i)));

                rs = preparedStatement.executeQuery();
                log.info("SQL执行成功！");
                JSONArray d = resultToJSONArray(rs);
                if (d.size() > 1000) {
                    log.error( listSql.get(i) + "数据返回超过1000条数据");
                }
                data.add(d);
                preparedStatement.close();

            }

            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }
        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param listSql
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryJson(@Nullable String dbName, List<String> listSql, String cacheKey) throws Exception {
        JSONArray data = queryJson(dbName, listSql);
        setCacheObject(cacheKey, data);
        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param generateSqlTran
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryJson(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception {
        if (!checkGenerate(dbName, generateSqlTran)) {
            throw new Exception("处理对象中存在异常对象");
        }
        JSONArray data = null;
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {
            if (preparedStatement != null) {
                preparedStatement.clearParameters();
                preparedStatement.close();
            }

            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));
            if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {

                setVal(conn, generateSqlTran, preparedStatement);
            }

            rs = preparedStatement.executeQuery();
            log.info("SQL执行成功！");
            data = resultToJSONArray(rs);
            if (data.size() > 1000) {
                log.error(  generateSqlTran.get_strsql()+ "数据返回超过1000条数据");
            }
            if (generateSqlTran.getEncryList().size() > 0) {
                data = EncryData.encryJson(data, generateSqlTran);

            }
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }

        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param generateSqlTran
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryJson(@Nullable String dbName, GenerateSqlTran generateSqlTran, String cacheKey) throws Exception {
        JSONArray data = queryJson(dbName, generateSqlTran);
        setCacheObject(cacheKey, data);
        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sqlTranList
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryTranJson(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception {
        if (!checkListGenerate(dbName, sqlTranList)) {
            throw new Exception("处理对象中存在异常对象");
        }
        JSONArray data = new JSONArray();

        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {
            for (int i = 0; i < sqlTranList.size(); i++) {
                GenerateSqlTran generateSqlTran = sqlTranList.get(i);
                if (preparedStatement != null) {
                    preparedStatement.clearParameters();
                    preparedStatement.close();
                }
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));

                if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {

                    setVal(conn, generateSqlTran, preparedStatement);
                }

                rs = preparedStatement.executeQuery();
                log.info("SQL执行成功！");
                JSONArray d= resultToJSONArray(rs);
                if (d.size() > 1000) {
                    log.error(  generateSqlTran.get_strsql()+ "数据返回超过1000条数据");
                }
                if (generateSqlTran.getEncryList().size() > 0) {

                    data.add(EncryData.encryJson(d, generateSqlTran));
                } else {
                    data.add(d);
                }
            }

            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }
        sqlTranList.clear();
        return data;
    }


    @Override
    public JSONObject queryTranJsonObject(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception {
        if (!checkListGenerate(dbName, sqlTranList)) {
            throw new Exception("处理对象中存在异常对象");
        }
        JSONObject data = new JSONObject();
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {
            for (int i = 0; i < sqlTranList.size(); i++) {
                GenerateSqlTran generateSqlTran = sqlTranList.get(i);
                if (preparedStatement != null) {
                    preparedStatement.clearParameters();
                    preparedStatement.close();
                }
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));

                if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {

                    setVal(conn, generateSqlTran, preparedStatement);
                }

                rs = preparedStatement.executeQuery();
                log.info("SQL执行成功！");
                JSONArray json = resultToJSONArray(rs);
                if (json.size() > 1000) {
                    log.error(  generateSqlTran.get_strsql()+ "数据返回超过1000条数据");
                }
                String Key = i + "";
                if (!StringUtils.isBlank(generateSqlTran.getTableName())) {
                    Key = generateSqlTran.getTableName() + generateSqlTran.getAliasName();
                }
                if (generateSqlTran.getEncryList().size() > 0) {
                    data.put(Key, EncryData.encryJson(json, generateSqlTran));
                } else {
                    data.put(Key, json);
                }
            }

            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }
        sqlTranList.clear();
        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sqlTranList
     * @param cacheKey
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray queryTranJson(@Nullable String dbName, List<GenerateSqlTran> sqlTranList, String cacheKey) throws Exception {
        JSONArray data = queryTranJson(dbName, sqlTranList);
        setCacheObject(cacheKey, data);
        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int queryJsonCount(@Nullable String dbName, String sql) throws Exception {
        return queryJson(dbName, sql).size();
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int queryJsonCount(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception {
        return queryJson(dbName, generateSqlTran).size();
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sql
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public List<Map<String, Object>> queryMap(@Nullable String dbName, String sql) throws Exception {
        List<Map<String, Object>> data = null;
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, sql));
            rs = preparedStatement.executeQuery();
            log.info("SQL执行成功！");
            data = resultToMap(rs);
            if (data.size() > 1000) {
                log.error(  sql+ "数据返回超过1000条数据");
            }
            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }

        return data;
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sql
     * @param cacheKey
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public List<Map<String, Object>> queryMap(@Nullable String dbName, String sql, String cacheKey) throws Exception {
        List<Map<String, Object>> data = queryMap(dbName, sql);
        setCacheObject(cacheKey, data);
        return data;
    }


    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param generateSqlTran
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public List<Map<String, Object>> queryMap(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception {
        if (!checkGenerate(dbName, generateSqlTran)) {
            throw new Exception("处理对象中存在异常对象");
        }
        List<Map<String, Object>> data = null;
        ResultSet rs = null;
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        try {
            if (preparedStatement != null) {
                preparedStatement.clearParameters();
            }
            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));
            if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {

                setVal(conn, generateSqlTran, preparedStatement);
            }

            rs = preparedStatement.executeQuery();
            log.info("SQL执行成功！");
            data = resultToMap(rs);
            if (data.size() > 1000) {
                log.error(generateSqlTran.get_strsql()+ "数据返回超过1000条数据");
            }
            if (generateSqlTran.getEncryList().size() > 0) {
                data = EncryData.encryMap(data, generateSqlTran);

            }
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, preparedStatement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, rs);
        }
        return data;
    }


    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param generateSqlTran
     * @param cacheKey
     * @return List<Map < String, Object>>
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public List<Map<String, Object>> queryMap(@Nullable String dbName, GenerateSqlTran generateSqlTran, String cacheKey) throws Exception {
        List<Map<String, Object>> data = queryMap(dbName, generateSqlTran);
        setCacheObject(cacheKey, data);
        return data;
    }


    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int queryMapCount(@Nullable String dbName, String sql) throws Exception {
        return queryMap(dbName, sql).size();
    }

    /**
     * 查询SQL数据
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int queryMapCount(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception {
        return queryMap(dbName, generateSqlTran).size();
    }


    /**
     * sql执行操作，增删改
     *
     * @param dbName
     * @param sql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int executeSql(@Nullable String dbName, String sql) throws Exception {
        int res = 0;
        Connection conn = conn(dbName);

        PreparedStatement preparedStatement = null;
        try {

            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, sql));
            res += preparedStatement.executeUpdate();
            log.info("SQL执行成功！");
            conn.commit();
        } catch (SQLException e) {
            log.error("执行异常：" + e);
            conn.rollback();
            res = 0;
            e.printStackTrace();
            close(conn, preparedStatement);
            if (res == 0) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement);
        }
        return res;
    }


    /**
     * sql执行操作，增删改
     *
     * @param dbName
     * @param listSql
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int executeSql(@Nullable String dbName, List<String> listSql) throws Exception {
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        int res = 0;
        try {
            for (int i = 0; i < listSql.size(); i++) {

                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, listSql.get(i)));
                res += preparedStatement.executeUpdate();
                log.info("第" + (i + 1) + "行SQL执行成功！");
                preparedStatement.close();
            }

            conn.commit();
        } catch (SQLException e) {
            log.error("执行异常：" + e);
            res = 0;
            conn.rollback();
            e.printStackTrace();
            close(conn, preparedStatement);
            if (res == 0) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement);
        }
        listSql.clear();
        return res;
    }

    @Override
    public List<String> executeSqlRes(@Nullable String dbName, List<String> listSql) throws Exception {
        List<String> returnInfo = new ArrayList<>();
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        int res = 0;
        int index = 0;
        try {

            for (int i = 0; i < listSql.size(); i++) {
                index = i;
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, listSql.get(i)));
                res += preparedStatement.executeUpdate();
                returnInfo.add("Sql:" + listSql.get(i) + "执行成功");
                log.info("第" + (i + 1) + "行SQL执行成功！");
                preparedStatement.close();
            }

            conn.commit();
        } catch (SQLException e) {
            log.error("执行异常：" + e);
            returnInfo.add("Sql:" + listSql.get(index) + "执行异常" + e.toString());
            res = 0;
            conn.rollback();
            e.printStackTrace();
            close(conn, preparedStatement);
            if (res == 0) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement);
        }
        listSql.clear();
        return returnInfo;
    }

    /**
     * sql执行操作，增删改
     *
     * @param dbName
     * @param generateSqlTran
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int executeSql(@Nullable String dbName, GenerateSqlTran generateSqlTran) throws Exception {
        if (!checkGenerate(dbName, generateSqlTran)) {
            throw new Exception("处理对象中存在异常对象");

        }
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;
        int res = 0;
        try {
            boolean excute = true;
            GenerateSqlTran SqlTran = generateSqlTran;
            if (preparedStatement != null) {
                preparedStatement.clearParameters();
                preparedStatement.close();
            }

            preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, SqlTran.get_strsql()));
            if (SqlTran.getListParameter() != null && SqlTran.getListParameter().size() > 0) {

                setVal(conn, SqlTran, preparedStatement);
            }
            if (SqlTran.getListBatch().size() > 0) {
                preparedStatement.addBatch();
                for (int j = 0; j < SqlTran.getListBatch().size(); j++) {
                    GenerateSqlTran batchSqlTran = SqlTran.getListBatch().get(j);
                    if (batchSqlTran.getListParameter() != null && batchSqlTran.getListParameter().size() > 0) {
                        setVal(conn, batchSqlTran, preparedStatement);
                    }
                    preparedStatement.addBatch();
                }
                int[] num = preparedStatement.executeBatch();
                log.info("批量SQL执行成功！");
                preparedStatement.clearBatch();
                int resnum = dbBatchRes.batchRes(dbName, num);
                res += resnum;
                if (resnum == 0) {
                    excute = false;
                }

            } else {
                res += preparedStatement.executeUpdate();
                log.info("SQL执行成功！");
            }
            if (!excute) {
                conn.rollback();
            } else {
                conn.commit();
            }


        } catch (SQLException e) {
            log.error("执行异常：" + e);
            conn.rollback();
            res = 0;
            e.printStackTrace();
            close(conn, preparedStatement);
            if (res == 0) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement);
        }

        return res;
    }

    /**
     * sql集合执行操作，增删改
     *
     * @param dbName
     * @param sqlTranList
     * @return int
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public int executeSqlTran(@Nullable String dbName, List<GenerateSqlTran> sqlTranList) throws Exception {
        if (!checkListGenerate(dbName, sqlTranList)) {
            throw new Exception("处理对象中存在异常对象");

        }
        Connection conn = conn(dbName);
        PreparedStatement preparedStatement = null;

        int res = 0;
        try {
            boolean excute = true;
            for (int i = 0; i < sqlTranList.size(); i++) {

                if (!excute) {
                    break;
                }
                GenerateSqlTran generateSqlTran = sqlTranList.get(i);

                if (preparedStatement != null) {
                    preparedStatement.clearParameters();
                    preparedStatement.close();
                }
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));

                if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {
                    setVal(conn, generateSqlTran, preparedStatement);
                }
                if (generateSqlTran.getListBatch().size() > 0) {
                    preparedStatement.addBatch();
                    for (int j = 0; j < generateSqlTran.getListBatch().size(); j++) {
                        GenerateSqlTran batchSqlTran = generateSqlTran.getListBatch().get(j);
                        if (batchSqlTran.getListParameter() != null && batchSqlTran.getListParameter().size() > 0) {
                            setVal(conn, batchSqlTran, preparedStatement);
                        }
                        preparedStatement.addBatch();
                    }
                    int[] num = preparedStatement.executeBatch();


                    preparedStatement.clearBatch();
                    int resnum = dbBatchRes.batchRes(dbName, num);
                    log.info("第" + (i + 1) + "行批量SQL执行成功,影响行数" + resnum + "！");
                    res += resnum;
                    if (resnum == 0) {
                        excute = false;
                    }
                } else {
                    int resnum = preparedStatement.executeUpdate();
                    res += resnum;
                    log.info("第" + (i + 1) + "行批量SQL执行成功,影响行数" + resnum + "！");

                }


            }
            if (excute) {
                conn.commit();
            } else {
                res = 0;
                conn.rollback();
            }

        } catch (SQLException e) {
            log.error("执行异常：" + e);
            conn.rollback();
            res = 0;
            e.printStackTrace();
            close(conn, preparedStatement);
            if (res == 0) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement);
        }
        sqlTranList.clear();
        return res;
    }

    @Override
    public void callProcedures(@Nullable String dbName, ProceduresParameter proceduresParameter) throws Exception {

        Connection conn = conn(dbName);
        CallableStatement callableStatement = null;
        try {
            String proceduresName = proceduresParameter.getProcedures();
            if (proceduresParameter.getListParameter().size() == 0) {
                proceduresName += "()";
            } else {
                proceduresName += "(";
                for (int i = 0; i < proceduresParameter.getListParameter().size(); i++) {
                    proceduresName += "?,";
                }
                proceduresName = proceduresName.substring(0, proceduresName.length() - 1);
                proceduresName += ")";
            }
            callableStatement = conn.prepareCall("{call " + proceduresName + "}");
            if (proceduresParameter.getListParameter().size() > 0) {
                setCallableVal(conn, proceduresParameter.getListParameter(), callableStatement);
            }
            callableStatement.execute();
            if (proceduresParameter.getListParameter().size() > 0) {
                retCallableVal(conn, proceduresParameter.getListParameter(), callableStatement);
            }
        } catch (SQLException e) {
            log.error("执行异常：" + e);
            conn.rollback();
            e.printStackTrace();
            close(conn, callableStatement);
        } finally {
            close(conn, callableStatement);
        }


    }

    public int executekeep(@Nullable String dbName, Connection conn, PreparedStatement preparedStatement, List<GenerateSqlTran> sqlTranList) throws Exception {
        if (!checkListGenerate(dbName, sqlTranList)) {
            throw new Exception("处理对象中存在异常对象");

        }
        int res = 0;
        try {
            boolean excute = true;
            for (int i = 0; i < sqlTranList.size(); i++) {

                if (!excute) {
                    break;
                }
                GenerateSqlTran generateSqlTran = sqlTranList.get(i);

                if (preparedStatement != null) {
                    preparedStatement.clearParameters();
                    preparedStatement.close();
                }
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));

                if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {
                    setVal(conn, generateSqlTran, preparedStatement);
                }
                if (generateSqlTran.getListBatch().size() > 0) {
                    preparedStatement.addBatch();
                    for (int j = 0; j < generateSqlTran.getListBatch().size(); j++) {
                        GenerateSqlTran batchSqlTran = generateSqlTran.getListBatch().get(j);
                        if (batchSqlTran.getListParameter() != null && batchSqlTran.getListParameter().size() > 0) {
                            setVal(conn, batchSqlTran, preparedStatement);
                        }
                        preparedStatement.addBatch();
                    }
                    int[] num = preparedStatement.executeBatch();


                    preparedStatement.clearBatch();
                    int resnum = dbBatchRes.batchRes(dbName, num);
                    log.info("第" + (i + 1) + "行批量SQL执行成功,影响行数" + resnum + "！");
                    res += resnum;
                    if (resnum == 0) {
                        excute = false;
                    }
                } else {
                    int resnum = preparedStatement.executeUpdate();
                    res += resnum;
                    log.info("第" + (i + 1) + "行批量SQL执行成功,影响行数" + resnum + "！");

                }
            }

        } catch (SQLException e) {
            log.error("执行异常：" + e);
            res = 0;
            e.printStackTrace();

        }
        return res;
    }

    public JSONArray querykeep(@Nullable String dbName, Connection conn, PreparedStatement preparedStatement, ResultSet rs, List<GenerateSqlTran> sqlTranList) throws Exception {
        if (!checkListGenerate(dbName, sqlTranList)) {
            throw new Exception("处理对象中存在异常对象");
        }
        JSONArray data = new JSONArray();

        try {
            for (int i = 0; i < sqlTranList.size(); i++) {
                GenerateSqlTran generateSqlTran = sqlTranList.get(i);
                if (preparedStatement != null) {
                    preparedStatement.clearParameters();
                    preparedStatement.close();
                }
                preparedStatement = conn.prepareStatement(dbConvertSql.convertStrSql(dbName, generateSqlTran.get_strsql()));

                if (generateSqlTran.getListParameter() != null && generateSqlTran.getListParameter().size() > 0) {

                    setVal(conn, generateSqlTran, preparedStatement);
                }

                rs = preparedStatement.executeQuery();
                log.info("SQL执行成功！");

                if (generateSqlTran.getEncryList().size() > 0) {

                    data.add(EncryData.encryJson(resultToJSONArray(rs), generateSqlTran));
                } else {
                    data.add(resultToJSONArray(rs));
                }
            }

            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {


        }
        return data;
    }

    @Override
    public Boolean keepSqlTran(DbKeepTran dbKeepTran) throws Exception {
        Boolean res = true;


        try {
            Boolean rowRes = true;
            for (int i = 0; i < dbKeepTran.getDbKeep().size(); i++) {

                DbKeep dbKeep = dbKeepTran.getDbKeep().get(i);
                if (!dbKeep.getExecute()) {

                    List<GenerateSqlTran> tranList = dbKeep.getSqlTranList();

                    if (dbKeep.getKeepSqlTranType() == KeepSqlTranType.execute) {

                        int count = executekeep(dbKeepTran.getDbName(), dbKeepTran.getConn(), dbKeepTran.getPreparedStatement(), tranList);
                        dbKeep.setResData(count);
                        if (count > 0) {
                            dbKeep.setRes(true);
                        } else {
                            dbKeep.setRes(false);
                            rowRes = false;
                            break;
                        }
                    } else {
                        JSONArray data = querykeep(dbKeepTran.getDbName(), dbKeepTran.getConn(), dbKeepTran.getPreparedStatement(), dbKeepTran.getRs(), tranList);
                        dbKeep.setResData(data);
                        if (data != null) {
                            dbKeep.setRes(true);
                        } else {
                            dbKeep.setRes(false);
                            rowRes = false;
                            break;
                        }
                    }

                }
                dbKeep.setExecute(true);
                rowRes = true;
            }
            if (!rowRes) {
                res = false;
            }

        } catch (SQLException e) {
            log.error("执行异常：" + e);
            dbKeepTran.getConn().rollback();
            res = false;
            e.printStackTrace();
            close(dbKeepTran.getConn(), dbKeepTran.getPreparedStatement(), dbKeepTran.getRs());
            if (!res) {
                throw e;
            }
        } finally {
            close(dbKeepTran.getConn(), dbKeepTran.getPreparedStatement(), dbKeepTran.getRs());
        }

        return res;
    }

    @Override
    public Boolean keepExecute(DbKeepTran dbKeepTran, Boolean execute) throws Exception {
        Boolean res = true;
        try {
            if (execute) {
                dbKeepTran.getConn().commit();
            } else {
                dbKeepTran.getConn().rollback();
            }
        } catch (SQLException e) {
            log.error("执行异常：" + e);
            dbKeepTran.getConn().rollback();
            res = false;
            e.printStackTrace();
            close(dbKeepTran.getConn(), dbKeepTran.getPreparedStatement(), dbKeepTran.getRs());
            if (!res) {
                throw e;
            }
        } finally {
            close(dbKeepTran.getConn(), dbKeepTran.getPreparedStatement(), dbKeepTran.getRs());
        }

        return res;
    }

    private void setVal(Connection conn, GenerateSqlTran generateSqlTran, PreparedStatement preparedStatement) throws Exception {

        log.info("参数化：");
        for (int j = 0; j < generateSqlTran.getListParameter().size(); j++) {

            DbParameter dbParameter = generateSqlTran.getListParameter().get(j);
            log.info("参数名：" + dbParameter.getParameterName() + "参数类型：" + dbParameter.getParamenterType().getParamenterTypeName() + "值：" + dbParameter.getParameterVal());

            if (dbParameter.getParameterVal() == null) {
                preparedStatement.setNull(j + 1, dbParameter.getParamenterType().getParamenterType());
                continue;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.VARCHAR)) {

                preparedStatement.setString(j + 1, SQLSanitizer.preparedStatementsanitize(dbParameter.getParameterVal().toString()));
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.CHAR)) {

                preparedStatement.setString(j + 1, dbParameter.getParameterVal().toString().trim());
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.DOUBLE)) {

                preparedStatement.setBigDecimal(j + 1, new BigDecimal(dbParameter.getParameterVal().toString()));
                continue;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.DATE)) {
                preparedStatement.setTimestamp(j + 1, new Timestamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dbParameter.getParameterVal().toString()).getTime()));
//                preparedStatement.setDate(j + 1,  new java.sql.Date(((java.util.Date)dbParameter.getParameterVal()).getTime()));
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.CLOB)) {
//                CLOB clob = CLOB.createTemporary(conn, false, CLOB.DURATION_SESSION);
//                String longStr = String.join(", ", Collections.nCopies(5000, dbParameter.getParameterVal().toString
//                ()));
//                clob.setString(1, dbParameter.getParameterVal().toString());
//                ((OraclePreparedStatement)preparedStatement).setStringForClob(2, longStr);
                preparedStatement.setString(j + 1, dbParameter.getParameterVal().toString());
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.BLOB)) {


                byte[] byteArray = (byte[]) dbParameter.getParameterVal();
                preparedStatement.setBlob(j + 1, new ByteArrayInputStream(byteArray));
//                preparedStatement.setBlob(j + 1, blob);
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.BYTEA)) {

                byte[] byteArray = (byte[]) dbParameter.getParameterVal();
                preparedStatement.setBytes(j + 1, byteArray);
//                preparedStatement.setBlob(j + 1, blob);
                continue;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.BOOL)) {

                preparedStatement.setBoolean(j + 1, dbParameter.getParameterVal().toString().equals("1") || dbParameter.getParameterVal().toString().equals("true"));
                continue;
            }
        }
    }

    private void setCallableVal(Connection conn, List<DbParameter> dbParameters, CallableStatement callableStatement) throws Exception {

        log.info("参数化：");
        for (int j = 0; j < dbParameters.size(); j++) {

            DbParameter dbParameter = dbParameters.get(j);
            log.info("参数名：" + dbParameter.getParameterName() + "参数类型：" + dbParameter.getParamenterType().getParamenterTypeName() + "值：" + dbParameter.getParameterVal());
            boolean isNull = false;
            if (dbParameter.getParameterVal() == null) {
                callableStatement.setNull(j + 1, dbParameter.getParamenterType().getParamenterType());
                isNull = true;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.VARCHAR)) {

                if (!isNull) {
                    callableStatement.setString(j + 1, SQLSanitizer.preparedStatementsanitize(dbParameter.getParameterVal().toString()));
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.VARCHAR);
                }
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.CHAR)) {
                if (!isNull) {
                    callableStatement.setString(j + 1, dbParameter.getParameterVal().toString().trim());
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.CHAR);
                }
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.DOUBLE)) {
                if (!isNull) {
                    callableStatement.setBigDecimal(j + 1, new BigDecimal(dbParameter.getParameterVal().toString()));
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.DOUBLE);
                }
                continue;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.DATE)) {
                if (!isNull) {
                    callableStatement.setTimestamp(j + 1, new Timestamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dbParameter.getParameterVal().toString()).getTime()));
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.DATE);
                }
//                preparedStatement.setDate(j + 1,  new java.sql.Date(((java.util.Date)dbParameter.getParameterVal()).getTime()));
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.CLOB)) {
//                CLOB clob = CLOB.createTemporary(conn, false, CLOB.DURATION_SESSION);
//                String longStr = String.join(", ", Collections.nCopies(5000, dbParameter.getParameterVal().toString
//                ()));
//                clob.setString(1, dbParameter.getParameterVal().toString());
//                ((OraclePreparedStatement)preparedStatement).setStringForClob(2, longStr);
                if (!isNull) {
                    callableStatement.setString(j + 1, dbParameter.getParameterVal().toString());
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.CLOB);
                }
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.BLOB)) {

                if (!isNull) {
                    byte[] byteArray = (byte[]) dbParameter.getParameterVal();
                    callableStatement.setBlob(j + 1, new ByteArrayInputStream(byteArray));
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.BLOB);
                }
//                preparedStatement.setBlob(j + 1, blob);
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.BYTEA)) {
                if (!isNull) {
                    byte[] byteArray = (byte[]) dbParameter.getParameterVal();
                    callableStatement.setBytes(j + 1, byteArray);
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.BIT);
                }
//                preparedStatement.setBlob(j + 1, blob);
                continue;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.BOOL)) {
                if (!isNull) {
                    callableStatement.setBoolean(j + 1, dbParameter.getParameterVal().toString().equals("1") || dbParameter.getParameterVal().toString().equals("true"));
                }
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    callableStatement.registerOutParameter(j + 1, Types.BOOLEAN);
                }
                continue;
            }
        }
    }

    private void retCallableVal(Connection conn, List<DbParameter> dbParameters, CallableStatement callableStatement) throws Exception {

        log.info("参数化：");
        for (int j = 0; j < dbParameters.size(); j++) {

            DbParameter dbParameter = dbParameters.get(j);

            if (dbParameter.getParamenterType().equals(ParamenterType.VARCHAR)) {

                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getString(j + 1));
                }
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.CHAR)) {
                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getString(j + 1));
                }
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.DOUBLE)) {

                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getDouble(j + 1));
                }
                continue;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.DATE)) {

                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getDate(j + 1));
                }
//                preparedStatement.setDate(j + 1,  new java.sql.Date(((java.util.Date)dbParameter.getParameterVal()).getTime()));
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.CLOB)) {
//                CLOB clob = CLOB.createTemporary(conn, false, CLOB.DURATION_SESSION);
//                String longStr = String.join(", ", Collections.nCopies(5000, dbParameter.getParameterVal().toString
//                ()));
//                clob.setString(1, dbParameter.getParameterVal().toString());
//                ((OraclePreparedStatement)preparedStatement).setStringForClob(2, longStr);

                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getClob(j + 1));
                }
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.BLOB)) {

                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getBlob(j + 1));
                }
//                preparedStatement.setBlob(j + 1, blob);
                continue;
            }
            if (dbParameter.getParamenterType().equals(ParamenterType.BYTEA)) {

                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getByte(j + 1));
                }
//                preparedStatement.setBlob(j + 1, blob);
                continue;
            }

            if (dbParameter.getParamenterType().equals(ParamenterType.BOOL)) {

                if (dbParameter.getParameRegisterType() == ParameRegisterType.out || dbParameter.getParameRegisterType() == ParameRegisterType.in_and_out) {
                    dbParameter.setRetParameterVal(callableStatement.getBoolean(j + 1));
                }
                continue;
            }
        }
    }


    private JSONArray resultToJSONArray(ResultSet rs) throws Exception {
        JSONArray list = new JSONArray();
        while (rs.next()) {

            ResultSetMetaData md = rs.getMetaData();

            JSONObject row = new JSONObject();

            for (int i = 0; i < md.getColumnCount(); i++) {
                if (rs.getObject(i + 1) != null) {
                    row.put(md.getColumnLabel(i + 1).toUpperCase(Locale.ROOT), specialColumnVal(md.getColumnTypeName(i + 1), rs.getObject(i + 1)));
                } else {
                    row.put(md.getColumnLabel(i + 1).toUpperCase(Locale.ROOT), "");
                }
            }
            list.add(row);
        }
        return list;
    }


    private List<Map<String, Object>> resultToMap(ResultSet rs) throws Exception {
        List<Map<String, Object>> list = new ArrayList<>();
        while (rs.next()) {

            ResultSetMetaData md = rs.getMetaData();

            Map<String, Object> map = new HashMap<>();

            for (int i = 0; i < md.getColumnCount(); i++) {
                if (rs.getObject(i + 1) != null) {
                    map.put(md.getColumnLabel(i + 1).toUpperCase(Locale.ROOT), specialColumnVal(md.getColumnTypeName(i + 1), rs.getObject(i + 1)));
                } else {
                    map.put(md.getColumnLabel(i + 1).toUpperCase(Locale.ROOT), "");
                }

            }
            list.add(map);
        }
        return list;
    }

    private DataTable resultToDataTable(ResultSet rs) throws Exception {
        DataTable list = new DataTable();
        while (rs.next()) {

            DataColumnCollection columns = list.getColumns();
            if (columns.size() == 0) {
                ResultSetMetaData md = rs.getMetaData();
                for (int i = 1; i <= md.getColumnCount(); i++) {


                    columns.add(md.getColumnLabel(i).toUpperCase(Locale.ROOT), md.getColumnType(i), md.getColumnTypeName(i));

//                    map.put(md.getColumnLabel(i), rs.getObject(i));
                }
            }

            DataRow dataRow = list.getRows().newRow();
            for (int i = 0; i < columns.size(); i++) {
                DataColumn dataColumn = columns.getColumn(i);
                if (rs.getObject(i + 1) != null) {
                    dataRow.setVal(dataColumn, specialColumnVal(dataColumn.getColumnTypeName(), rs.getObject(i + 1)));
                } else {
                    dataRow.setVal(dataColumn, "");
                }

            }
        }
        return list;
    }

    public Connection conn(@Nullable String dbName) throws Exception {

        Connection conn = null;
        if (dbName != null) {

            if (tenant.getSingle()) {
                conn = dataSource.getResolvedDataSources().get(dbName).getConnection();
                conn.setAutoCommit(false);
            } else {
                String tenantId = interceptTenant.getTenantHeader();
                conn = dataSource.getResolvedDataSources().get(dbName + "-" + tenantId).getConnection();
                conn.setAutoCommit(false);

            }

        } else {
            conn = dataSource.getResolvedDefaultDataSource().getConnection();
            conn.setAutoCommit(false);
        }
        return conn;
    }

    public DataSource getDataSource(@Nullable String dbName) throws Exception {

        DataSource data = null;
        String tenantId = interceptTenant.getTenantHeader();
        data = dataSource.getResolvedDataSources().get(dbName);
        return data;
    }

    /**
     * 释放资源
     *
     * @param rs 结果集
     */
    public void close(Connection conn, PreparedStatement preparedStatement, ResultSet rs) {
        dataSoureClose(conn, preparedStatement, rs, null);
    }

    public void close(Connection conn, PreparedStatement preparedStatement) {
        dataSoureClose(conn, preparedStatement, null, null);
    }

    public void close(Connection conn, CallableStatement preparedStatement) {
        dataSoureClose(conn, preparedStatement, null, preparedStatement);
    }


    public boolean checkListGenerate(String dbName, List<GenerateSqlTran> sqlTranList) {

        boolean res = true;

        for (int i = 0; i < sqlTranList.size(); i++) {
            res = checkGenerate(dbName, sqlTranList.get(i));
            if (!res) {
                res = false;
                break;
            }
        }

        return res;
    }

    public boolean checkGenerate(String dbName, GenerateSqlTran generateSqlTran) {

        boolean res = true;
        if (generateSqlTran.getErrList().size() > 0) {
            res = false;
        }

        if (generateSqlTran.getListBatch().size() > 0) {

            for (int i = 0; i < generateSqlTran.getListBatch().size(); i++) {
                GenerateSqlTran batchTran = generateSqlTran.getListBatch().get(i);
                if (generateSqlTran.getErrList().size() > 0) {
                    res = false;
                    break;
                }
            }
        }
        return res;
    }

    public Object specialColumnVal(String columnTypeName, Object val) throws SQLException {
        if (columnTypeName.equals("NCLOB")) {
            return convertNCLOBtoString((NClob) val);
        }
        if (columnTypeName.equals("CLOB")) {
            return convertCLOBtoString((Clob) val);
        }
        return val;
    }

    public String convertNCLOBtoString(NClob clob) throws SQLException {
        try {
            if (clob == null) {
                return null;
            }
            StringBuilder sb = new StringBuilder();
            try (Reader reader = clob.getCharacterStream()) {
                char[] buffer = new char[4096];
                int charsRead;
                while ((charsRead = reader.read(buffer)) != -1) {
                    sb.append(buffer, 0, charsRead);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return sb.toString();
        } catch (Exception exception) {
            exception.printStackTrace();
            System.out.print(exception.toString());
            return null;
        }
    }

    public String convertCLOBtoString(Clob clob) throws SQLException {
        try {
            if (clob == null) {
                return null;
            }
            StringBuilder sb = new StringBuilder();
            try (Reader reader = clob.getCharacterStream()) {
                char[] buffer = new char[4096];
                int charsRead;
                while ((charsRead = reader.read(buffer)) != -1) {
                    sb.append(buffer, 0, charsRead);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return sb.toString();
        } catch (Exception exception) {
            exception.printStackTrace();
            System.out.print(exception.toString());
            return null;
        }
    }


    public void dataSoureClose(Connection conn, Statement statement, ResultSet rs, CallableStatement callableStatement) {
        if (rs != null) {
            resultSetClose(rs);
        }
        if (statement != null) {
            statementClose(statement);
        }
        if (callableStatement != null) {
            callableStatementClose(callableStatement);
        }
        if (conn != null) {
            connClose(conn);
        }
    }

    private static void callableStatementClose(CallableStatement callableStatement) {
        try {
            callableStatement.close();
        } catch (SQLException e) {
            log.error("callableStatement关闭连接异常：" + e);
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.print(e.toString());
        }
    }

    /**
     * 释放连接
     *
     * @param conn
     */
    private void connClose(Connection conn) {
        try {
            conn.close();
        } catch (SQLException e) {
            log.error("connClose关闭连接异常：" + e);
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.print(e.toString());
        }
    }

    private static void statementClose(Statement statement) {
        try {
            statement.close();
        } catch (SQLException e) {
            log.error("statementClose关闭连接异常：" + e);
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.print(e.toString());
        }
    }

    private static void resultSetClose(ResultSet rs) {
        try {
            rs.close();
        } catch (SQLException e) {
            log.error("resultSetClose关闭连接异常：" + e);
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.print(e.toString());
        }
    }

    private void setCacheObject(String cacheKey, Object data) {
        try {
            log.info("设置缓存");
            if (tenant.getSingle()) {
                redisService.setCacheObject(cacheKey, data);
            } else {
                redisService.setCacheObject(interceptTenant.getTenantHeader() + ":" + cacheKey, data);
            }

        } catch (Exception ex) {
            log.error("缓存设置异常" + ex);
        }
    }
}
