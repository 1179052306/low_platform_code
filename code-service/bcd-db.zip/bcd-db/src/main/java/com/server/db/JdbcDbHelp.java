package com.server.db;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.params.JdbcConnectModel;
import com.server.params.JdbcSqlModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.List;
import java.util.Locale;

/**
 * @author lw
 * @date: 2025/2/21
 * @description:
 **/
@Slf4j
@Service
public class JdbcDbHelp {

    public boolean connect(JdbcConnectModel jdbcConnectModel) throws Exception {

        boolean res = false;
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(jdbcConnectModel.getJdbc_url(), jdbcConnectModel.getUser(), jdbcConnectModel.getPwd());
            res = true;
        } catch (SQLException e) {
            log.error("执行异常：" + e);
            close(conn, null, null);

        } finally {
            close(conn, null, null);
        }

        return res;
    }

    public int executeSql(JdbcConnectModel jdbcConnectModel, List<String> listSql) throws Exception {
        Connection conn = DriverManager.getConnection(jdbcConnectModel.getJdbc_url(), jdbcConnectModel.getUser(), jdbcConnectModel.getPwd());
        PreparedStatement preparedStatement = null;
        int res = 0;
        try {
            conn.setAutoCommit(false);
            for (int i = 0; i < listSql.size(); i++) {

                preparedStatement = conn.prepareStatement(listSql.get(i));
                res += preparedStatement.executeUpdate();
                log.info("第" + (i + 1) + "行SQL执行成功！");
                preparedStatement.close();
            }

            conn.commit();
        } catch (SQLException e) {
            log.error("执行异常：" + e);
            res = 0;
            conn.rollback();
            e.printStackTrace();
            close(conn, preparedStatement, null);
            if (res == 0) {
                throw e;
            }
        } finally {
            close(conn, preparedStatement, null);
        }
        listSql.clear();
        return res;
    }

    public JSONArray queryJson(JdbcConnectModel jdbcConnectModel, String sql) throws Exception {
        JSONArray data = new JSONArray();
        ResultSet rs = null;
        Connection conn = DriverManager.getConnection(jdbcConnectModel.getJdbc_url(), jdbcConnectModel.getUser(), jdbcConnectModel.getPwd());
        Statement statement = null;
        try {


            statement = conn.createStatement();
            rs = statement.executeQuery(sql);
            log.info("SQL执行成功！");
            data = resultToJSONArray(rs);
            statement.close();
            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, statement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, statement, rs);
        }
        return data;
    }

    public JSONArray queryJson(JdbcConnectModel jdbcConnectModel, List<String> listSql) throws Exception {
        JSONArray data = new JSONArray();
        ResultSet rs = null;
        Connection conn = DriverManager.getConnection(jdbcConnectModel.getJdbc_url(), jdbcConnectModel.getUser(), jdbcConnectModel.getPwd());
        Statement statement = null;
        try {


            for (int i = 0; i < listSql.size(); i++) {
                statement = conn.createStatement();
                rs = statement.executeQuery(listSql.get(i));
                log.info("SQL执行成功！");
                data.add(resultToJSONArray(rs));
                statement.close();

            }
            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, statement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, statement, rs);
        }
        return data;
    }

    public JSONObject queryJsonObject(JdbcConnectModel jdbcConnectModel, List<JdbcSqlModel> listSql) throws Exception {
        JSONObject data = new JSONObject();
        ResultSet rs = null;
        Connection conn = DriverManager.getConnection(jdbcConnectModel.getJdbc_url(), jdbcConnectModel.getUser(), jdbcConnectModel.getPwd());
        Statement statement = null;
        try {


            for (int i = 0; i < listSql.size(); i++) {
                statement = conn.createStatement();
                rs = statement.executeQuery(listSql.get(i).getSql());
                log.info("SQL执行成功！");
                data.put(listSql.get(i).getAlias(), resultToJSONArray(rs));
                statement.close();

            }
            return data;
        } catch (Exception e) {
            log.error("执行异常：" + e);
            e.printStackTrace();
            close(conn, statement, rs);
            data = null;
            if (data == null) {
                throw e;
            }
        } finally {
            close(conn, statement, rs);
        }
        return data;
    }

    private JSONArray resultToJSONArray(ResultSet rs) throws Exception {
        JSONArray list = new JSONArray();
        while (rs.next()) {

            ResultSetMetaData md = rs.getMetaData();

            JSONObject row = new JSONObject();

            for (int i = 0; i < md.getColumnCount(); i++) {
                if (rs.getObject(i + 1) != null) {
                    row.put(md.getColumnLabel(i + 1).toUpperCase(Locale.ROOT), rs.getObject(i + 1));
                } else {
                    row.put(md.getColumnLabel(i + 1).toUpperCase(Locale.ROOT), "");
                }
            }
            list.add(row);
        }
        return list;
    }

    public void close(Connection conn, Statement preparedStatement, ResultSet rs) {
        dataSoureClose(conn, preparedStatement, rs);
    }

    public void dataSoureClose(Connection conn, Statement statement, ResultSet rs) {
        if (rs != null) {
            resultSetClose(rs);
        }
        if (statement != null) {
            statementClose(statement);
        }
        if (conn != null) {
            connClose(conn);
        }
    }

    /**
     * 释放连接
     *
     * @param conn
     */
    private void connClose(Connection conn) {
        try {
            conn.close();
        } catch (SQLException e) {
            log.error("connClose关闭连接异常：" + e);
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.print(e.toString());
        }
    }

    private static void statementClose(Statement statement) {
        try {
            statement.close();
        } catch (SQLException e) {
            log.error("statementClose关闭连接异常：" + e);
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.print(e.toString());
        }
    }

    private static void resultSetClose(ResultSet rs) {
        try {
            rs.close();
        } catch (SQLException e) {
            log.error("resultSetClose关闭连接异常：" + e);
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.print(e.toString());
        }
    }

}
