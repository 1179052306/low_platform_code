package com.server.params;

/**
 * @Description 数据库参数类型
 * @Author liwei
 * @Date 2023/7/26 10:22
 **/
public enum ParamenterType{

    VARCHAR("VARCHAR",12),
    CHAR("CHAR",12),
    DOUBLE("DOUBLE",8),
    DATE("DATE",91),
    CLOB("CLOB",2005),
    BLOB("BLOB",2006),
    BOOL("BLOB",2006),
    BYTEA("BLOB",2006),
    NULL("NULL",0);

    ParamenterType (String paramenterTypeName,int paramenterType){

        this.paramenterType=paramenterType;

        this.paramenterTypeName=paramenterTypeName;
    }
    private  int paramenterType;////参数类型

    private  String paramenterTypeName;/////参数类型名称

    public int getParamenterType() {
        return paramenterType;
    }

    public String getParamenterTypeName() {
        return paramenterTypeName;
    }


    public void setParamenterType(int paramenterType) {
        this.paramenterType = paramenterType;
    }

    public void setParamenterTypeName(String paramenterTypeName) {
        this.paramenterTypeName = paramenterTypeName;
    }



}
