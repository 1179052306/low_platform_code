package com.server.params;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description 指定位置参数替换匹配
 * @Author liwei
 * @Date 2023/7/26 10:17     
 **/
public class DbParmentReplace{


    /**
     * 获取匹配的变量
     *
     * @param paramenterTypeName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public static String getString(String paramenterTypeName){

        return  "@{"+paramenterTypeName+"}@";
    }

    /**
     * 获取添加别名的变量匹配
     *
     * @param TableAlias
     * @param paramenterTypeName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public static String getString(String TableAlias, String paramenterTypeName){

        return  "@{"+TableAlias+"."+paramenterTypeName+"}@";
    }
    /**
     * 动态替换源占位符的内容
     *
     * @param StrSql
     * @return List
     * @author liwei
     * @date: 2023/7/26
     **/
    public static List<Rpc> getParamenters(StringBuilder StrSql){

        List<Rpc>paramenters=new ArrayList<Rpc>();

        String[] SqlStrings= StrSql.toString().split("@\\{");

        if(SqlStrings.length>1){

            for (int i = 0; i < SqlStrings.length; i++) {

               String[] SqlStr= SqlStrings[i].split("\\}@");

               if(SqlStr.length>1){

                   String[] alias=SqlStr[0].split("\\.");

                   if(alias.length>1){
                       paramenters.add(new Rpc(alias[0],alias[1]));
                   }else {
                       paramenters.add(new Rpc("",SqlStr[0]));
                   }

               }


            }
            
        }

        return  paramenters;
    }
}
