package com.server.syntax.xmlmanage;

import com.server.dataset.DataRow;
import com.server.dataset.DataTable;
import com.server.db.DbHelpImpl;
import com.server.generate.GenerateSqlImpl;
import com.server.params.DbParameter;
import com.server.params.GenerateSqlTran;
import com.server.params.ParamenterType;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @Description PgXml获取接口
 * @Author liwei
 * @Date 2023/7/26 10:46
 **/
@Service
public class PgXmlMange implements DbTableXmlServer {

    @Autowired
    private DbHelpImpl dbHelp;

    @Autowired
    private GenerateSqlImpl generateSql;
    /**
     * 保存xml
     *
     * @param path
     * @param table
     * @param dbName
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public boolean saveXml(String path, String table, @Nullable String dbName) {
        boolean res = false;
        Document doc = DocumentHelper.createDocument();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT * FROM ( select t.tablename AS TABLE_NAME,a.attname AS COLUMN_NAME,case when p.typname ='numeric' then 'NUMBER' when p.typname ='timestamptz'then 'DATE' ELSE  p.typname END as DATA_TYPE,case when a.attlen > 0 then a.attlen when p.typname='bit' then a.atttypmod else a.atttypmod - 4 end as DATA_LENGTH , 0 AS IS_COLUMN  from pg_tables t left join pg_class c on t.tablename=c.relname left join pg_attribute a on c.OID=a.attrelid left join pg_type p on A.atttypid = p.OID where 1=1  and A.attnum > 0  and  t.tablename ='" + table.toLowerCase(Locale.ROOT) + "'");
        stringBuilder.append(" UNION ALL ");
        stringBuilder.append("SELECT  lower(T.TABLE_NAME)  TABLE_NAME, lower(T.COLUMN_NAME) as COLUMN_NAME, T.COLUMN_TYPE DATA_TYPE, T.COLUMN_SIZE DATA_LENGTH,1 IS_COLUMN  FROM s_xml_manage T ) AS T WHERE 1 = 1  AND lower(T.TABLE_NAME)='" + table.toLowerCase(Locale.ROOT) + "'");
        DataTable dataTable = null;
        try {
            dataTable = dbHelp.query(dbName, stringBuilder.toString());

        } catch (Exception ex) {


        }

        if (dataTable != null) {
            if (dataTable.getRows().size() == 0) {
                return false;
            }
            Element root = doc.addElement("Column");
            for (int i = 0; i < dataTable.getRows().size(); i++) {

                DataRow row = dataTable.getRows().getRow(i);
                Element node = root.addElement("ColumnAttribute");
                node.addAttribute("ID", row.getVal("COLUMN_NAME").toString().toUpperCase(Locale.ROOT));

                Element OracleType = node.addElement("OracleType");
                OracleType.addText(row.getVal("DATA_TYPE").toString().toUpperCase(Locale.ROOT));

                Element OracleSize = node.addElement("OracleSize");
                if (row.getVal("DATA_TYPE").toString().toUpperCase(Locale.ROOT).contains("VARCHAR")) {
                    OracleSize.addText(row.getVal("DATA_LENGTH").toString());

                }
                Element IsColumn = node.addElement("IS_COLUMN");
                IsColumn.addText(row.getVal("IS_COLUMN").toString());
            }
            try {

                XMLWriter writer = new XMLWriter(OutputFormat.createPrettyPrint());
                FileOutputStream fos = new FileOutputStream(path);
                writer.setOutputStream(fos);
                writer.write(doc);
                System.out.println("写出完毕!");
                writer.close();
                res = true;
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return res;
    }

    /**
     * 检查字段xml
     *
     * @param table
     * @param columnName
     * @param dbName
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public boolean checkColumnXml(String table, String columnName, @Nullable String dbName) {
        boolean res = false;

        Document doc = DocumentHelper.createDocument();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT * FROM ( select t.tablename AS TABLE_NAME,a.attname AS COLUMN_NAME,case when p.typname ='numeric' then 'NUMBER' when p.typname ='timestamptz'then 'DATE' ELSE  p.typname END as DATA_TYPE,case when a.attlen > 0 then a.attlen when p.typname='bit' then a.atttypmod else a.atttypmod - 4 end as DATA_LENGTH , 0 AS IS_COLUMN  from pg_tables t left join pg_class c on t.tablename=c.relname left join pg_attribute a on c.OID=a.attrelid left join pg_type p on A.atttypid = p.OID where 1=1  and A.attnum > 0  and  t.tablename ='" + table.toLowerCase(Locale.ROOT) + "'");
        stringBuilder.append(" UNION ALL ");

        stringBuilder.append("SELECT lower(T.TABLE_NAME) TABLE_NAME, lower(T.COLUMN_NAME) as COLUMN_NAME, T.COLUMN_TYPE DATA_TYPE," +
                " T.COLUMN_SIZE DATA_LENGTH,1 IS_COLUMN  FROM S_XML_MANAGE T  WHERE 1=1   AND  lower(T.TABLE_NAME)='" + table.toLowerCase(Locale.ROOT) + "')T WHERE 1 = 1 AND T.COLUMN_NAME=?");
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.set_strsql(stringBuilder.toString());
        generateSqlTran.setDbName(dbName);
        generateSqlTran.setTableName(table);
        List<DbParameter> listParameter = new ArrayList<>();
        DbParameter dbParameter = new DbParameter();
        dbParameter.setParameterName("COLUMN_NAME");
        dbParameter.setParamenterType(ParamenterType.VARCHAR);
        dbParameter.setParameterVal(columnName.toLowerCase(Locale.ROOT));
        listParameter.add(dbParameter);
        generateSqlTran.setListParameter(listParameter);

        DataTable dataTable = null;
        try {
            dataTable = dbHelp.query(dbName, generateSqlTran);

        } catch (Exception ex) {

        }

        if (dataTable != null) {

            if (dataTable.getRows().size() == 0) {
                return false;
            }
            res = true;
        }
        return res;
    }

    /**
     * 获取全部表数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public StringBuilder getDataSql(@Nullable String dbName) {
        StringBuilder strSql = new StringBuilder();
        strSql.append("SELECT TABLE_NAME FROM (SELECT TABLE_NAME ||'' AS TABLE_NAME FROM (select tablename as TABLE_NAME from pg_tables t where 1=1  ");
        strSql.append(" UNION ALL ");
        strSql.append("SELECT lower(T.TABLE_NAME) TABLE_NAME FROM S_XML_MANAGE T  WHERE 1=1   )T WHERE 1 = 1 GROUP BY TABLE_NAME )T WHERE 1=1 ");
        return strSql;
    }


    @Override
    public GenerateSqlTran getDataSql(@Nullable String dbName, String symbol, String filter) {
        StringBuilder strSql = new StringBuilder();
        strSql.append("SELECT TABLE_NAME FROM (SELECT TABLE_NAME ||'' AS TABLE_NAME FROM (select tablename as TABLE_NAME from pg_tables t where 1=1  ");
        strSql.append(" UNION ALL ");
        strSql.append("SELECT lower(T.TABLE_NAME) TABLE_NAME FROM S_XML_MANAGE T  WHERE 1=1   )T WHERE 1 = 1 GROUP BY TABLE_NAME )T WHERE 1=1 ");

        return  generateSql.sqlQuery(dbName, "S_XML_MANAGE", strSql, generateSql.add("TABLE_NAME", symbol, filter.toLowerCase(Locale.ROOT)));
    }

    /**
     * 获取全部表字段数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public StringBuilder getTableColumnSql(@Nullable String dbName) {
        StringBuilder strSql = new StringBuilder();
        strSql.append("SELECT * FROM ( select t.tablename AS TABLE_NAME,a.attname AS COLUMN_NAME,case when p.typname ='numeric' then 'NUMBER' when p.typname ='timestamptz'then 'DATE' ELSE  p.typname END as DATA_TYPE,case when a.attlen > 0 then a.attlen when p.typname='bit' then a.atttypmod else a.atttypmod - 4 end as DATA_LENGTH , col_description(a.attrelid,a.attnum) as comment from pg_tables t left join pg_class c on t.tablename=c.relname left join pg_attribute a on c.OID=a.attrelid left join pg_type p on A.atttypid = p.OID where 1=1  and A.attnum > 0 )t where 1=1 ");
        return strSql;
    }
    /**
     * 获取全部表字段数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran getTableColumnSql(@Nullable String dbName, String table) {
        StringBuilder strSql = new StringBuilder();
        strSql.append("SELECT * FROM ( select t.tablename AS TABLE_NAME,a.attname AS COLUMN_NAME,upper(case when p.typname ='numeric' then 'NUMBER' when p.typname ='timestamptz'then 'DATE' when p.typname ='timestamp'then 'DATETIME' ELSE  p.typname END) as DATA_TYPE,case when a.attlen > 0 then a.attlen when p.typname='bit' then a.atttypmod else a.atttypmod - 4 end as DATA_LENGTH , col_description(a.attrelid,a.attnum) as REMARKS from pg_tables t left join pg_class c on t.tablename=c.relname left join pg_attribute a on c.OID=a.attrelid left join pg_type p on A.atttypid = p.OID where 1=1  and A.attnum > 0 )t where 1=1 AND DATA_TYPE<>'' ");

        return  generateSql.sqlQuery(dbName, "S_XML_MANAGE", strSql, generateSql.add("TABLE_NAME",table.toLowerCase(Locale.ROOT)));
    }

}
