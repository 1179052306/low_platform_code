package com.server.params;

/**
 * @Description 参数自动获取数据库时间
 * @Author liwei
 * @Date 2023/7/26 10:33
 **/
public class Rtt{

    public Rtt(  String paramentName){
       
        this.paramentName=paramentName;


    }
    public Rtt(  String paramentName, String paramentVal){

        this.paramentName=paramentName;
        this.paramentVal=paramentVal;

    }

    private  String paramentVal="";/////数据时间值

    private  String paramentName="";/////字段名称

    public String getParamentVal() {
        return paramentVal;
    }

    public String getParamentName() {
        return paramentName;
    }

    public void setParamentVal(String paramentVal) {
        this.paramentVal = paramentVal;
    }

    public void setParamentName(String paramentName) {
        this.paramentName = paramentName;
    }




}
