package com.server.special_handle;

/**
 * @author lw
 * @date: 2025/2/26
 * @description:
 **/
@FunctionalInterface
public interface SpecialHandleInterface<T> {

    void execute(T... args) throws Exception;
}
