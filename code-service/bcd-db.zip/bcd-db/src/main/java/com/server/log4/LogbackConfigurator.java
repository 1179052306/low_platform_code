package com.server.log4;

import ch.qos.logback.classic.AsyncAppender;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.db.DBAppender;
import ch.qos.logback.classic.filter.ThresholdFilter;
import ch.qos.logback.core.db.ConnectionSource;
import ch.qos.logback.core.db.DriverManagerConnectionSource;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.DbHelp;
import com.server.db.Tenant;
import com.server.tenant_http.TenantHttp;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author lw
 * @date: 2025/3/11
 * @description:
 **/
@Service
@Slf4j
public class LogbackConfigurator {

    @Autowired
    Tenant tenant;

    @Autowired
    DbHelp dbHelp;

    public void configureDbAppender() throws Exception {
        LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
        // 创建 DBAppender 实例
        DBAppender dbAppender = new DBAppender();
        dbAppender.setContext(loggerContext);

        // 设置过滤器
        ThresholdFilter thresholdFilter = new ThresholdFilter();
        thresholdFilter.setLevel(Level.ERROR.levelStr);
        thresholdFilter.start();
        dbAppender.addFilter(thresholdFilter);
        HikariDataSource dataSource =null;
        if (tenant.getSingle()) {
            dataSource = (HikariDataSource) dbHelp.getDataSource("project_log");

        } else {
            dataSource= getLogDataBaseData();
        }

        if(dataSource==null){
            log.error("日志数据库未正确配置");
        }
        DriverManagerConnectionSource connectionSource = new DriverManagerConnectionSource();
        connectionSource.setDriverClass(dataSource.getDriverClassName());
        connectionSource.setUrl(dataSource.getJdbcUrl());
        connectionSource.setUser(dataSource.getUsername());
        connectionSource.setPassword(dataSource.getPassword());
        connectionSource.setContext(loggerContext);
        connectionSource.start();
        dbAppender.setConnectionSource(connectionSource);
        // 启动 Appender
        dbAppender.start();
        // 创建 AsyncAppender 实例
        AsyncAppender asyncAppender = new AsyncAppender();
        asyncAppender.setContext(loggerContext);
        asyncAppender.addAppender(dbAppender);
        asyncAppender.setIncludeCallerData(true); // 包含调用者数据
        asyncAppender.start();
        // 获取根 Logger 并添加 Appender
        Logger rootLogger = loggerContext.getLogger(Logger.ROOT_LOGGER_NAME);
        rootLogger.addAppender(asyncAppender);
    }

    private HikariDataSource getLogDataBaseData() {
        HikariDataSource hikariDataSource = null;
        log.info("准备获取平台日志数据库");
        log.info("请求地址：" + this.tenant.getTenanturl()+"/log/getDataSource");
        TenantHttp tenantHttp = new TenantHttp(this.tenant.getTenanturl()+"/log/getDataSource", true);
        try {
            tenantHttp.addParameter("SYSTEM_TYPE",tenant.getSystemType());
            log.info("发送请求");
            tenantHttp.post();
            log.info("请求结果：" + tenantHttp.getContent());
            JSONObject returnData = JSONObject.parseObject(tenantHttp.getContent());
            if (!returnData.getBoolean("res")) {
                log.error("返回结果失败：" + returnData.getString("data"));
                return hikariDataSource;
            }
            JSONArray data = JSONArray.parseArray(returnData.getString("data"));
            for (int i = 0; i < data.size(); i++) {
                JSONObject item = data.getJSONObject(i);
                hikariDataSource = new HikariDataSource();
                hikariDataSource.setJdbcUrl(item.getString("CONNECT_STRING"));
                hikariDataSource.setDriverClassName(item.getString("DRIVER_CLASS_NAME"));
                hikariDataSource.setUsername(item.getString("CONNECT_USERID"));
                hikariDataSource.setPassword(item.getString("CONNECT_PWD"));
                hikariDataSource.setPoolName(item.getString("DATABASE_ID") );

            }
        } catch (Exception ex) {
            log.error("请求异常：" + ex.toString());
        }
        return hikariDataSource;
    }


}
