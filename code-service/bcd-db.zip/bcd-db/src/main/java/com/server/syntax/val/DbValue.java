package com.server.syntax.val;

import com.server.db.DbConfig;
import com.server.generate.SQLSanitizer;
import com.server.params.DateIntervalType;
import com.server.params.GenerateSqlTran;
import com.server.params.Seq;
import com.server.params.SqlRestrictionsInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * @Description 数据库值获取
 * @Author liwei
 * @Date 2023/7/26 10:27     
 **/
@Service
public class DbValue {
    @Resource
    DbConfig dbConfig;

    @Qualifier("oracleVal")
    @Autowired
    DbValueServer  oracleVal;

    @Qualifier("postgreSqlVal")
    @Autowired
    DbValueServer  postgreSqlVal;
    @Qualifier("dmVal")
    @Autowired
    DbValueServer  dmVal;
    public SqlRestrictionsInfo queryRestrictions(String sqlScript) throws Exception {
        SqlRestrictionsInfo sqlRestrictionsInfo=new SqlRestrictionsInfo();
        String errInfo="";
        if(!StringUtils.isBlank(sqlScript)){
            String sql=sqlScript.toUpperCase(Locale.ROOT).trim();
            List<String> DANGEROUS_KEYWORDS=   SQLSanitizer.DANGEROUS_KEYWORDS;
            for (int i = 0; i < DANGEROUS_KEYWORDS.size(); i++) {
                if(sql.contains(DANGEROUS_KEYWORDS.get(i))){
                    sqlRestrictionsInfo.setRes(false);
                    errInfo+="不允许存在"+DANGEROUS_KEYWORDS.get(i)+"语法";
                }
            }
        }
        if(!sqlRestrictionsInfo.isRes()){
            sqlRestrictionsInfo.setErrInfo(errInfo);
        }
        return sqlRestrictionsInfo;
    }

    public String XmlSql(@Nullable String dbName ) throws Exception {
        String returnValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            returnValue= " SELECT * FROM (SELECT UPPER(T.TABLE_NAME) TABLE_NAME, UPPER(T.COLUMN_NAME)COLUMN_NAME,COLUMN_TYPE,COLUMN_SIZE FROM S_XML_MANAGE T WHERE 1=1)T WHERE 1=1  ";


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            returnValue= " SELECT * FROM (SELECT lower(T.TABLE_NAME)TABLE_NAME, lower(T.COLUMN_NAME)COLUMN_NAME,COLUMN_TYPE,COLUMN_SIZE FROM S_XML_MANAGE T WHERE 1=1)T WHERE 1=1  ";

        }
        if (Type.equals("4")) {

            returnValue= " SELECT * FROM (SELECT UPPER(T.TABLE_NAME) TABLE_NAME, UPPER(T.COLUMN_NAME)COLUMN_NAME,COLUMN_TYPE,COLUMN_SIZE FROM S_XML_MANAGE T WHERE 1=1)T WHERE 1=1  ";


        }
        return returnValue;
    }

    public String XmlValue(@Nullable String dbName, String val ) throws Exception {
        String returnValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            returnValue= val.toUpperCase(Locale.ROOT);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            returnValue= val.toLowerCase(Locale.ROOT);

        }
        if (Type.equals("4")) {

            returnValue= val.toUpperCase(Locale.ROOT);


        }
        return returnValue;
    }
    /**
     * 获取自增列数据值
     *
     * @param dbName
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSeqValue(@Nullable String dbName, String table ) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SeqValue= oracleVal.getSeqVal(dbName,table);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getSeqVal(dbName,table);

        }
        if (Type.equals("4")) {

            SeqValue= dmVal.getSeqVal(dbName,table);


        }
        return SeqValue;
    }
    /**
     * 获取自增列数据值
     *
     * @param dbName
     * @param seq
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public void getListSeqVal(@Nullable String dbName, Seq seq ) throws Exception {

        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            oracleVal.getListSeqVal(dbName,seq);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            postgreSqlVal.getListSeqVal(dbName,seq);

        }
        if (Type.equals("4")) {

            dmVal.getListSeqVal(dbName,seq);


        }
    }
    /**
     * 获取自增列数据库SQL文本
     *
     * @param dbName
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSeq(@Nullable String dbName, String table ) {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SeqValue= oracleVal.getSeq(table);

        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getSeq(table);

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getSeq(table);
        }
        return SeqValue;
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDateVal(@Nullable String dbName,String format) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            SeqValue= oracleVal.getSysDateVal(dbName,format);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getSysDateVal(dbName,format);
        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getSysDateVal(dbName,format);
        }
        return SeqValue;
    }

    /**
     * 获取数据库时间sql
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDataStr(@Nullable String dbName, String format) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            SeqValue= oracleVal.getSysDataStr(dbName,format);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {
            SeqValue= postgreSqlVal.getSysDataStr(dbName,format);

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getSysDataStr(dbName,format);
        }
        return SeqValue;
    }

    public String getDateSql(String dbName, String time, String format) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            SeqValue= oracleVal.getDateSql(dbName,time,format);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {
            SeqValue= postgreSqlVal.getDateSql(dbName,time,format);

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getDateSql(dbName,time,format);
        }
        return SeqValue;
    }
    public String getToDateColumSql(String dbName, String column, String format) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            SeqValue= oracleVal.getToDateColumSql(dbName,column,format);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {
            SeqValue= postgreSqlVal.getToDateColumSql(dbName,column,format);

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getToDateColumSql(dbName,column,format);
        }
        return SeqValue;
    }
    public String getDateColumSql(String dbName, String column, String format) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            SeqValue= oracleVal.getDateColumSql(dbName,column,format);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {
            SeqValue= postgreSqlVal.getDateColumSql(dbName,column,format);

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getDateColumSql(dbName,column,format);
        }
        return SeqValue;
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDateVal(@Nullable String dbName) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            SeqValue= oracleVal.getSysDateVal(dbName);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getSysDateVal(dbName);
        }

        if (Type.equals("4")) {
            SeqValue= dmVal.getSysDateVal(dbName);
        }
        return SeqValue;
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDate(@Nullable String dbName, String format) {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SeqValue= oracleVal.getSysDate(format);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getSysDate(format);
        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getSysDate(format);
        }
        return SeqValue;
    }

    /**
     * 获取数据库时间
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDate(@Nullable String dbName) {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SeqValue= oracleVal.getSysDate();


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getSysDate();

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getSysDate();
        }
        return SeqValue;
    }


    /**
     * 获取数据库时间
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran getSysDateGenerateSql(@Nullable String dbName) {
        GenerateSqlTran generateSqlTran = null;
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            generateSqlTran= oracleVal.getSysDateGenerateSql();


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            generateSqlTran= postgreSqlVal.getSysDateGenerateSql();

        }
        if (Type.equals("4")) {
            generateSqlTran= dmVal.getSysDateGenerateSql();
        }
        return generateSqlTran;
    }

    public String connectSymbol(@Nullable String dbName){
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.connect_symbol();
        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.connect_symbol();

        }
        if (Type.equals("4")) {
            sql= dmVal.connect_symbol();
        }
        return sql;
    }

    public String getSysDateIntervalDay(@Nullable String dbName, String val) {
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.getSysDateIntervalDay(val);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.getSysDateIntervalDay(val);

        }
        if (Type.equals("4")) {
            sql= dmVal.getSysDateIntervalDay(val);
        }
        return sql;
    }
    public String getCeil(@Nullable String dbName, String val) {
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.getCeil(val);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.getCeil(val);

        }
        if (Type.equals("4")) {
            sql= dmVal.getCeil(val);
        }
        return sql;
    }
    public String getMod(@Nullable String dbName,String except, String dividdeBy) {
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.getMod(except,dividdeBy);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.getMod(except,dividdeBy);

        }
        if (Type.equals("4")) {
            sql= dmVal.getMod(except,dividdeBy);
        }
        return sql;
    }
    public String getFloor(@Nullable String dbName, String val) {
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.getFloor(val);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.getFloor(val);

        }
        if (Type.equals("4")) {
            sql= dmVal.getFloor(val);
        }
        return sql;
    }

    /**
     * 获取数据库时间区间
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getDateInterval(@Nullable String dbName,int value, DateIntervalType dateType) {
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.getDateInterval(value,dateType);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.getDateInterval(value,dateType);

        }
        if (Type.equals("4")) {
            sql= dmVal.getDateInterval(value,dateType);
        }
        return sql;
    }

    public String getDateSubduction(@Nullable String dbName,String startDateFiled,String endDateFiled) {
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.getDateSubduction(startDateFiled,endDateFiled);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.getDateSubduction(startDateFiled,endDateFiled);

        }
        if (Type.equals("4")) {
            sql= dmVal.getDateSubduction(startDateFiled,endDateFiled);
        }
        return sql;
    }

    public String getTrunc(@Nullable String dbName,String startDateFiled,String symbol,String endDateFiled) {
        String sql = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sql= oracleVal.getTrunc(startDateFiled,symbol,endDateFiled);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sql= postgreSqlVal.getTrunc(startDateFiled,symbol,endDateFiled);

        }
        if (Type.equals("4")) {
            sql= dmVal.getTrunc(startDateFiled,symbol,endDateFiled);
        }
        return sql;
    }

    public String dual(@Nullable String dbName,String context){
        String contextValue = "SELECT "+context;
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            contextValue+= " FROM  DUAL ";


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            contextValue+= "";

        }
        if (Type.equals("4")) {
            contextValue+= " FROM  DUAL ";
        }
        return contextValue;
    }

    public String convertVarchar(@Nullable String dbName,String context){
        String contextValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            contextValue= oracleVal.convertVarchar(context);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            contextValue= postgreSqlVal.convertVarchar(context);

        }
        if (Type.equals("4")) {
            contextValue= dmVal.convertVarchar(context);
        }
        return contextValue;
    }

    public String convertVarchar(@Nullable String dbName,String context,String format){
        String contextValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            contextValue= oracleVal.convertVarchar(context,format);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            contextValue= postgreSqlVal.convertVarchar(context,format);

        }
        if (Type.equals("4")) {
            contextValue= dmVal.convertVarchar(context,format);
        }
        return contextValue;
    }

    public String getTrim(@Nullable String dbName,String context){
        String contextValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            contextValue= oracleVal.getTrim(context);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            contextValue= postgreSqlVal.getTrim(context);

        }
        if (Type.equals("4")) {
            contextValue= dmVal.getTrim(context);
        }
        return contextValue;
    }


    /**
     * 获取数据库行
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getRowNum(@Nullable String dbName,int row) {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SeqValue= oracleVal.getRowNum(row);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getRowNum(row);

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getRowNum(row);
        }
        return SeqValue;
    }

    /**
     * 获取数据库行
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getRowVal(@Nullable String dbName) {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SeqValue= oracleVal.getRowVal();


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.getRowVal();

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.getRowVal();
        }
        return SeqValue;
    }

    public String getDecimalPoint(@Nullable String dbName,String context,String precision){
        String contextValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            contextValue= "ROUND("+context+","+precision+")";


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            contextValue=context+" :: float";

        }
        if (Type.equals("4")) {
            contextValue= "ROUND("+context+","+precision+")";
        }
        return contextValue;
    }

    /**
     * 获取数据库所有表信息
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getTableDescription(@Nullable String dbName){
        String sqlStr = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            sqlStr = oracleVal.getTableDescription();
        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            sqlStr = postgreSqlVal.getTableDescription();
        }
        if (Type.equals("4")) {
            sqlStr = dmVal.getTableDescription();
        }
        return sqlStr;
    }

    /**
     * 获取自增列数据值
     *
     * @param dbName
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String createTable(@Nullable String dbName, String table,String copyTable ) throws Exception {
        String SeqValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            SeqValue= oracleVal.createTable(table,copyTable);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            SeqValue= postgreSqlVal.createTable(table,copyTable);

        }
        if (Type.equals("4")) {
            SeqValue= dmVal.createTable(table,copyTable);
        }
        return SeqValue;
    }

    /**
     * 初始化SEQ
     * @param dbName
     * @param tableName
     * @param startVal
     * @return
     * @throws Exception
     */
    public String resetSeqSql(@Nullable String dbName,String tableName ,int startVal) throws Exception {
        String returnValue = "";
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {

            returnValue= " SELECT SETVAL('"+tableName+"_seq',"+startVal+",0) FROM DUAL ";


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            returnValue= " ELECT setval('" + tableName + "_seq', 1, false)  ";

        }
        if (Type.equals("4")) {
            returnValue= " SELECT SETVAL('"+tableName+"_seq',"+startVal+",0) FROM DUAL ";
        }
        return returnValue;
    }
}
