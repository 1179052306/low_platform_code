package com.server;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author lw
 * @date: 2025/3/10
 * @description:
 **/
@Component
public class ApplicationNameProvider {
    @Value("${spring.application.name:unknown}")
    private String applicationName;

    public String getApplicationName() {
        return applicationName;
    }
}
