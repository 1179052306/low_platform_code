package com.server.dataset;

import java.util.ArrayList;
import java.util.stream.Stream;

/**
 * @Author
 * @Date 2022/11/14 11:28
 */
public class DataTable {

    public DataTable() {

        columns = new DataColumnCollection(this);

        rows = new DataRowCollection(columns, this);


    }

    public DataColumnCollection getColumns() {
        return columns;
    }

    public DataColumn getColumns(int index) {
        return columns.getColumn(index);
    }

    public void setColumns(DataColumnCollection columns) {
        this.columns = columns;
    }

    private DataColumnCollection columns = null;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String tableName = "table1";

    public DataRowCollection getRows() {
        return rows;
    }

    public DataRow getRows(int index) {
        return rows.getRow(index);
    }

    public int size() {
        return rows.size();
    }
//    public DataRow getRow(int index) {
//        return rows.getRow(index);
//    }
//
//    public DataColumn getColumn(int index) {
//        return columns.getColumn(index);
//    }
//    public void setRows(DataRowCollection rows) {
//        this.rows = rows;
//    }

    public DataRowCollection rows = null;

    public String getFirstRowVal(String column) {
        return rows.getRow(0).getVal(column).toString();
    }

    public <E> Stream<E> stream() {
        return  rows.getRows().stream();
    }

}
