package com.server.params;


/**
 * @Description 指定位置参数替换实体类
 * @Author liwei
 * @Date 2023/7/25 13:57     
 **/
public class Rpc{

    public Rpc(String tableAlias,String paramentName){

        this.paramentName=paramentName;
        this.tableAlias=tableAlias;
    }

    private  String tableAlias="";////表别名

    private  String paramentName="";/////字段名称

    public String getParamentName() {   return paramentName; }

    public String getTableAlias() { return tableAlias; }

    public void setParamentName(String paramentName) { this.paramentName = paramentName; }

    public void setTableAlias(String tableAlias) {
        this.tableAlias = tableAlias;
    }


}
