package com.server.syntax.val;

import com.server.params.DateIntervalType;
import com.server.params.GenerateSqlTran;
import com.server.params.Seq;
import org.springframework.lang.Nullable;

/**
 * @Description 数据库值获取
 * @Author liwei
 * @Date 2023/7/26 10:30
 **/
public interface DbValueServer {

    /**
     * 获取自增列数据库SQL文本
     *
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSeq(String table);

    /**
     * 获取自增列数据值
     *
     * @param dbName
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSeqVal(@Nullable String dbName, String table) throws Exception;

    public void getListSeqVal(@Nullable String dbName, Seq seq)throws Exception;
    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDateVal(@Nullable String dbName) throws Exception;

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDateVal(@Nullable String dbName, String format) throws Exception;

    public String getSysDateIntervalDay(String val);
    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDataStr(@Nullable String dbName, String format) throws Exception;

    public String getToDateColumSql(@Nullable String dbName, String time, String format) throws Exception;

    public String getDateSql(@Nullable String dbName, String time, String format) throws Exception;

    public String getDateColumSql(@Nullable String dbName, String column, String format) throws Exception;

    public String getCeil( String val) ;

    public String getFloor(String val) ;
    public String getMod(String except,String dividdeBy) ;

    public String connect_symbol();
    /**
     * 获取数据库时间值
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDate();
    /**
     * 获取数据库时间值
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran getSysDateGenerateSql();
    /**
     * 获取数据库时间值
     *
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getSysDate(String format);

    public String getDateInterval(int value, DateIntervalType dateType);
//    public String getColumnDateInterval(String cloumn ,int value, DateIntervalType dateType);
    public String getDateSubduction(String startDateFiled,String endDateFiled) ;

    public String getTrunc(String startDateFiled,String symbol,String endDateFiled) ;
    /**
     * 获取数据库字段详情
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String convertVarchar(String context);
    public String convertVarchar(String context,String format);
    /**
     * 去空格
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getTrim(String context);
    /**
     * 获取数据库字段详情
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getRowNum( int row);

    /**
     * 获取数据库字段详情
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getRowVal();
    /**
     * 获取数据库字段详情
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public String getTableDescription();


    public String createTable(String table,String copyTable) throws Exception;
}
