package com.server.params;

/**
 * @author lw
 * @date: 2023/11/1
 * @description:
 **/
public class DbCustomParameter {

    private boolean isOrg = false;////组织数据权限

    private boolean isAllOrg = false;////组织数据权限

    private boolean isWh = false;////仓库数据权限

    private boolean isConsignor = false;////货主数据权限

    private boolean isOrderType = false;////货主数据权限

    private String customSql = null;////组织数据权限

    private boolean isTranSport = false;////承运商数据权限

    public boolean isTranSport() {
        return isTranSport;
    }

    public void setTranSport(boolean tranSport) {
        isTranSport = tranSport;
    }

    public boolean isWh() {
        return isWh;
    }

    public void setWh(boolean wh) {
        isWh = wh;
    }

    public boolean isOrg() {
        return isOrg;
    }

    public void setOrg(boolean org) {
        isOrg = org;
    }

    public boolean isAllOrg() {
        return isAllOrg;
    }

    public void setAllOrg(boolean allOrg) {
        isAllOrg = allOrg;
    }

    public String getCustomSql() {
        return customSql;
    }

    public void setCustomSql(String customSql) {
        this.customSql = customSql;
    }

    public boolean isConsignor() {
        return isConsignor;
    }

    public void setConsignor(boolean consignor) {
        isConsignor = consignor;
    }

    public boolean isOrderType() {
        return isOrderType;
    }

    public void setOrderType(boolean orderType) {
        isOrderType = orderType;
    }
}
