package com.server.generate;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.MultiDataSource;
import com.server.params.*;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.List;


@Component
@Service
public class GenerateSql implements GenerateSqlImpl {

    @Resource
    private CommonImpl common;

    @Resource
    public MultiDataSource dataSource;

    private static WhereSql whereSql = new WhereSql();

    /**
     * SQL插入
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran executeInsert(@Nullable String dbName, String tableName, JSONObject json) {
        return executeInsert(dbName, tableName, json, null);
    }

    /**
     * SQL插入
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran executeInsert(@Nullable String dbName, String tableName, JSONObject json, List<Object> masterMagic) {
        return common.insert(dbName, tableName, json, masterMagic);
    }

    /**
     * SQL修改
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listwhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran executeUpdate(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listwhere) {
        return executeUpdate(dbName, tableName, json, listwhere, null);
    }

    /**
     * SQL修改
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param listwhere
     * @param masterMagic
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran executeUpdate(@Nullable String dbName, String tableName, JSONObject json, List<Wheres> listwhere, List<Object> masterMagic) {
        return common.update(dbName, tableName, json, listwhere, masterMagic);
    }


    /**
     * SQL删除
     *
     * @param dbName
     * @param tableName
     * @param listwhere
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran executeDelete(@Nullable String dbName, String tableName, List<Wheres> listwhere) {
        return common.delete(dbName, tableName, listwhere);
    }

    /**
     * SQL删除
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param listwhere
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public void executeDelete(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<Wheres> listwhere) {
        listExecuteSqlTran.add(common.delete(dbName, tableName, listwhere));
    }

    /**
     * SQL集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public void executeListInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json) {
        executeListInsert(dbName, tableName, listExecuteSqlTran, json, null);
    }

    /**
     * SQL集合插入
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public void executeListInsert(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json, List<Object> masterMagic) {
        common.listInsert(dbName, tableName, listExecuteSqlTran, json, masterMagic);
    }

    /**
     * SQL集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @param listwhere
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public void executeListUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json, List<Wheres> listwhere) {
        executeListUpdate(dbName, tableName, listExecuteSqlTran, json, listwhere, null);
    }

    /**
     * SQL集合修改
     *
     * @param dbName
     * @param tableName
     * @param listExecuteSqlTran
     * @param json
     * @param listwhere
     * @param masterMagic
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public void executeListUpdate(@Nullable String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, JSONArray json, List<Wheres> listwhere, List<Object> masterMagic) {
        common.listUpdate(dbName, tableName, listExecuteSqlTran, json, listwhere, masterMagic);
    }

    @Override
    public void executeListInsert(String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList) {
        executeListInsert(dbName, tableName, listExecuteSqlTran, jsonObjectList, null);
    }

    @Override
    public void executeListInsert(String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Object> masterMagic) {
        common.listInsert(dbName, tableName, listExecuteSqlTran, jsonObjectList, masterMagic);
    }

    @Override
    public void executeListUpdate(String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Wheres> listwhere) {
        executeListUpdate(dbName, tableName, listExecuteSqlTran, jsonObjectList, listwhere, null);
    }

    @Override
    public void executeListUpdate(String dbName, String tableName, List<GenerateSqlTran> listExecuteSqlTran, List<JSONObject> jsonObjectList, List<Wheres> listwhere, List<Object> masterMagic) {
        common.listUpdate(dbName, tableName, listExecuteSqlTran, jsonObjectList, listwhere, masterMagic);
    }

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName) {
        return sqlQuery(dbName, tableName, null);
    }

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, JSONArray json) {
        return sqlQuery(dbName, tableName, json, null);
    }

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, JSONArray json, List<Rps> rpsList) {
        return common.sqlQueryParameter(dbName, tableName, json, rpsList);
    }

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param strSql
     * @param json
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, StringBuilder strSql, JSONArray json) {
        return sqlQuery(dbName, tableName, strSql, json, null);
    }

    /**
     * SQL查询
     *
     * @param dbName
     * @param tableName
     * @param strSql
     * @param json
     * @param rpsList
     * @return GenerateSqlTran
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public GenerateSqlTran sqlQuery(@Nullable String dbName, String tableName, StringBuilder strSql, JSONArray json, List<Rps> rpsList) {
        StringBuilder querSql = new StringBuilder();
        querSql.append(strSql.toString());
        JSONArray filter=new JSONArray();
        if(json!=null){
            for (int i = 0; i < json.size(); i++) {
                filter.add(json.getJSONObject(i));
            }
        }else{
             filter=null;
        }
        return common.sqlQueryParameter(dbName, tableName, querSql, filter, rpsList);
    }

    /**
     * 查询条件手动添加
     *
     * @param jsonArray
     * @param id
     * @param value
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public void add(JSONArray jsonArray, String id, String value) {
        whereSql.add(jsonArray, id, value,"T");
    }

    /**
     * 查询条件手动添加
     *
     * @param jsonArray
     * @param id
     * @param symbol
     * @param value
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public void add(JSONArray jsonArray,String id,  String symbol, String value) {
        whereSql.add(jsonArray, symbol, id, value,"T");
    }

    /**
     * 查询条件手动添加
     *
     * @param id
     * @param symbol
     * @param value
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray add( String id, String symbol,String value) {
        JSONArray json = new JSONArray();
        whereSql.add(json, symbol, id, value,"T");
        return json;
    }
    @Override
    public JSONArray addContainAlias(String id, String value, String TableAlias) {
        JSONArray json = new JSONArray();
        whereSql.add(json, "=", id, value,TableAlias);
        return json;
    }

    @Override
    public void addContainAlias(JSONArray jsonArray, String id, String value, String TableAlias) {
        whereSql.add(jsonArray,  id, value,TableAlias);
    }

    @Override
    public JSONArray addContainAlias(String id, String symbol, String value, String TableAlias) {
        JSONArray json = new JSONArray();
        whereSql.add(json, symbol, id, value,TableAlias);
        return json;
    }

    @Override
    public void addContainAlias(JSONArray jsonArray, String id, String symbol, String value, String TableAlias) {
        whereSql.add(jsonArray, symbol, id, value,TableAlias);
    }
    /**
     * 查询条件手动添加
     *
     * @param id
     * @param value
     * @return JSONArray
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public JSONArray add(String id, String value) {
        JSONArray json = new JSONArray();
        whereSql.add(json, "=", id, value,"T");
        return json;
    }

    /**
     * 查询条件后台手动验证字段是否合法
     *
     * @param json
     * @param whereValidates
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public boolean validateQuery(JSONArray json, List<WhereValidate> whereValidates) {

        return whereSql.validate(json, whereValidates);
    }

    /**
     * 检查参数字段是否合法
     *
     * @param column
     * @param generateSqlTran
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public boolean checkParameter(String column, GenerateSqlTran generateSqlTran) {
        return common.checkParameter(column, generateSqlTran);
    }



}
