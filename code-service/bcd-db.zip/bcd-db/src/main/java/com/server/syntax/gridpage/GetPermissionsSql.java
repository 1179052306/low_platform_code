package com.server.syntax.gridpage;

import com.server.getdata.TableAttribute;
import com.server.params.DataParameter;
import com.server.params.DbCustomParameter;
import com.server.tenant_http.TenantHttpContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

/**
 * @author lw
 * @date: 2024/1/19
 * @description:
 **/
@Service
public class GetPermissionsSql {


    public  String getPermissionsSql(String tableSql,DataParameter dataParameter,  @Nullable DbCustomParameter dbCustomParameter,TableAttribute tableAttribute){
        if(dbCustomParameter==null){
            dataParameter.setUserCustomSql(false);
        }
        if (dataParameter.isUseCustomSql()) {
            tableSql = getSqlString(tableAttribute, tableSql, dbCustomParameter.isAllOrg(), dbCustomParameter.isOrg(), dbCustomParameter.isConsignor(), dbCustomParameter.isWh(),dbCustomParameter.isOrderType(),dbCustomParameter.isTranSport());
            if (dbCustomParameter.getCustomSql() != null) {
                tableSql += dbCustomParameter.getCustomSql();
            }
        } else {
            tableSql = getSqlString(tableAttribute, tableSql, dataParameter.isAllOrg(), dataParameter.isOrg(), dataParameter.isConsignor(), dataParameter.isWh(),dataParameter.isOrderType(),dataParameter.isTranSport());

            if (dataParameter.getCustomSql() != null) {
                tableSql += dataParameter.getCustomSql();
            }
        }
        return  tableSql;
    }


    private String getSqlString(TableAttribute tableAttribute, String tableSql, boolean allOrg, boolean org, boolean consignor, boolean wh, boolean orderType, boolean isTranSport)  {

        //7 承运商
        int usertype=5;
        try {
            usertype = Integer.parseInt(TenantHttpContext.getHeader("usertype"));

        }catch(Exception e){

        }


        if (allOrg) {
            tableSql += " AND T.ORG_KEY IN (SELECT ORG_KEY FROM S_JURISDICTION_ORG O WHERE 1=1 AND O.JURISDICTION_KEY=" + tableAttribute.getJurisdiction_key() + " )";
        } else if (org) {
            tableSql += " AND T.ORG_KEY IN  (SELECT ORG_KEY FROM S_JURISDICTION_ORG O WHERE 1=1 AND O.JURISDICTION_KEY=" + tableAttribute.getJurisdiction_key() + " AND O.ORG_KEY=" + tableAttribute.getOrg_key() + ")";
        }
        if (consignor) {
            tableSql += " AND T.CONSIGNOR_KEY IN (SELECT CONSIGNOR_KEY FROM WMS.S_JURISDICTION_CONSIGNOR C  WHERE 1=1 AND C.JURISDICTION_KEY=" + tableAttribute.getJurisdiction_key() + " AND C.ORG_KEY=" + tableAttribute.getOrg_key() + ")";
        }
        if (wh) {
            tableSql += " AND T.WH_KEY IN (SELECT WH_KEY FROM S_JURISDICTION_WH W  WHERE 1=1 AND W.JURISDICTION_KEY=" + tableAttribute.getJurisdiction_key()  + ")";
        }
        if (orderType) {
            tableSql += " AND T.ORDER_TYPE NOT IN (SELECT ORTYPE_KEY FROM S_USER_ORDERTYPE WHERE USER_KEY="+tableAttribute.getUser_key()+")";
        }

        if (isTranSport&&usertype==7) {
            tableSql += " AND T.TRANSPORT_KEY = (SELECT TRANSPORT_KEY FROM S_USER WHERE USER_KEY="+tableAttribute.getUser_key()+")";
        }

        return tableSql;
    }
}
