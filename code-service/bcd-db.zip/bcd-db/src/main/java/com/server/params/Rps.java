package com.server.params;


import java.io.Serializable;

/**
 * @Description Rps参数转换SQL实体类
 * @Author liwei
 * @Date 2023/7/25 13:59     
 **/
public class Rps implements Serializable {

    public Rps( String paramentName,String sql){

        this.paramentName=paramentName;
        this.sql=sql;
    }

    private  String sql="";////值转换后的SQL

    private  String paramentName="";////字段名称

    public String getSql() {
        return sql;
    }

    public String getParamentName() {
        return paramentName;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public void setParamentName(String paramentName) {
        this.paramentName = paramentName;
    }
}
