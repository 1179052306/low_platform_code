package com.server.thread;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.MultiDataSourceHolder;
import com.server.db.Tenant;
import com.server.params.GenerateSqlTran;
import com.server.special_handle.SpecialHandleInterface;
import com.server.tenant.TenantData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author lw
 * @date: 2025/2/26
 * @description:
 **/


public class ThreadBase extends Thread {

    private ThreadsObject threadsObject;

    public <T> ThreadBase(ThreadsObject threadsObject, T... args) {

        this.threadsObject = threadsObject;
    }

    public ThreadBase() {

    }


    @Override
    public void run() {
        try {
            threadsObject.threadState.setNowState(ThreadStateType.run);
            writeTableState();
            while (true) {
                if (threadsObject.threadState.threadStateType == ThreadStateType.stop) {
                    threadsObject.threadState.setNowState(ThreadStateType.notstart);
                    writeTableState();
                    break;
                }
                threadsObject.threadState.setNowState(ThreadStateType.run);
                writeTableState();
                try {
                    if (threadsObject.dbComposite != null) {
                        if (!threadsObject.dbComposite.tenant.getSingle()) {
                            threadsObject.dbComposite.multiDataSourceHolder.setDatasource(threadsObject.tenantId);
                        }
                    }

                    try {
                        execute();
                    } catch (Exception exception) {

                    } finally {
                        if (threadsObject.dbComposite != null) {
                            threadsObject.dbComposite.multiDataSourceHolder.clearDataSource();
                        }
                    }


                } catch (Exception ex) {

                } finally {
                    threadsObject.threadState.setNowState(ThreadStateType.hibernate);
                    writeTableState();
                    if (threadsObject.getSleep() > 0) {
                        Thread.sleep(threadsObject.getSleep());
                    }
                }

            }
        } catch (Exception exception) {

        }

    }

    public void execute() throws Exception {

    }

    public void writeTableState() throws Exception {

        try {
            if (threadsObject.threadTable != null) {
                if (!threadsObject.dbComposite.tenant.getSingle()) {
                    threadsObject.dbComposite.multiDataSourceHolder.setDatasource(threadsObject.tenantId);
                }

                String sql = "UPDATE " + threadsObject.threadTable.getTableName() + "  SET " + threadsObject.threadTable.getTableStateColumn() + "=" + threadsObject.threadState.nowState.getStateType();

                if (threadsObject.threadTable.getTableDataColumn() != null) {
                    sql += " , " + threadsObject.threadTable.getTableDataColumn() + "=" + threadsObject.dbComposite.dbValue.getSysDate(threadsObject.project) + "";
                }

                try {
                    int pkVal = Integer.parseInt(threadsObject.threadTable.getTablePkVal());
                    sql += "   WHERE 1=1 AND " + threadsObject.threadTable.getTablePkColumn() + "=" +pkVal + "";
                } catch (Exception ex) {
                    sql += "   WHERE 1=1 AND " + threadsObject.threadTable.getTablePkColumn() + "='" + threadsObject.threadTable.getTablePkVal() + "'";
                }


                threadsObject.getDbComposite().dbHelp.executeSql(threadsObject.getProject(), new GenerateSqlTran(sql));
                if (!threadsObject.dbComposite.tenant.getSingle()) {
                    threadsObject.dbComposite.multiDataSourceHolder.clearDataSource();
                }
            }
        } catch (Exception ex) {

        }
    }

    public String getUserInfo(JSONObject row) throws Exception {
        JSONObject userInfo = new JSONObject();
        userInfo.put("org_key", row.getString("ORG_KEY"));
        userInfo.put("user_key", row.getString("CREATE_USER_KEY"));
        userInfo.put("user_id", row.getString("CREATE_USER_ID"));
        userInfo.put("user_name", row.getString("CREATE_USER_NAME"));
        if (!threadsObject.dbComposite.tenant.getSingle()) {
            userInfo.put("tenant", threadsObject.tenantId);
        }
        return userInfo.toJSONString();

    }
}
