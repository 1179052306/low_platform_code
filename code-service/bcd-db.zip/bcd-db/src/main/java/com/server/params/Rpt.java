package com.server.params;

/**
 * @Description 参数可替换类型
 * @Author liwei
 * @Date 2023/7/26 10:33
 **/
public class Rpt{

    public Rpt(String paramentName, String paramentVal){

        this.paramentName=paramentName;
        this.paramentVal=paramentVal;
    }

    private  String paramentVal="";/////需要替换的相关内容

    private  String paramentName="";/////字段名称

    public String getParamentVal() {
        return paramentVal;
    }

    public String getParamentName() {
        return paramentName;
    }


    public void setParamentVal(String paramentVal) {
        this.paramentVal = paramentVal;
    }

    public void setParamentName(String paramentName) {
        this.paramentName = paramentName;
    }

}
