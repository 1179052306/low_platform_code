package com.server.params;

//import com.server.Db.DbConfig;

/**
 * @Author
 * @Date 2022/11/18 16:28
 */
public class DbDate{
//    @Autowired
//    private DbConfig dbConfig;
    public  String getDate() {


        String date="";
//
//        if (dbConfig.getDbType().equals("0")) {
//
//            date="";
//        }
//        if (dbConfig.getDbType().equals("1")) {
//
//            date="to_date(to_char(sysdate,'yyyy-MM-dd HH24:mi:ss'),'yyyy-MM-dd HH24:mi:ss') ";
//
//        }
//        if (dbConfig.getDbType().equals("2")) {
//            date="";
//
//        }
//        if (dbConfig.getDbType().equals("3")) {
//            date="";
//
//        }
        return  date;
    }
    public  String setValue(String Value) {


        String date="";

//        if (dbConfig.getDbType().equals("0")) {
//
//            date="";
//        }
//        if (dbConfig.getDbType().equals("1")) {
//
//            date="to_date('"+Value+"','yyyy-MM-dd HH24:mi:ss') ";
//
//        }
//        if (dbConfig.getDbType().equals("2")) {
//            date="";
//
//        }
//        if (dbConfig.getDbType().equals("3")) {
//            date="";
//
//        }
        return  date;
    }


}
