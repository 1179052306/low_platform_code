package com.server.redisson;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

@Configuration
public class RedissonConfig {

    @Value("${spring.redis.host}")
    private String redisHost;

    @Value("${spring.redis.port}")
    private int redisPort;

    @Value("${spring.redis.password}")
    private String redisPassword;

    @Value("${spring.redis.timeout}")
    private String timeout; // 格式是 3s，Spring 会自动解析

    @Value("${spring.redis.databases}")
    private int database;

    @Bean
    public RedissonClient redissonClient() {
        // 将 timeout 解析为毫秒
        long timeoutMillis = 3000; // 默认为 3s
        if (timeout.endsWith("s")) {
            timeoutMillis = Long.parseLong(timeout.replace("s", "")) * 1000;
        }

        Config config = new Config();
        String redisAddress = "redis://" + redisHost + ":" + redisPort;

        config.useSingleServer()
                .setAddress(redisAddress)
                .setPassword(redisPassword)
                .setTimeout((int) timeoutMillis)  // 设置连接超时时间
                .setDatabase(database); // 设置数据库索引（默认为 0）

        return Redisson.create(config);
    }
}

