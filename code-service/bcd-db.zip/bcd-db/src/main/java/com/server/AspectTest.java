//package com.server;
//
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.*;
//import org.springframework.context.annotation.Configuration;
//
//import java.util.Arrays;
//
//@Aspect //声明这是个切面
//@Configuration
//public class AspectTest {
//    @Pointcut(value = "execution(* com.server.control.*.* (..))")//切点路径
//    public void pointcut() {
//    }
//    //前置通知（进入环绕后执行，下一步执行方法）
//    @Before(value="pointcut()")
//    public void doAccessCheck(JoinPoint joinPoint){
//        System.out.println("@Before前置通知:"+ Arrays.toString(joinPoint.getArgs()));
//    }
//
//    //环绕通知
//    @Around(value = "pointcut()")
//    public Object doaround(ProceedingJoinPoint point)throws Throwable{
//        System.out.println("***enter Around***");
//        Object object=point.proceed();
//        System.out.println(point.getThis()+"***end Around***");
//        return object;
//    }
//
//    //异常通知（出错时执行）
//    @AfterThrowing(value="pointcut()",throwing="ex")
//    public void doAfterThrow(JoinPoint joinPoint,Throwable ex){
//        System.out.println("@AfterThrowing例外通知(异常通知)"+Arrays.toString(joinPoint.getArgs()));
//        System.out.println("@AfterThrowing异常信息："+ex);
//    }
//
//    //后置通知(返回之前执行)
//    @After(value="pointcut()")
//    public void after(){
//        System.out.println("@After后置通知...");
//    }
//
//    //最终通知（正常返回通知，最后执行）
//    @AfterReturning(value="pointcut()")
//    public void doAfter(){
//        System.out.println("@AfterReturning最终通知...End!");
//    }
//}
