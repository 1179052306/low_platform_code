package com.server.params;

/**
 * @Description 错误信息
 * @Author liwei
 * @Date 2023/7/26 10:20     
 **/
public class GenerateErr{

    public GenerateErr(String errName, String errVal){

        this.errName=errName;
        this.errVal=errVal;
    }
    private  String errName="";////错误名称

    private  String errVal="";////错误详情

    public String getErrName() {
        return errName;
    }

    public String getErrVal() {
        return errVal;
    }

    public void setErrName(String errName) {
        this.errName = errName;
    }

    public void setErrVal(String errVal) {
        this.errVal = errVal;
    }


}
