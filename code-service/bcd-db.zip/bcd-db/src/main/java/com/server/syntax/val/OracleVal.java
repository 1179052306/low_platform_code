package com.server.syntax.val;

import com.server.dataset.DataTable;
import com.server.db.DbHelpImpl;
import com.server.params.DateIntervalType;
import com.server.params.GenerateSqlTran;
import com.server.params.Seq;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description Oracle数据库值获取
 * @Author liwei
 * @Date 2023/7/26 10:34
 **/
@Service
public class OracleVal implements DbValueServer {

    @Autowired
    private DbHelpImpl dbHelp;

    /**
     * 获取自增列数据库SQL文本
     *
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSeq(String table) {
        return table + "_SEQ.NEXTVAL";
    }

    /**
     * 获取自增列数据值
     *
     * @param dbName
     * @param table
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSeqVal(@Nullable String dbName, String table) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT " + table + "_SEQ.NEXTVAL FROM DUAL");
        return dbHelp.query(dbName, stringBuilder.toString()).getRows().getRow(0).getVal(0).toString();
    }

    @Override
    public void getListSeqVal(@Nullable String dbName, Seq seq) throws Exception {
        List<Long> value = new ArrayList<>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT " + seq.getTable() + "_SEQ.NEXTVAL FROM (");
        for (int i = 0; i < seq.getNum(); i++) {
            stringBuilder.append("SELECT 1 FROM DUAL");
            if (i < seq.getNum() - 1) {
                stringBuilder.append(" UNION ALL ");
            }
        }
        stringBuilder.append(")");
        DataTable dataTable = dbHelp.query(dbName, stringBuilder.toString());

        for (int i = 0; i < dataTable.size(); i++) {
            value.add(Long.parseLong(dataTable.getRows(i).getVal(0).toString()));

        }
        seq.setSeqList(value);
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDateVal(@Nullable String dbName) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT to_date(to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss') FROM DUAL");
        return dbHelp.query(dbName, stringBuilder.toString()).getRows().getRow(0).getVal(0).toString();
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDateVal(@Nullable String dbName, String format) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT to_char(sysdate,'" + format + "') FROM DUAL");
        return dbHelp.query(dbName, stringBuilder.toString()).getRows().getRow(0).getVal(0).toString();
    }

    @Override
    public String getSysDateIntervalDay(String val) {
        return " SYSDATE-"+val+" ";
    }

    /**
     * 获取数据库时间值
     *
     * @param dbName
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDataStr(@Nullable String dbName, String format) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("to_date(to_char(sysdate,'"+format+"'),'"+format+"')");
        return stringBuilder.toString();
    }

    @Override
    public String getDateSql(String dbName, String time, String format) throws Exception {
        if (StringUtils.isBlank(time)) {
            return "null";
        }
        String sql = "to_date('" + time + "','" + format + "')";
        return sql;
    }
    @Override
    public String getToDateColumSql(String dbName, String column, String format) throws Exception {
        String sql = "to_date(" + column + ",'" + format + "')";
        return sql;
    }
    @Override
    public String getDateColumSql(String dbName, String column, String format) throws Exception {
        String sql = "to_date(to_char(" + column + ",'" + format + "'),'" + format + "')";
        return sql;
    }

    @Override
    public String getCeil( String val) {
        return " CEIL("+val+") ";
    }

    @Override
    public String getFloor( String val)  {
        return " FLOOR("+val+") ";
    }

    @Override
    public String getMod(String except, String dividdeBy) {
        return " mod("+except+","+dividdeBy+") ";
    }

    @Override
    public String connect_symbol() {
        return "||";
    }

    /**
     * 获取数据库时间SQL文本
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDate() {
        return "to_date(to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss')";
    }

    @Override
    public String getDateInterval(int value, DateIntervalType dateType) {
        String sql="";
        if(dateType.getIntervalType().equals(DateIntervalType.year.getIntervalType())){
            sql=" NUMTOYMINTERVAL("+value+",'"+dateType.getIntervalType()+"')";
        }
        if(dateType.getIntervalType().equals(DateIntervalType.month.getIntervalType())){
            sql=" NUMTOYMINTERVAL("+value+",'"+dateType.getIntervalType()+"')";
        }
        if(dateType.getIntervalType().equals(DateIntervalType.day.getIntervalType())){
            sql=" NUMTODSINTERVAL("+value+",'"+dateType.getIntervalType()+"')";
        }
        if(dateType.getIntervalType().equals(DateIntervalType.week.getIntervalType())){
            sql=" NUMTODSINTERVAL("+value*7+",'"+DateIntervalType.day.getIntervalType()+"')";
        }
        if(dateType.getIntervalType().equals(DateIntervalType.hour.getIntervalType())){
            sql=" NUMTODSINTERVAL("+value+",'"+dateType.getIntervalType()+"')";
        }
        if(dateType.getIntervalType().equals(DateIntervalType.minute.getIntervalType())){
            sql=" NUMTODSINTERVAL("+value+",'"+dateType.getIntervalType()+"')";
        }
        if(dateType.getIntervalType().equals(DateIntervalType.second.getIntervalType())){
            sql=" NUMTODSINTERVAL("+value+",'"+dateType.getIntervalType()+"')";
        }
        return  sql;
    }
//    @Override
//    public String getColumnDateInterval(String cloumn ,int value, DateIntervalType dateType) {
//        return " INTERVAL '"+value+"' "+dateType.getIntervalType()+"";
//    }
    @Override
    public String getDateSubduction(String startDateFiled, String endDateFiled) {
        return " TRUNC("+startDateFiled+" - "+endDateFiled+")";
    }

    @Override
    public String getTrunc(String startDateFiled, String symbol, String endDateFiled) {
        return " TRUNC("+startDateFiled+" "+symbol+" "+endDateFiled+")";
    }


    @Override
    public String convertVarchar(String context) {
        return " TO_CHAR(" + context + ")";
    }

    @Override
    public String convertVarchar(String context, String format) {
        return " TO_CHAR(" + context + ",'"+format+"')";
    }

    @Override
    public String getTrim(String context) {
        return " TRIM(" + context + ")";
    }

    @Override
    public GenerateSqlTran getSysDateGenerateSql() {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        generateSqlTran.set_strsql("SELECT to_date(to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),'yyyy-mm-dd hh24:mi:ss') AS NEW_DATE  FROM DUAL");
        generateSqlTran.setTableName("NEW_DATE");
        return generateSqlTran;
    }

    /**
     * 获取数据库时间SQL文本
     *
     * @param format
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getSysDate(String format) {
        return " to_date(to_char(sysdate,'" + format + "'),'" + format + "')";
    }

    @Override
    public String getRowNum(int row) {
        return " and rownum <=" + row + "";
    }

    @Override
    public String getRowVal() {
        return "rownum";
    }

    /**
     * 获取数据库字段详情
     *
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @Override
    public String getTableDescription() {
        return "SELECT * FROM (SELECT COLS.TABLE_NAME AS TABLE_NAME, USER_TAB_COMMENTS.COMMENTS AS TABLE_CAPTION, COLS.COLUMN_NAME AS COLUMN_NAME, " +
                "DATA_TYPE AS COLUMN_TYPE, USER_COL_COMMENTS.COMMENTS AS COLUMN_CAPTION, COLS.NULLABLE AS IS_NULLABLE FROM COLS LEFT JOIN USER_TAB_COMMENTS " +
                "ON ( COLS.TABLE_NAME =  USER_TAB_COMMENTS.TABLE_NAME) LEFT JOIN USER_COL_COMMENTS ON ( COLS.TABLE_NAME = USER_COL_COMMENTS.TABLE_NAME AND " +
                "COLS.COLUMN_NAME = USER_COL_COMMENTS.COLUMN_NAME ) GROUP BY COLS.TABLE_NAME, USER_TAB_COMMENTS.COMMENTS, COLS.COLUMN_NAME, COLS.DATA_TYPE, " +
                "USER_COL_COMMENTS.COMMENTS, COLS.NULLABLE ORDER BY COLS.TABLE_NAME) T WHERE 1=1 ";
    }

    @Override
    public String createTable(String table, String copyTable) throws Exception {
        return "CREATE TABLE " + table + " AS SELECT * FROM " + copyTable + " WHERE 1=0";
    }


}
