package com.server.params;


/**
 * @Description 字段参数实体类
 * @Author liwei
 * @Date 2023/7/26 10:13     
 **/
public class DbParameter{

    public  DbParameter(){

    }

    public  DbParameter(String parameterName,Object parameterVal){

        this.parameterName=parameterName;
        this.parameterVal=parameterVal;
    }
    public  DbParameter(String parameterName,Object parameterVal,int parameterSize){
        this.parameterName=parameterName;
        this.parameterVal=parameterVal;
        this.parameterSize=parameterSize;
    }
    public  DbParameter(String parameterName,Object parameterVal,ParamenterType paramenterType,int parameterSize){

        this.parameterName=parameterName;
        this.parameterVal=parameterVal;
        this.paramenterType=paramenterType;
        this.parameterSize=parameterSize;
    }
    public  DbParameter(String parameterName,Object parameterVal,ParamenterType paramenterType,ParameRegisterType parameRegisterType){
        this.parameterName=parameterName;
        this.parameterVal=parameterVal;
        this.paramenterType=paramenterType;
        this.parameRegisterType=parameRegisterType;
    }
    private Object parameterVal = "";////字段值

    private Object retParameterVal = "";////字段值

    private int parameterSize = 2000;////字段最大长度

    private String parameterName = "";////字段名称

    private ParameRegisterType parameRegisterType=ParameRegisterType.in;

    private String sourceParameterName = "";////源名称

    private ParamenterType paramenterType= ParamenterType.VARCHAR;/////字段类型

    public int getParameterSize() {
        return parameterSize;
    }

    public Object getParameterVal() {
        return parameterVal;
    }

    public String getParameterName() {
        return parameterName;
    }

    public ParamenterType getParamenterType() {
        return paramenterType;
    }

    public String getSourceParameterName() {
        return sourceParameterName;
    }

    public void setParameterVal(Object parameterVal) {
        this.parameterVal = parameterVal;
    }

    public void setParameterSize(int parameterSize) {
        this.parameterSize = parameterSize;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public void setParamenterType(ParamenterType paramenterType) {
        this.paramenterType = paramenterType;
    }

    public void setSourceParameterName(String sourceParameterName) {
        this.sourceParameterName = sourceParameterName;
    }

    public ParameRegisterType getParameRegisterType() {
        return parameRegisterType;
    }

    public void setParameRegisterType(ParameRegisterType parameRegisterType) {
        this.parameRegisterType = parameRegisterType;
    }

    public Object getRetParameterVal() {
        return retParameterVal;
    }

    public void setRetParameterVal(Object retParameterVal) {
        this.retParameterVal = retParameterVal;
    }
}
