package com.server.params;

/**
 * @Description 加密类型
 * @Author liwei
 * @Date 2023/7/26 10:23
 **/
public enum EncryType {
    ipone(1),
    email(0);
    private int encryType;


    EncryType(int encryType){

        this.encryType=encryType;
    }
    public int getEncryType() {
        return encryType;
    }

    public void setEncryType(int encryType) {
        this.encryType = encryType;
    }

}
