package com.server.params;

/**
 * @Description 参数自动获取数据库时间
 * @Author liwei
 * @Date 2023/7/26 10:33
 **/
public class RptCompute {



    public RptCompute(String paramentName,String symbol) {
        this.symbol=symbol;
        this.paramentName = paramentName;

    }


    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    private String symbol = "+";/////计算符号

    private String paramentName = "";/////字段名称


    public String getParamentName() {
        return paramentName;
    }


    public void setParamentName(String paramentName) {
        this.paramentName = paramentName;
    }


}
