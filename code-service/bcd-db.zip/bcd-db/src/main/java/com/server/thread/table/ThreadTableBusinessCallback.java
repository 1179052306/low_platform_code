package com.server.thread.table;

import com.alibaba.fastjson.JSONObject;
import com.server.thread.ThreadBase;
import com.server.thread.ThreadsObject;

/**
 * @author lw
 * @date: 2025/3/6
 * @description:
 **/
public interface ThreadTableBusinessCallback {

    ThreadBase externalMethod(ThreadsObject threadsObject, JSONObject row);
}
