//
//package com.server.db;
//
//import com.zaxxer.hikari.HikariDataSource;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.Resource;
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpServletRequest;
//import java.io.IOException;
//import java.util.Arrays;
//import java.util.List;
//import java.util.stream.Stream;
//
//@Slf4j
//@Component
//@WebFilter(urlPatterns = "/*", filterName = "dataSourceFilter")
//public class DataSourceFilter implements Filter {
//    @Autowired
//    private DBProperties dbProperties;
//
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//        Filter.super.init(filterConfig);
//    }
//
//    @Override
//    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
//        HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
//        String domain = httpRequest.getRemoteHost();
//        List<HikariDataSource> dataSources = dbProperties.getNames();
//        Stream<HikariDataSource> dataSourceStream = dataSources.stream().filter(hikari -> domain.equals(hikari.getPoolName()));
//        int rescount = (int) dataSourceStream.count();
//        for (HikariDataSource hikariDataSource : dataSources) {
//            hikariDataSource.getPoolName();
//        }
//        //multiDataSource.get
////        if ("192.168.1.134".equals(domain) || "localhost".equals(domain)) {
//        MultiDataSourceHolder.setDatasource("project");
////        } else if ("domain2.example.com".equals(domain)) {
////            MultiDataSourceHolder.setDatasource("db2");
////        }
//        try {
//            filterChain.doFilter(servletRequest, servletResponse);
//        } finally {
//            MultiDataSourceHolder.clearDataSource();
//        }
//    }
//
//    @Override
//    public void destroy() {
//        Filter.super.destroy();
//    }
//}
//
