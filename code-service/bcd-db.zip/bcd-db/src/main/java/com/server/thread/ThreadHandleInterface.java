package com.server.thread;

/**
 * @author lw
 * @date: 2025/2/26
 * @description:
 **/
@FunctionalInterface
public interface ThreadHandleInterface {

    void execute(String tenantId) throws Exception;
}
