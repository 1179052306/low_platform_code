package com.server.params;

import com.server.db.MultiDataSourceHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description 动态生成SQL
 * @Author liwei
 * @Date 2023/7/26 10:24
 **/
public class GenerateSqlTran {

    public GenerateSqlTran() {

    }

    public GenerateSqlTran(String _strsql) {
        this._strsql = _strsql;
    }

    private String _strsql; /////sql

    private String dbName; /////数据库名

    private String tableName;/////表名



    private String aliasName="";/////别名

    private boolean res = true;/////验证结果

    private DocumentXml _XmlDocumentName;/////xml文档

    private List<GenerateErr> errList = new ArrayList<GenerateErr>();/////错误集合

    private List<GenerateEncry> encryList = new ArrayList<>();/////加密字段

    private List<DbParameter> listParameter = new ArrayList<>();/////特殊处理属性集合

    private List<GenerateSqlTran> listBatch = new ArrayList<GenerateSqlTran>();/////特殊处理属性集合


    public boolean getRes() {
        return res;
    }

    public String getDbName() {
        return dbName;
    }

    public String get_strsql() {
        return _strsql;
    }

    public String getTableName() {
        return tableName;
    }

    public List<GenerateEncry> getEncryList() {
        return encryList;
    }

    public List<GenerateSqlTran> getListBatch() {
        return listBatch;
    }

    public List<DbParameter> getListParameter() {
        return listParameter;
    }

    public DocumentXml get_XmlDocumentName() {
        return _XmlDocumentName;
    }

    public List<GenerateErr> getErrList() {  res = false; return errList; }

    public void setRes(boolean res) {
        this.res = res;
    }

    public void set_strsql(String _strsql) {
        this._strsql = _strsql;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setEncryList(List<GenerateEncry> encryList) {
        this.encryList = encryList;
    }

    public void setListBatch(List<GenerateSqlTran> listBatch) {
        this.listBatch = listBatch;
    }

    public void setListParameter(List<DbParameter> listParameter) {
        this.listParameter = listParameter;
    }

    public void set_XmlDocumentName(DocumentXml _XmlDocumentName) {
        this._XmlDocumentName = _XmlDocumentName;
    }

    public void setDbName(String dbName) {  this.dbName = dbName; }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }
}

