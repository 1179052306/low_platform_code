package com.server.params;

import com.server.db.DbHelp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 * @author lw
 * @date: 2023/12/6
 * @description:
 **/
public class DbKeepTran {

    public DbKeepTran(String dbName) throws Exception {
        this.dbName=dbName;
        DbHelp dbHelp=new DbHelp();
        this.conn = dbHelp.conn(dbName);
    }



    String dbName="";
    List<DbKeep> dbKeeps;
    Connection conn ;
    PreparedStatement preparedStatement = null;
    ResultSet rs = null;
    public List<DbKeep> getDbKeep() {
        return dbKeeps;
    }

    public void setDbKeep(List<DbKeep> dbKeeps) {
        this.dbKeeps = dbKeeps;
    }

    public Connection getConn() {
        return conn;
    }

    public PreparedStatement getPreparedStatement() {
        return preparedStatement;
    }

    public void setPreparedStatement(PreparedStatement preparedStatement) {
        this.preparedStatement = preparedStatement;
    }

    public ResultSet getRs() {
        return rs;
    }

    public void setRs(ResultSet rs) {
        this.rs = rs;
    }
    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

}
