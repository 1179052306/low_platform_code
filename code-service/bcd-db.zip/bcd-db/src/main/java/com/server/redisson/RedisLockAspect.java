//package com.server.redisson;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.aspectj.lang.annotation.After;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.concurrent.TimeUnit;
//
//@Aspect
//@Component
//public class RedisLockAspect {
//
//    private static final Logger logger = LoggerFactory.getLogger(RedisLockAspect.class);
//
//    @Autowired
//    private RedissonClient redissonClient;
//
//    @Pointcut("@annotation(RedisLock)") // 定义切点，拦截所有带有 @RedisLock 注解的方法
//    public void redisLockPointcut() {}
//
//    @Before("redisLockPointcut() && @annotation(redisLock)")
//    public void lock(RedisLock redisLock) throws InterruptedException {
//        String lockName = redisLock.value(); // 获取锁的名称
//        if (lockName.isEmpty()) {
//            lockName = "defaultLock"; // 如果没有提供锁名，使用默认名称
//        }
//
//        long timeout = redisLock.timeout(); // 锁的超时时间
//        long waitTime = redisLock.waitTime(); // 等待锁的最大时间
//        boolean fair = redisLock.fair(); // 是否使用公平锁
//
//        RLock lock = redissonClient.getLock(lockName);
//
//        boolean locked = false;
//        if (fair) {
//            locked = lock.tryLock(waitTime, timeout, TimeUnit.MILLISECONDS); // 公平锁
//        } else {
//            locked = lock.tryLock(0, timeout, TimeUnit.MILLISECONDS); // 非公平锁
//        }
//
//        if (!locked) {
//            throw new RuntimeException("Could not acquire lock within the given time");
//        }
//
//        // 日志记录锁的获取
//        logger.info("Successfully acquired lock: {}", lockName);
//    }
//
//    @After("redisLockPointcut() && @annotation(redisLock)")
//    public void unlock(RedisLock redisLock) {
//        String lockName = redisLock.value();
//        if (lockName.isEmpty()) {
//            lockName = "defaultLock";
//        }
//
//        RLock lock = redissonClient.getLock(lockName);
//        if (lock.isHeldByCurrentThread()) {
//            lock.unlock(); // 释放锁
//            // 日志记录锁的释放
//            logger.info("Successfully released lock: {}", lockName);
//        } else {
//            logger.warn("Lock {} is not held by current thread, skipping unlock", lockName);
//        }
//    }
//}
