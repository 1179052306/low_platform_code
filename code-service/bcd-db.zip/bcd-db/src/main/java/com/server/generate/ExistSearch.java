package com.server.generate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.DbHelpImpl;
import com.server.params.GenerateSqlTran;
import com.server.syntax.val.DbValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description 分组查询
 * @Author liwei
 * @Date 2023/7/26 10:02
 **/
@Service
public class ExistSearch {
    @Autowired
    private GenerateSqlImpl generateSql;

    @Autowired
    private DbHelpImpl dbHelp;

    @Autowired
    private DbValue dbValue;

    /**
     * 分组查询
     *
     * @param dbName
     * @param ColumnName
     * @param ColumnType
     * @param DataString
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    public  String excuteSearch(String dbName, String ColumnName, String ColumnType, String DataString) throws Exception {

        List<GenerateSqlTran> ListSqlTrans = new ArrayList<>();

        String[] DataArry = DataString.split(",");

        if (DataArry.length > 0) {
            if (DataArry.length > 2000) {

                throw new Exception(ColumnName + "分组查询值不能超出500条数据");
            }

            String MstKey= dbValue.getSeqValue(dbName, "M_SEARCH_DATA");
            JSONArray jArray = new JSONArray();
            if (ColumnType.equals("NUMBER")) {

                for (String s : DataArry) {
                    JSONObject jObject = new JSONObject();
                    jObject.put("SEARCH_DATA_KEY", MstKey);
                    jObject.put("COLUMNNAME_NUM", s.trim());
                    jArray.add(jObject);
                }
            } else {
                for (String s : DataArry) {
                    JSONObject jObject = new JSONObject();
                    jObject.put("SEARCH_DATA_KEY", MstKey);
                    jObject.put("COLUMNNAME_VAR", s.trim());
                    jArray.add(jObject);
                }

            }
            generateSql.executeListInsert(dbName, "M_SEARCH_DATA", ListSqlTrans, jArray);
            dbHelp.executeSqlTran(dbName, ListSqlTrans);
            return MstKey;

        } else {
            return null;
        }
    }
}
