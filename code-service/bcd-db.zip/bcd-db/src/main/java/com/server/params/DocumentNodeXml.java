package com.server.params;

import org.dom4j.Node;

/**
 * @Author
 * @Date 2022/11/17 10:54
 */
public class DocumentNodeXml{

    public Node getNode() {
        return node;
    }

    public void setNode(Node node) {
        this.node = node;
    }

    private Node node;
}
