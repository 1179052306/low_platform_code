package com.server.generate;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author lw
 * @date: 2025/3/25
 * @description:
 **/
public class SQLSanitizer {
    // 定义危险关键字列表（大小写不敏感）
//    public static final List<String> DANGEROUS_KEYWORDS = Arrays.asList(
//            "DROP", "SELECT", "INSERT", "DELETE", "UPDATE",
//            "ALTER", "TRUNCATE", "UNION", "EXEC", "CALL",
//            "CREATE", "GRANT", "REVOKE", "COMMIT", "ROLLBACK"
//    );
    public static final List<String> DANGEROUS_KEYWORDS = Arrays.asList(
            "DROP", "INSERT", "DELETE", "UPDATE",
            "ALTER", "TRUNCATE",  "EXEC", "CALL",
            "CREATE", "GRANT", "REVOKE", "COMMIT", "ROLLBACK"
    );
    // 定义危险字符列表（如分号、引号、注释符等）
    // 定义你要过滤的字符列表（包含 "--" 这样的多字符）
    public static final List<String> dangerousPatterns = Arrays.asList("/*");//, "--", ";"

    /**
     * 清理SQL输入，过滤危险关键字和特殊字符。
     *
     * @param input 需要清理的原始字符串
     * @return 清理后的字符串（移除危险内容）
     */
    public static String sanitize(String input) {
        if (input == null) {
            return null;
        }

        // 第一步：过滤危险关键字（大小写不敏感）
        String sanitized = filterKeywords(input);

        // 第二步：过滤危险字符
        sanitized = filterCharacters(sanitized);

        // 移除首尾空格
        return sanitized.trim();
    }

    // 过滤危险关键字
    public static String filterKeywords(String input) {
        if (input == null) {
            return null;
        }
        if (input.length() == 0) {
            return input;
        }
        for (String keyword : DANGEROUS_KEYWORDS) {
//            String regex = "(?i)" +keyword +  "(?=\\s|/\\*)";
            String regex = "\\b" + Pattern.quote(keyword) + "(?=\\s|/\\*)";

            // 使用 Matcher 替换
            Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(input);

            input =  matcher.replaceAll(input + "_");
        }
        return input;
    }

    // 过滤危险字符
    public static String filterCharacters(String input) {
        if (input == null) {
            return null;
        }
        if (input.length() == 0) {
            return input;
        }
        String regex = dangerousPatterns.stream()
                .map(Pattern::quote) // 转义每个模式中的特殊字符
                .collect(Collectors.joining("|"));

// 包裹在 (?:...) 中表示非捕获组
        regex = "(?:" + regex + ")";

// 使用正则表达式替换所有匹配项为空字符串
        return input.replaceAll(regex, "");
    }

    public static String preparedStatementsanitize(String input){
        if (input == null) {
            return null;
        }
        if (input.length() == 0) {
            return input;
        }
        // 第一步：过滤危险关键字（大小写不敏感）
        String sanitized = filterKeywords(input);

        // 第二步：过滤危险字符
        sanitized = filterCharacters(sanitized);

        // 移除首尾空格
        return sanitized.trim();
    }
}
