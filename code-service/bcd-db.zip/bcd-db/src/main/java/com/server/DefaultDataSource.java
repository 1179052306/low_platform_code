//package com.server;
//
//import java.lang.annotation.*;
//
//import static java.lang.annotation.ElementType.*;
//import static java.lang.annotation.RetentionPolicy.RUNTIME;
//
//@Target({ElementType.FIELD,ElementType.METHOD, TYPE})
//@Retention(RUNTIME)
//@Documented
//public @interface DefaultDataSource {
//
//    String dbName() default "project";
//
//}
