package com.server.thread.table;

/**
 * @author lw
 * @date: 2025/3/6
 * @description:
 **/
public class ThreadTable {

    String tableName;

    String tablePkColumn;

    String tablePkVal;

    String tableStateColumn;

    String tableSeelpColumn;

    String tableDataColumn;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getTablePkColumn() {
        return tablePkColumn;
    }

    public void setTablePkColumn(String tablePkColumn) {
        this.tablePkColumn = tablePkColumn;
    }

    public String getTablePkVal() {
        return tablePkVal;
    }

    public void setTablePkVal(String tablePkVal) {
        this.tablePkVal = tablePkVal;
    }

    public String getTableStateColumn() {
        return tableStateColumn;
    }

    public void setTableStateColumn(String tableStateColumn) {
        this.tableStateColumn = tableStateColumn;
    }

    public String getTableSeelpColumn() {
        return tableSeelpColumn;
    }

    public void setTableSeelpColumn(String tableSeelpColumn) {
        this.tableSeelpColumn = tableSeelpColumn;
    }

    public String getTableDataColumn() {
        return tableDataColumn;
    }

    public void setTableDataColumn(String tableDataColumn) {
        this.tableDataColumn = tableDataColumn;
    }
}
