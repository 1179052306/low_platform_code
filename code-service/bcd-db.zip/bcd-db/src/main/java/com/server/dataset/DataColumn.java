package com.server.dataset;

/**
 * @Author
 * @Date 2022/11/14 13:13
 */
public class DataColumn {

    public DataColumn(DataTable table){

        this.table=table;
    }

    public DataColumn(String columnName,int columnType,String columnTypeName, DataTable table){

        this.ColumnName=columnName;
        this.table=table;
        this.ColumnType=columnType;
        this.ColumnTypeName=columnTypeName;
    }

    public String getColumnName() {
        return ColumnName;
    }

    public void setColumnName(String columnName) {
        this.ColumnName = columnName;
    }

    public String ColumnName="";

    public String getCaption() {
        return Caption;
    }

    public void setCaption(String caption) {
        this.Caption = caption;
    }

    public String Caption="";

    public Object getDefaultValue() {
        return DefaultValue;
    }

    public void setDefaultValue(Object defaultValue) {
        this.DefaultValue = defaultValue;
    }

    public Object DefaultValue;

    public DataTable getTable() {
        return table;
    }

    public void setTable(DataTable table) {
        this.table = table;
    }

    private DataTable table;

    public int getColumnType() {
        return ColumnType;
    }

    public void setColumnType(int columnType) {
        ColumnType = columnType;
    }
//    Types
    private int ColumnType;

    public String getColumnTypeName() {
        return ColumnTypeName;
    }

    public void setColumnTypeName(String columnTypeName) {
        ColumnTypeName = columnTypeName;
    }

    private String ColumnTypeName;
}
