package com.server.special_handle;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.server.db.MultiDataSourceHolder;
import com.server.db.Tenant;
import com.server.tenant.TenantData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author lw
 * @date: 2025/2/26
 * @description:
 **/

@Service
public class SpecialHandle {

    @Autowired
    TenantData tenantData;

    public  <T> void execute(Tenant tenant,SpecialHandleInterface<T> task, T... args) throws Exception {
        if(tenant.getSingle()) {
            task.execute(args);
        }else {
           JSONArray data= tenantData.getTenant();
            for (int i = 0; i < data.size(); i++) {
                JSONObject item=data.getJSONObject(i);
                MultiDataSourceHolder.setDatasource(item.getString("TENANT_ID"));
                task.execute(args);
                MultiDataSourceHolder.clearDataSource();
            }


        }
    }
}
