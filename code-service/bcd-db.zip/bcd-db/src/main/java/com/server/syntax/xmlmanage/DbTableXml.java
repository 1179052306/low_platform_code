package com.server.syntax.xmlmanage;


import com.server.db.DbConfig;
import com.server.db.InterceptTenant;
import com.server.db.Tenant;
import com.server.params.GenerateSqlTran;
import lombok.SneakyThrows;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.UnsupportedEncodingException;

/**
 * @Description 保存XML
 * @Author liwei
 * @Date 2023/7/26 10:39
 **/
@Service
public class DbTableXml {


    @Resource
    DbConfig dbConfig;

    @Qualifier("oracleXmlMange")
    @Autowired
    DbTableXmlServer oracleSaveXml;

    @Qualifier("pgXmlMange")
    @Autowired
    DbTableXmlServer postgreSqlSaveXml;

    @Qualifier("dmXmlMange")
    @Autowired
    DbTableXmlServer dmSaveXml;

    @Autowired
    Tenant tenant;

    @Autowired
    InterceptTenant interceptTenant;
    /**
     * 保存xml
     *
     * @param path
     * @param table
     * @param dbName
     * @return Document
     * @author liwei
     * @date: 2023/7/26
     **/
    public Document saveTableXml(String path, String table, @Nullable String dbName) {
        Document doc = null;
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            boolean res = oracleSaveXml.saveXml(path, table, dbName);
            if (res) {
                doc = getTableXml(table, dbName);
            }

        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            boolean res = postgreSqlSaveXml.saveXml(path, table, dbName);
            if (res) {
                doc = getTableXml(table, dbName);
            }

        }
        if (Type.equals("4")) {

            boolean res = dmSaveXml.saveXml(path, table, dbName);
            if (res) {
                doc = getTableXml(table, dbName);
            }

        }
        return doc;
    }

    /**
     * 重置xml
     *
     * @param path
     * @param table
     * @param dbName
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public boolean resetTableXml(String path, String table, @Nullable String dbName) {


        boolean res = false;
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


             res = oracleSaveXml.saveXml(path, table, dbName);
        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            res = postgreSqlSaveXml.saveXml(path, table, dbName);

        }
        if (Type.equals("4")) {

            res = dmSaveXml.saveXml(path, table, dbName);

        }
        return res;
    }

    /**
     * 检查字段xml
     *
     * @param table
     * @param columnName
     * @param dbName
     * @return boolean
     * @author liwei
     * @date: 2023/7/26
     **/
    public boolean checkColumnXml(String table, String columnName, @Nullable String dbName) {


        boolean res = false;
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            res = oracleSaveXml.checkColumnXml(table, columnName, dbName);
        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {

            res = postgreSqlSaveXml.checkColumnXml(table, columnName, dbName);

        }
        if (Type.equals("4")) {

            res = dmSaveXml.checkColumnXml(table, columnName, dbName);

        }
        return res;
    }

    /**
     * 获取xml
     *
     * @param table
     * @param dbName
     * @return Document
     * @author liwei
     * @date: 2023/7/26
     **/
    @SneakyThrows
    public Document getTableXml(String table, @Nullable String dbName) {

        Document doc = null;
        String path = getPath();
        path+="/TableXml";
//        path = java.net.URLDecoder.decode(path, "utf-8");
        File TableXml = new File(path  );
        if (!TableXml.exists()) {
            TableXml.mkdir();
        }

        if(!tenant.getSingle()){
            TableXml = new File(path + "/"+ interceptTenant.getTenantHeader());
            if (!TableXml.exists()) {
                TableXml.mkdir();
            }
            path+="/"+ interceptTenant.getTenantHeader();
        }

        File dbNameFile = new File(path+ "/" + dbName);
        if (dbNameFile.exists()) {
            File Xml = new File(path + "/" + dbName + "/" + table + ".xml");
            if (Xml.exists()) {
                try {
                    SAXReader reader = new SAXReader();
//                    doc=  reader.read(Common.class.getResourceAsStream("/TableXml/"+table+".xml"));
                    doc = reader.read(Xml);
                } catch (Exception ex) {}

            } else {
                doc = saveTableXml(path + "/" + dbName + "/" + table + ".xml", table, dbName);
            }
        } else {
            dbNameFile.mkdir();
            doc = getTableXml(table, dbName);
        }
        return doc;
    }

    private String getPath() throws UnsupportedEncodingException {
        String path = System.getProperty("user.dir");
        path = java.net.URLDecoder.decode(path, "utf-8");
        int index=path.indexOf("serviceRelease");
        if(index==-1){
            return path;
        }
        path= path.substring(0,index+14);
        return  path;
    }
    /**
     * 获取xml路径
     *
     * @param table
     * @param dbName
     * @return String
     * @author liwei
     * @date: 2023/7/26
     **/
    @SneakyThrows
    public String getTableXmlPath(String table, @Nullable String dbName) {
        String path = getPath();

        if(!tenant.getSingle()){
            return path + "/TableXml/" +interceptTenant.getTenantHeader()+"/"+ dbName + "/" + table + ".xml";
        }else{
            return path + "/TableXml/" + dbName + "/" + table + ".xml";
        }
//        path = java.net.URLDecoder.decode(path, "utf-8");

    }

    /**
     * 获取全部表数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    public StringBuilder getDataSql(@Nullable String dbName) {
        StringBuilder StrSql = new StringBuilder();
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            StrSql = oracleSaveXml.getDataSql(dbName);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {


            StrSql = postgreSqlSaveXml.getDataSql(dbName);
        }

        if (Type.equals("4")) {


            StrSql = dmSaveXml.getDataSql(dbName);
        }
        return StrSql;
    }

    /**
     * @Description:  获取数据库所有表名称
     * @param dbName 数据库标识
     * @param symbol 条件标识符
     * @param filter 条件
     * @Return {@link GenerateSqlTran}
     * @Author: 陈永书
     * @Date: 2024/2/3 14:27
     */
    public GenerateSqlTran getDataSql(@Nullable String dbName, String symbol, String filter) {
        GenerateSqlTran sqlTran = new GenerateSqlTran();
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {

        }
        if (Type.equals("1")) {

            sqlTran = oracleSaveXml.getDataSql(dbName, symbol, filter);
        }
        if (Type.equals("2")) {

        }
        if (Type.equals("3")) {

            sqlTran = postgreSqlSaveXml.getDataSql(dbName, symbol, filter);
        }
        if (Type.equals("4")) {

            sqlTran = dmSaveXml.getDataSql(dbName, symbol, filter);
        }
        return sqlTran;
    }

    /**
     * 获取全部表字段数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    public StringBuilder getTableColumnSql(@Nullable String dbName) {
        StringBuilder StrSql = new StringBuilder();
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            StrSql = oracleSaveXml.getTableColumnSql(dbName);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {


            StrSql = postgreSqlSaveXml.getTableColumnSql(dbName);
        }
        if (Type.equals("4")) {


            StrSql = dmSaveXml.getTableColumnSql(dbName);
        }
        return StrSql;
    }
    /**
     * 获取全部表字段数据SQL
     *
     * @param dbName
     * @return StringBuilder
     * @author liwei
     * @date: 2023/7/26
     **/
    public GenerateSqlTran getTableColumnSql(@Nullable String dbName,String tableName) {
        GenerateSqlTran generateSqlTran = new GenerateSqlTran();
        String Type = dbConfig.getType(dbName);
        if (Type.equals("0")) {


        }
        if (Type.equals("1")) {


            generateSqlTran = oracleSaveXml.getTableColumnSql(dbName,tableName);


        }
        if (Type.equals("2")) {


        }
        if (Type.equals("3")) {


            generateSqlTran = postgreSqlSaveXml.getTableColumnSql(dbName,tableName);
        }

        if (Type.equals("4")) {


            generateSqlTran = dmSaveXml.getTableColumnSql(dbName,tableName);
        }
        return generateSqlTran;
    }
}
