package com.server.thread.table;

import com.server.DbComposite;

/**
 * @author lw
 * @date: 2025/3/6
 * @description:
 **/

public class ThreadTableBusiness {
    public ThreadTableBusiness() {

    }

    public ThreadTableBusiness(String project, ThreadTable threadTable, DbComposite dbComposite, ThreadTableBusinessCallback threadTableBusinessCallback) {
        this.project = project;
        this.threadTable = threadTable;
        this.dbComposite = dbComposite;
        this.threadTableBusinessCallback = threadTableBusinessCallback;
    }

    String project = "project";

    ThreadTable threadTable;

    DbComposite dbComposite;

    ThreadTableBusinessCallback threadTableBusinessCallback;



    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public ThreadTable getThreadTable() {
        return threadTable;
    }

    public void setThreadTable(ThreadTable threadTable) {
        this.threadTable = threadTable;
    }


    public DbComposite getDbComposite() {
        return dbComposite;
    }

    public void setDbComposite(DbComposite dbComposite) {
        this.dbComposite = dbComposite;
    }

    public ThreadTableBusinessCallback getThreadBusinessCallback() {
        return threadTableBusinessCallback;
    }

    public void setThreadBusinessCallback(ThreadTableBusinessCallback threadTableBusinessCallback) {
        this.threadTableBusinessCallback = threadTableBusinessCallback;
    }
}
